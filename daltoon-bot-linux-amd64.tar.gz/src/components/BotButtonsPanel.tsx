import { translateText, Language, translations } from "../lang/locales";
import React, { useState } from "react";
import { CustomSelect } from "./CustomSelect";
import { PanelSettings, CustomButton } from "../types";
import ConfirmationModal from "./ConfirmationModal";
import {
  Command,
  Sparkles,
  PlusCircle,
  Check,
  Edit,
  Pencil,
  Trash2,
  Plus,
  Save,
  Database,
  Columns,
  Power,
  ChevronUp,
  ChevronDown,
  Activity,
  Coins,
  Settings,
  ImageIcon,
  Film,
  Mic,
  Paperclip,
  Palette,
  Globe,
  Smartphone,
  Sliders,
  Grid2X2,
  Layers,
  Eye,
  Upload,
  ToggleLeft,
  ToggleRight,
} from "lucide-react";

interface BotButtonsPanelProps {
  settings: PanelSettings;
  onSaveSettings: (settings: PanelSettings) => void;
  lang: Language;
  customButtons: CustomButton[];
  setCustomButtons: React.Dispatch<React.SetStateAction<CustomButton[]>>;
}

export default function BotButtonsPanel({
  settings,
  onSaveSettings,
  lang,
  customButtons,
  setCustomButtons,
}: BotButtonsPanelProps) {
  const t = { ...translations.en, ...translations[lang] };

  const [deleteConfirmConfig, setDeleteConfirmConfig] = useState<{
    isOpen: boolean;
    action: (() => void) | null;
    message: string;
  }>({ isOpen: false, action: null, message: "" });

  // Primary buttons text & visibility states
  const [btnTextBuyNew, setBtnTextBuyNew] = useState(
    settings.btnTextBuyNew || "🛒 خرید اشتراک جدید",
  );
  const [hideBtnBuyNew, setHideBtnBuyNew] = useState(!!settings.hideBtnBuyNew);

  const [btnTextMySubs, setBtnTextMySubs] = useState(
    settings.btnTextMySubs || "🗂 سرویس‌های من / تمدید",
  );
  const [hideBtnMySubs, setHideBtnMySubs] = useState(!!settings.hideBtnMySubs);

  const [btnTextGuides, setBtnTextGuides] = useState(
    settings.btnTextGuides || "💡 راهنما",
  );
  const [hideBtnGuides, setHideBtnGuides] = useState(!!settings.hideBtnGuides);

  const [btnTextProfile, setBtnTextProfile] = useState(
    settings.btnTextProfile || "👤 حساب کاربری",
  );
  const [hideBtnProfile, setHideBtnProfile] = useState(
    !!settings.hideBtnProfile,
  );

  const [btnTextSupport, setBtnTextSupport] = useState(
    settings.btnTextSupport || "📞 پشتیبانی",
  );
  const [hideBtnSupport, setHideBtnSupport] = useState(
    !!settings.hideBtnSupport,
  );

  const [btnTextTicketSupport, setBtnTextTicketSupport] = useState(
    settings.btnTextTicketSupport || "🎫 تیکت پشتیبانی",
  );
  const [hideBtnTicketSupport, setHideBtnTicketSupport] = useState(
    !!settings.hideBtnTicketSupport,
  );

  const [btnTextFreeTest, setBtnTextFreeTest] = useState(
    settings.btnTextFreeTest || "🎁 تست رایگان",
  );
  const [hideBtnFreeTest, setHideBtnFreeTest] = useState(
    !!settings.hideBtnFreeTest,
  );

  const [btnTextInstantSupport, setBtnTextInstantSupport] = useState(
    settings.btnTextInstantSupport || "🤖 پشتیبانی آنی",
  );
  const [hideBtnInstantSupport, setHideBtnInstantSupport] = useState(
    !!settings.hideBtnInstantSupport,
  );

  const [btnTextFeedback, setBtnTextFeedback] = useState(
    settings.btnTextFeedback || "💌 نظرات کاربران",
  );
  const [hideBtnFeedback, setHideBtnFeedback] = useState(
    !!settings.hideBtnFeedback,
  );

  const [btnTextWallet, setBtnTextWallet] = useState(
    settings.btnTextWallet || "💵 کیف پول + شارژ",
  );
  const [hideBtnWallet, setHideBtnWallet] = useState(!!settings.hideBtnWallet);

  const [btnTextReferral, setBtnTextReferral] = useState(
    settings.btnTextReferral || "👥 زیرمجموعه‌گیری",
  );
  const [hideBtnReferral, setHideBtnReferral] = useState(
    !!settings.hideBtnReferral,
  );

  const [btnTextColleagues, setBtnTextColleagues] = useState(
    settings.btnTextColleagues || "پنل ویژه همکاران",
  );
  const [hideBtnColleagues, setHideBtnColleagues] = useState(
    settings.hideBtnColleagues !== undefined
      ? settings.hideBtnColleagues
      : true,
  ); // default hidden

  const [btnTextAiChat, setBtnTextAiChat] = useState(
    settings.btnTextAiChat || "🤖 چت هوشمند",
  );
  const [hideBtnAiChat, setHideBtnAiChat] = useState(
    settings.hideBtnAiChat !== undefined ? settings.hideBtnAiChat : true,
  ); // default hidden

  const [btnTextAi, setBtnTextAi] = useState(
    settings.btnTextAi || "🧠 هوش مصنوعی",
  );
  const [hideBtnAi, setHideBtnAi] = useState(
    settings.hideBtnAi !== undefined ? settings.hideBtnAi : true,
  );

  const [btnTextAddConfig, setBtnTextAddConfig] = useState(
    settings.btnTextAddConfig || "➕ افزودن کانفیگ به ربات",
  );
  const [hideBtnAddConfig, setHideBtnAddConfig] = useState(
    !!settings.hideBtnAddConfig,
  );

  const [btnTextConfigDetails, setBtnTextConfigDetails] = useState(
    settings.btnTextConfigDetails || "📊 مشخصات کانفیگ",
  );
  const [hideBtnConfigDetails, setHideBtnConfigDetails] = useState(
    !!settings.hideBtnConfigDetails,
  );

  const [btnTextSearchConfig, setBtnTextSearchConfig] = useState(
    settings.btnTextSearchConfig || "🔍 سرچ کانفیگ (مدیریت)",
  );
  const [hideBtnSearchConfig, setHideBtnSearchConfig] = useState(
    !!settings.hideBtnSearchConfig,
  );

  const [useMiniAppMode, setUseMiniAppMode] = useState(
    !!settings.useMiniAppMode,
  );
  const [startCommandMode, setStartCommandMode] = useState<
    "buttons" | "miniapp" | "dual_choice"
  >(
    settings.startCommandMode ||
      (settings.useMiniAppMode ? "miniapp" : "buttons"),
  );
  const [btnTextMiniApp, setBtnTextMiniApp] = useState(
    settings.btnTextMiniApp || "🚀 ورود به برنامه هوشمند",
  );
  const [btnTextDashSimple, setBtnTextDashSimple] = useState(
    settings.btnTextDashSimple || "📱 داشبورد ساده",
  );
  const [btnTextDashPro, setBtnTextDashPro] = useState(
    settings.btnTextDashPro || settings.btnTextMiniApp || "🚀 داشبورد حرفه‌ای",
  );
  const [dashButtonsLayout, setDashButtonsLayout] = useState<"single" | "double">(
    settings.dashButtonsLayout || "single",
  );
  const [dashButtonsOrder, setDashButtonsOrder] = useState<"simple_first" | "pro_first">(
    settings.dashButtonsOrder || "simple_first",
  );
  const [hideBtnDashSimple, setHideBtnDashSimple] = useState(
    !!settings.hideBtnDashSimple,
  );
  const [hideBtnDashPro, setHideBtnDashPro] = useState(
    !!settings.hideBtnDashPro,
  );
  const [miniAppUrl, setMiniAppUrl] = useState(
    settings.miniAppUrl || "",
  );
  const [hideBtnMiniApp, setHideBtnMiniApp] = useState(
    !!settings.hideBtnMiniApp,
  );
  const [miniAppSplashLogo, setMiniAppSplashLogo] = useState(
    settings.miniAppSplashLogo || "",
  );
  const [miniAppSplashEnabled, setMiniAppSplashEnabled] = useState(
    settings.miniAppSplashEnabled !== false,
  );

  const [keyboardLayout, setKeyboardLayout] = useState<
    "horizontal" | "vertical" | "stepped"
  >(settings.keyboardLayout || "stepped");
  const [guidesText, setGuidesText] = useState(settings.guidesText || "");
  const [showGuidesModal, setShowGuidesModal] = useState(false);
  const [tempGuidesText, setTempGuidesText] = useState("");

  // States for Guide Video URLs / File IDs
  const [guideVideoHapp, setGuideVideoHapp] = useState(
    settings.guideVideoHapp || "",
  );
  const [guideVideoIos, setGuideVideoIos] = useState(
    settings.guideVideoIos || "",
  );
  const [guideVideoAndroid, setGuideVideoAndroid] = useState(
    settings.guideVideoAndroid || "",
  );
  const [guideVideoV2rayn, setGuideVideoV2rayn] = useState(
    settings.guideVideoV2rayn || "",
  );
  const [guideVideoKaring, setGuideVideoKaring] = useState(
    settings.guideVideoKaring || "",
  );
  const [guideVideoMac, setGuideVideoMac] = useState(
    settings.guideVideoMac || "",
  );
  const [guideVideoLinux, setGuideVideoLinux] = useState(
    settings.guideVideoLinux || "",
  );

  React.useEffect(() => {
    if (settings.btnTextBuyNew !== undefined) setBtnTextBuyNew(settings.btnTextBuyNew || "🛒 خرید اشتراک جدید");
    if (settings.hideBtnBuyNew !== undefined) setHideBtnBuyNew(!!settings.hideBtnBuyNew);
    if (settings.btnTextMySubs !== undefined) setBtnTextMySubs(settings.btnTextMySubs || "🗂 سرویس‌های من / تمدید");
    if (settings.hideBtnMySubs !== undefined) setHideBtnMySubs(!!settings.hideBtnMySubs);
    if (settings.btnTextGuides !== undefined) setBtnTextGuides(settings.btnTextGuides || "💡 راهنما");
    if (settings.hideBtnGuides !== undefined) setHideBtnGuides(!!settings.hideBtnGuides);
    if (settings.btnTextProfile !== undefined) setBtnTextProfile(settings.btnTextProfile || "👤 حساب کاربری");
    if (settings.hideBtnProfile !== undefined) setHideBtnProfile(!!settings.hideBtnProfile);
    if (settings.btnTextSupport !== undefined) setBtnTextSupport(settings.btnTextSupport || "📞 پشتیبانی");
    if (settings.hideBtnSupport !== undefined) setHideBtnSupport(!!settings.hideBtnSupport);
    if (settings.btnTextTicketSupport !== undefined) setBtnTextTicketSupport(settings.btnTextTicketSupport || "🎫 تیکت پشتیبانی");
    if (settings.hideBtnTicketSupport !== undefined) setHideBtnTicketSupport(!!settings.hideBtnTicketSupport);
    if (settings.btnTextFreeTest !== undefined) setBtnTextFreeTest(settings.btnTextFreeTest || "🎁 تست رایگان");
    if (settings.hideBtnFreeTest !== undefined) setHideBtnFreeTest(!!settings.hideBtnFreeTest);
    if (settings.btnTextInstantSupport !== undefined) setBtnTextInstantSupport(settings.btnTextInstantSupport || "🤖 پشتیبانی آنی");
    if (settings.hideBtnInstantSupport !== undefined) setHideBtnInstantSupport(!!settings.hideBtnInstantSupport);
    if (settings.btnTextFeedback !== undefined) setBtnTextFeedback(settings.btnTextFeedback || "💌 نظرات کاربران");
    if (settings.hideBtnFeedback !== undefined) setHideBtnFeedback(!!settings.hideBtnFeedback);
    if (settings.btnTextWallet !== undefined) setBtnTextWallet(settings.btnTextWallet || "💵 کیف پول + شارژ");
    if (settings.hideBtnWallet !== undefined) setHideBtnWallet(!!settings.hideBtnWallet);
    if (settings.btnTextReferral !== undefined) setBtnTextReferral(settings.btnTextReferral || "👥 زیرمجموعه‌گیری");
    if (settings.hideBtnReferral !== undefined) setHideBtnReferral(!!settings.hideBtnReferral);
    if (settings.btnTextColleagues !== undefined) setBtnTextColleagues(settings.btnTextColleagues || "پنل ویژه همکاران");
    if (settings.hideBtnColleagues !== undefined) setHideBtnColleagues(settings.hideBtnColleagues !== undefined ? settings.hideBtnColleagues : true);
    if (settings.btnTextAiChat !== undefined) setBtnTextAiChat(settings.btnTextAiChat || "🤖 چت هوشمند");
    if (settings.hideBtnAiChat !== undefined) setHideBtnAiChat(settings.hideBtnAiChat !== undefined ? settings.hideBtnAiChat : true);
    if (settings.btnTextAi !== undefined) setBtnTextAi(settings.btnTextAi || "🧠 هوش مصنوعی");
    if (settings.hideBtnAi !== undefined) setHideBtnAi(settings.hideBtnAi !== undefined ? settings.hideBtnAi : true);
    if (settings.btnTextAddConfig !== undefined) setBtnTextAddConfig(settings.btnTextAddConfig || "➕ افزودن کانفیگ به ربات");
    if (settings.hideBtnAddConfig !== undefined) setHideBtnAddConfig(!!settings.hideBtnAddConfig);
    if (settings.btnTextConfigDetails !== undefined) setBtnTextConfigDetails(settings.btnTextConfigDetails || "📊 مشخصات کانفیگ");
    if (settings.hideBtnConfigDetails !== undefined) setHideBtnConfigDetails(!!settings.hideBtnConfigDetails);
    if (settings.btnTextSearchConfig !== undefined) setBtnTextSearchConfig(settings.btnTextSearchConfig || "🔍 سرچ کانفیگ (مدیریت)");
    if (settings.hideBtnSearchConfig !== undefined) setHideBtnSearchConfig(!!settings.hideBtnSearchConfig);
    if (settings.useMiniAppMode !== undefined) setUseMiniAppMode(!!settings.useMiniAppMode);
    if (settings.startCommandMode) {
      setStartCommandMode(settings.startCommandMode);
    } else if (settings.useMiniAppMode !== undefined) {
      setStartCommandMode(settings.useMiniAppMode ? "miniapp" : "buttons");
    }
    if (settings.btnTextMiniApp !== undefined) setBtnTextMiniApp(settings.btnTextMiniApp || "🚀 ورود به برنامه هوشمند");
    if (settings.btnTextDashSimple !== undefined) setBtnTextDashSimple(settings.btnTextDashSimple || "📱 داشبورد ساده");
    if (settings.btnTextDashPro !== undefined) setBtnTextDashPro(settings.btnTextDashPro || "🚀 داشبورد حرفه‌ای");
    if (settings.dashButtonsLayout !== undefined) setDashButtonsLayout(settings.dashButtonsLayout || "single");
    if (settings.dashButtonsOrder !== undefined) setDashButtonsOrder(settings.dashButtonsOrder || "simple_first");
    if (settings.hideBtnDashSimple !== undefined) setHideBtnDashSimple(!!settings.hideBtnDashSimple);
    if (settings.hideBtnDashPro !== undefined) setHideBtnDashPro(!!settings.hideBtnDashPro);
    if (settings.miniAppUrl !== undefined) setMiniAppUrl(settings.miniAppUrl || "");
    if (settings.hideBtnMiniApp !== undefined) setHideBtnMiniApp(!!settings.hideBtnMiniApp);
    if (settings.miniAppSplashLogo !== undefined) setMiniAppSplashLogo(settings.miniAppSplashLogo || "");
    if (settings.miniAppSplashEnabled !== undefined) setMiniAppSplashEnabled(settings.miniAppSplashEnabled !== false);
    if (settings.keyboardLayout !== undefined) setKeyboardLayout(settings.keyboardLayout || "stepped");
    if (settings.guidesText !== undefined) setGuidesText(settings.guidesText || "");
    if (settings.guideVideoHapp !== undefined) setGuideVideoHapp(settings.guideVideoHapp || "");
    if (settings.guideVideoIos !== undefined) setGuideVideoIos(settings.guideVideoIos || "");
    if (settings.guideVideoAndroid !== undefined) setGuideVideoAndroid(settings.guideVideoAndroid || "");
    if (settings.guideVideoV2rayn !== undefined) setGuideVideoV2rayn(settings.guideVideoV2rayn || "");
    if (settings.guideVideoKaring !== undefined) setGuideVideoKaring(settings.guideVideoKaring || "");
    if (settings.guideVideoMac !== undefined) setGuideVideoMac(settings.guideVideoMac || "");
    if (settings.guideVideoLinux !== undefined) setGuideVideoLinux(settings.guideVideoLinux || "");
    if (settings.walletChargeAmounts && Array.isArray(settings.walletChargeAmounts)) {
      setWalletChargeAmounts(settings.walletChargeAmounts);
    }
    if (settings.singleButtons && Array.isArray(settings.singleButtons)) {
      setSingleButtons(settings.singleButtons);
    }
  }, [settings]);

  const [singleButtons, setSingleButtons] = useState<string[]>(() => {
    if (settings.singleButtons && Array.isArray(settings.singleButtons)) {
      return settings.singleButtons;
    }
    return ["btnBuyNew", "btnColleagues"];
  });

  const [walletChargeAmounts, setWalletChargeAmounts] = useState<number[]>(
    () => {
      return settings.walletChargeAmounts &&
        Array.isArray(settings.walletChargeAmounts)
        ? settings.walletChargeAmounts
        : [200000, 300000, 400000, 500000, 1000000];
    },
  );
  const [showWalletAmountsModal, setShowWalletAmountsModal] = useState(false);
  const [tempChargeAmounts, setTempChargeAmounts] = useState<number[]>([]);

  const defaultOrder = [
    "btnBuyNew",
    "btnWallet",
    "btnMySubs",
    "btnAddConfig",
    "btnConfigDetails",
    "btnSearchConfig",
    "btnGuides",
    "btnColleagues",
    "btnProfile",
    "btnSupport",
    "btnTicketSupport",
    "btnFreeTest",
    "btnAiChat",
    "btnAi",
    "btnInstantSupport",
    "btnFeedback",
    "btnReferral",
  ];

  const [mainButtonsOrder, setMainButtonsOrder] = useState<string[]>(() => {
    if (settings.mainButtonsOrder && settings.mainButtonsOrder.length > 0) {
      const saved = [...settings.mainButtonsOrder];
      defaultOrder.forEach((key) => {
        if (!saved.includes(key)) {
          saved.push(key);
        }
      });
      return saved;
    }
    return defaultOrder;
  });

  // Custom reply buttons states
  const [btnText, setBtnText] = useState("");
  const [btnReplyText, setBtnReplyText] = useState("");
  const [buttonError, setButtonError] = useState("");
  const [buttonSuccess, setButtonSuccess] = useState(false);
  const [editingButtonId, setEditingButtonId] = useState<string | null>(null);

  const [saved, setSaved] = useState(false);
  const [isExtraWordsOpen, setIsExtraWordsOpen] = useState(false);
  const [isPremiumEmojisOpen, setIsPremiumEmojisOpen] = useState(false);

  const [usePremiumEmojis, setUsePremiumEmojis] = useState(
    settings.usePremiumEmojis !== undefined ? settings.usePremiumEmojis : false
  );
  const [useButtonColors, setUseButtonColors] = useState(
    settings.useButtonColors !== undefined ? settings.useButtonColors : false
  );

  
  const [primaryButtonColors, setPrimaryButtonColors] = useState<Record<string, string>>(
    settings.primaryButtonColors || {}
  );
  
  const defaultExtraColors: {keyword: string, color: string}[] = [];
  
  const [extraButtonColors, setExtraButtonColors] = useState<{keyword: string, color: string}[]>(
    settings.extraButtonColors || (settings.buttonStylesMapping ? Object.entries(settings.buttonStylesMapping).flatMap(([color, words]) => words.map(w => ({keyword: w, color}))) : defaultExtraColors)
  );
  
  const defaultEmojis = [
    {"emoji": "🛒", "customId": "5449640306352655512"}, {"emoji": "🎁", "customId": "5368324170671202286"},
    {"emoji": "👤", "customId": "5368324170671202287"}, {"emoji": "🎧", "customId": "5368324170671202288"},
    {"emoji": "🚀", "customId": "5368324170671202289"}, {"emoji": "✅", "customId": "5368324170671202290"},
    {"emoji": "❌", "customId": "5368324170671202291"}, {"emoji": "⚠️", "customId": "5368324170671202292"},
    {"emoji": "💎", "customId": "5368324170671202293"}, {"emoji": "💰", "customId": "5368324170671202294"},
    {"emoji": "📊", "customId": "5368324170671202295"}, {"emoji": "🔄", "customId": "5368324170671202296"},
    {"emoji": "🎫", "customId": "5368324170671202297"}, {"emoji": "⚡", "customId": "5368324170671202298"},
    {"emoji": "💳", "customId": "5368324170671202299"}, {"emoji": "📝", "customId": "5368324170671202300"},
    {"emoji": "⏳", "customId": "5368324170671202301"}, {"emoji": "🌐", "customId": "5368324170671202302"},
    {"emoji": "⚙️", "customId": "5368324170671202303"}, {"emoji": "🔌", "customId": "5368324170671202304"},
    {"emoji": "🔋", "customId": "5368324170671202305"}, {"emoji": "💡", "customId": "5368324170671202306"},
    {"emoji": "🔒", "customId": "5368324170671202307"}, {"emoji": "🔓", "customId": "5368324170671202308"},
    {"emoji": "🔑", "customId": "5368324170671202309"}
  ];
  
  const [premiumEmojiList, setPremiumEmojiList] = useState<{emoji: string, customId: string}[]>(
    settings.premiumEmojiList || (settings.premiumEmojiMapping ? Object.entries(settings.premiumEmojiMapping).map(([k, v]) => ({emoji: k, customId: v})) : defaultEmojis)
  );

  const [supportHandle, setSupportHandle] = useState(
    settings.supportHandle || "",
  );
  const [welcomeText, setWelcomeText] = useState(settings.welcomeText || "");
  const [supportText, setSupportText] = useState(settings.supportText || "");
  const [pinnedMessageText, setPinnedMessageText] = useState(settings.pinnedMessageText || "");
  const [pinnedMessageActive, setPinnedMessageActive] = useState(!!settings.pinnedMessageActive);
  const [purchaseSuccessNote, setPurchaseSuccessNote] = useState(
    settings.purchaseSuccessNote || "",
  );
  const [activePurchaseAttachment, setActivePurchaseAttachment] = useState<{
    fileData: string;
    fileName: string;
    fileType: "image" | "video" | "voice" | "file";
  } | null>(settings.purchaseSuccessAttachment || null);
  const [activePurchaseUploadType, setActivePurchaseUploadType] = useState<
    "image" | "video" | "voice" | "file"
  >("image");
  const purchaseAttachmentInputRef = React.useRef<HTMLInputElement>(null);

  const triggerPurchaseUpload = (
    type: "image" | "video" | "voice" | "file",
  ) => {
    setActivePurchaseUploadType(type);
    setTimeout(() => {
      if (purchaseAttachmentInputRef.current) {
        if (type === "image")
          purchaseAttachmentInputRef.current.accept = "image/*";
        else if (type === "video")
          purchaseAttachmentInputRef.current.accept = "video/*";
        else if (type === "voice")
          purchaseAttachmentInputRef.current.accept = "audio/*";
        else purchaseAttachmentInputRef.current.accept = "*/*";
        purchaseAttachmentInputRef.current.click();
      }
    }, 10);
  };

  React.useEffect(() => {
    setBtnTextBuyNew(settings.btnTextBuyNew || "🛒 خرید اشتراک جدید");
    setHideBtnBuyNew(!!settings.hideBtnBuyNew);
    setBtnTextMySubs(settings.btnTextMySubs || "🗂 سرویس‌های من / تمدید");
    setHideBtnMySubs(!!settings.hideBtnMySubs);
    setBtnTextGuides(settings.btnTextGuides || "💡 راهنما");
    setHideBtnGuides(!!settings.hideBtnGuides);
    setBtnTextProfile(settings.btnTextProfile || "👤 حساب کاربری");
    setHideBtnProfile(!!settings.hideBtnProfile);
    setBtnTextSupport(settings.btnTextSupport || "📞 پشتیبانی");
    setHideBtnSupport(!!settings.hideBtnSupport);
    setBtnTextTicketSupport(settings.btnTextTicketSupport || "🎫 تیکت پشتیبانی");
    setHideBtnTicketSupport(!!settings.hideBtnTicketSupport);
    setBtnTextFreeTest(settings.btnTextFreeTest || "🎁 تست رایگان");
    setHideBtnFreeTest(!!settings.hideBtnFreeTest);
    setBtnTextInstantSupport(settings.btnTextInstantSupport || "🤖 پشتیبانی آنی");
    setHideBtnInstantSupport(!!settings.hideBtnInstantSupport);
    setBtnTextFeedback(settings.btnTextFeedback || "💌 نظرات کاربران");
    setHideBtnFeedback(!!settings.hideBtnFeedback);
    setBtnTextWallet(settings.btnTextWallet || "💵 کیف پول + شارژ");
    setHideBtnWallet(!!settings.hideBtnWallet);
    setBtnTextReferral(settings.btnTextReferral || "👥 زیرمجموعه‌گیری");
    setHideBtnReferral(!!settings.hideBtnReferral);
    setBtnTextColleagues(settings.btnTextColleagues || "پنل ویژه همکاران");
    setHideBtnColleagues(settings.hideBtnColleagues !== undefined ? settings.hideBtnColleagues : true);
    setBtnTextAiChat(settings.btnTextAiChat || "🤖 چت هوشمند");
    setHideBtnAiChat(settings.hideBtnAiChat !== undefined ? settings.hideBtnAiChat : true);
    setBtnTextAi(settings.btnTextAi || "🧠 هوش مصنوعی");
    setHideBtnAi(settings.hideBtnAi !== undefined ? settings.hideBtnAi : true);
    setBtnTextAddConfig(settings.btnTextAddConfig || "➕ افزودن کانفیگ به ربات");
    setHideBtnAddConfig(!!settings.hideBtnAddConfig);
    setBtnTextConfigDetails(settings.btnTextConfigDetails || "📊 مشخصات کانفیگ");
    setHideBtnConfigDetails(!!settings.hideBtnConfigDetails);
    setBtnTextSearchConfig(settings.btnTextSearchConfig || "🔍 سرچ کانفیگ (مدیریت)");
    setHideBtnSearchConfig(!!settings.hideBtnSearchConfig);
    setKeyboardLayout(settings.keyboardLayout || "stepped");
    setGuidesText(settings.guidesText || "");
    setGuideVideoHapp(settings.guideVideoHapp || "");
    setGuideVideoIos(settings.guideVideoIos || "");
    setGuideVideoAndroid(settings.guideVideoAndroid || "");
    setGuideVideoV2rayn(settings.guideVideoV2rayn || "");
    setGuideVideoKaring(settings.guideVideoKaring || "");
    setGuideVideoMac(settings.guideVideoMac || "");
    setGuideVideoLinux(settings.guideVideoLinux || "");
    if (settings.walletChargeAmounts && Array.isArray(settings.walletChargeAmounts)) {
      setWalletChargeAmounts(settings.walletChargeAmounts);
    }
    if (settings.mainButtonsOrder && settings.mainButtonsOrder.length > 0) {
      const saved = [...settings.mainButtonsOrder];
      defaultOrder.forEach((key) => {
        if (!saved.includes(key)) {
          saved.push(key);
        }
      });
      setMainButtonsOrder(saved);
    } else {
      setMainButtonsOrder(defaultOrder);
    }
    setUsePremiumEmojis(settings.usePremiumEmojis !== undefined ? settings.usePremiumEmojis : false);
    setUseButtonColors(settings.useButtonColors !== undefined ? settings.useButtonColors : false);
        setPrimaryButtonColors(settings.primaryButtonColors || {});
    setExtraButtonColors(settings.extraButtonColors || (settings.buttonStylesMapping ? Object.entries(settings.buttonStylesMapping).flatMap(([color, words]) => words.map(w => ({keyword: w, color}))) : []));
    setPremiumEmojiList(settings.premiumEmojiList || (settings.premiumEmojiMapping ? Object.entries(settings.premiumEmojiMapping).map(([k, v]) => ({emoji: k, customId: v})) : defaultEmojis));
    setSupportHandle(settings.supportHandle || "");
    setWelcomeText(settings.welcomeText || "");
    setSupportText(settings.supportText || "");
    setPinnedMessageText(settings.pinnedMessageText || "");
    setPinnedMessageActive(!!settings.pinnedMessageActive);
    setPurchaseSuccessNote(settings.purchaseSuccessNote || "");
    setActivePurchaseAttachment(settings.purchaseSuccessAttachment || null);
  }, [settings]);

  // Add/Edit Button Handler
  const handleAddButton = async (e: React.MouseEvent) => {
    e.preventDefault();
    setButtonError("");
    setButtonSuccess(false);

    if (!btnText.trim()) {
      setButtonError(
        translateText("Button text cannot be empty.", "عنوان دکمه نمی‌تواند خالی باشد.", lang),
      );
      return;
    }
    if (!btnReplyText.trim()) {
      setButtonError(
        translateText("Bot reply response text cannot be empty.", "پاسخ ربات نمی‌تواند خالی باشد.", lang),
      );
      return;
    }

    // Check duplicates but exclude current editing button
    if (
      customButtons.some(
        (b) => b.text === btnText.trim() && b.id !== editingButtonId,
      )
    ) {
      setButtonError(
        translateText("A button with this exact label already exists.", "این دکمه قبلاً ایجاد شده است.", lang),
      );
      return;
    }

    const buttonIdToUse =
      editingButtonId || Math.random().toString(36).substring(2, 9);
    const targetBtn: CustomButton = {
      id: buttonIdToUse,
      text: btnText.trim(),
      replyText: btnReplyText.trim(),
    };

    try {
      const response = await fetch("/api/custom-buttons", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(targetBtn),
      });
      if (response.ok) {
        if (editingButtonId) {
          setCustomButtons((prev) =>
            prev.map((b) => (b.id === editingButtonId ? targetBtn : b)),
          );
          setEditingButtonId(null);
        } else {
          setCustomButtons((prev) => [...prev, targetBtn]);
        }
        setBtnText("");
        setBtnReplyText("");
        setButtonSuccess(true);
        setTimeout(() => setButtonSuccess(false), 3000);
      } else {
        setButtonError(
          translateText("Failed to sync with the database.", "خطا در برقراری ارتباط با دیتابیس.", lang),
        );
      }
    } catch (err) {
      setButtonError(
        translateText("Network connection failed.", "خطا در برقراری ارتباط با سرور.", lang),
      );
    }
  };

  // Delete Button Handler
  const handleDeleteButton = async (id: string) => {
    try {
      const response = await fetch("/api/custom-buttons/delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      if (response.ok) {
        setCustomButtons((prev) => prev.filter((b) => b.id !== id));
      }
    } catch (err) {
      console.error("Failed to delete button:", err);
    }
  };

  // Move button up or down
  const moveButton = (index: number, direction: "up" | "down") => {
    const newButtons = [...customButtons];
    if (direction === "up" && index > 0) {
      [newButtons[index], newButtons[index - 1]] = [
        newButtons[index - 1],
        newButtons[index],
      ];
    } else if (direction === "down" && index < newButtons.length - 1) {
      [newButtons[index], newButtons[index + 1]] = [
        newButtons[index + 1],
        newButtons[index],
      ];
    }
    setCustomButtons(newButtons);
  };

  const moveMainButton = (index: number, direction: "up" | "down") => {
    const newOrder = [...mainButtonsOrder];
    if (direction === "up" && index > 0) {
      [newOrder[index], newOrder[index - 1]] = [
        newOrder[index - 1],
        newOrder[index],
      ];
    } else if (direction === "down" && index < newOrder.length - 1) {
      [newOrder[index], newOrder[index + 1]] = [
        newOrder[index + 1],
        newOrder[index],
      ];
    }
    setMainButtonsOrder(newOrder);
  };

  const getPayload = () => {
    const newButtonStylesMapping: Record<string, string[]> = {
      success: [], danger: [], primary: []
    };
    
    extraButtonColors.forEach(item => {
      if (item.keyword && item.color && item.color !== 'none') {
        if (!newButtonStylesMapping[item.color]) newButtonStylesMapping[item.color] = [];
        if (!newButtonStylesMapping[item.color].includes(item.keyword)) {
            newButtonStylesMapping[item.color].push(item.keyword);
        }
      }
    });
    
    const primaryBtns = { btnBuyNew: btnTextBuyNew, btnMySubs: btnTextMySubs, btnAddConfig: btnTextAddConfig, btnConfigDetails: btnTextConfigDetails, btnSearchConfig: btnTextSearchConfig, btnGuides: btnTextGuides, btnProfile: btnTextProfile, btnSupport: btnTextSupport, btnTicketSupport: btnTextTicketSupport, btnFreeTest: btnTextFreeTest, btnInstantSupport: btnTextInstantSupport, btnFeedback: btnTextFeedback, btnReferral: btnTextReferral, btnWallet: btnTextWallet, btnColleagues: btnTextColleagues, btnAiChat: btnTextAiChat, btnAi: btnTextAi, btnMiniApp: btnTextMiniApp, btnDashSimple: btnTextDashSimple, btnDashPro: btnTextDashPro };
    Object.entries(primaryBtns).forEach(([key, val]) => {
      const col = primaryButtonColors[key];
      if (col && col !== 'none') {
         if (!newButtonStylesMapping[col]) newButtonStylesMapping[col] = [];
         if (!newButtonStylesMapping[col].includes(val)) {
             newButtonStylesMapping[col].push(val);
         }
      }
    });
    
    const newEmojiMapping: Record<string, string> = {};
    premiumEmojiList.forEach(item => {
      if (item.emoji && item.customId) {
        newEmojiMapping[item.emoji] = item.customId;
      }
    });

    return {
      ...settings,
      primaryButtonColors,
      extraButtonColors,
      premiumEmojiList,
      usePremiumEmojis,
      useButtonColors,
      buttonStylesMapping: newButtonStylesMapping,
      premiumEmojiMapping: newEmojiMapping,
      btnTextBuyNew,
      btnTextMySubs,
      btnTextGuides,
      btnTextProfile,
      btnTextSupport,
      btnTextTicketSupport,
      btnTextFreeTest,
      btnTextInstantSupport,
      btnTextFeedback,
      btnTextReferral,
      btnTextWallet,
      btnTextColleagues,
      btnTextAiChat,
      btnTextAi,
      btnTextAddConfig,
      btnTextConfigDetails,
      btnTextSearchConfig,
      useMiniAppMode: startCommandMode !== "buttons",
      startCommandMode,
      btnTextMiniApp: btnTextDashPro || btnTextMiniApp,
      btnTextDashSimple,
      btnTextDashPro,
      dashButtonsLayout,
      dashButtonsOrder,
      hideBtnDashSimple,
      hideBtnDashPro,
      miniAppUrl,
      hideBtnMiniApp,
      miniAppSplashLogo,
      miniAppSplashEnabled,
      hideBtnBuyNew,
      hideBtnMySubs,
      hideBtnGuides,
      hideBtnProfile,
      hideBtnSupport,
      hideBtnTicketSupport,
      hideBtnFreeTest,
      hideBtnInstantSupport,
      hideBtnFeedback,
      hideBtnReferral,
      hideBtnWallet,
      hideBtnColleagues,
      hideBtnAiChat,
      hideBtnAi,
      hideBtnAddConfig,
      hideBtnConfigDetails,
      hideBtnSearchConfig,
      keyboardLayout,
      mainButtonsOrder,
      singleButtons,
      walletChargeAmounts,
      guideVideoHapp,
      guideVideoIos,
      guideVideoAndroid,
      guideVideoV2rayn,
      guideVideoKaring,
      guideVideoMac,
      guideVideoLinux,
      guidesText,
      supportText,
      welcomeText,
      supportHandle,
      pinnedMessageText,
      pinnedMessageActive,
      purchaseSuccessNote,
      purchaseSuccessAttachment: activePurchaseAttachment,
    };
  };

  // Main Form Submit Handler (Saves primary button labels and layout)
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (typeof localStorage !== "undefined") {
      try {
        localStorage.setItem("daltoon_mini_app_splash_logo", miniAppSplashLogo || "");
        localStorage.setItem("daltoon_mini_app_splash_enabled", String(miniAppSplashEnabled));
      } catch (e) {}
    }
    onSaveSettings(getPayload());
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div
      id="bot-buttons-tab"
      className="max-w-4xl mx-auto space-y-6 animate-fade-in"
    >
      {/* Header Info */}
      <div className="bg-[#111827] border border-[#1f2937] p-5 rounded-xl space-y-4 shadow-sm">
        <h3 className="font-display font-medium text-lg text-white flex items-center gap-2">
          <Command className="w-5 h-5 text-indigo-400" />
          {translateText("Telegram Bot Menu & Buttons Management", "مدیریت دکمه‌ها و منوهای ربات تلگرام", lang)}
        </h3>
        <p className="text-xs text-gray-400 leading-relaxed">
          {translateText("In this interface, you can manage the layout, hierarchy, and labels of the Telegram bot's main keyboard menus. You can also define automated-reply custom buttons to offer features such as free test accounts, guides, or rules.", "در این پنجره می‌توانید ترتیب، چیدمان و نام تمام دکمه‌های کیبورد ربات تلگرام را ویرایش کنید. همچنین امکان ساخت دکمه‌های پاسخ خودکار جدید برای ارائه‌ی خدماتی نظیر اکانت تست یا برگه قوانین وجود دارد.", lang)}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Layout & Primary Labels section */}
        <div className="bg-[#111827] border border-[#1f2937] p-5 rounded-xl space-y-6">
          <div className="flex items-center gap-3 border-b border-gray-800 pb-3">
            <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400">
              <Columns className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-display font-medium text-base text-white">
                {translateText("Primary Keyboard Layout & Labels", "چیدمان و عناوین کیبورد اصلی", lang)}
              </h4>
              <p className="text-xs text-gray-400">
                {translateText("Configure keyboard spacing structures and edit text labels.", "پیکربندی چیدمان ظاهری دکمه‌ها و ویرایش برچسب‌های متنی منوی اصلی.", lang)}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Keyboard Layout pattern Selector */}
            <div className="space-y-2 bg-[#090d16] p-4 border border-gray-800/60 rounded-xl flex flex-col justify-between">
              <div>
                <label className="block text-xs uppercase tracking-wider text-gray-400 font-semibold mb-1">
                  {translateText("📐 Main Keyboard Layout Type", "📐 چیدمان دکمه‌های اصلی کیبورد", lang)}
                </label>
                <p className="text-[11px] text-gray-500 mb-4">
                  {translateText("Determines how the primary bot buttons stack on Telegram messenger.", "نحوه‌ی نمایش و قرارگیری دکمه‌های اصلی در تلگرام را تعیین کنید.", lang)}
                </p>
              </div>

              <div className="grid grid-cols-3 gap-2.5">
                {(["stepped", "horizontal", "vertical"] as const).map(
                  (style) => (
                    <button
                      key={style}
                      type="button"
                      onClick={() => setKeyboardLayout(style)}
                      className={`p-3 rounded-lg border text-center transition cursor-pointer text-xs font-semibold capitalize ${
                        keyboardLayout === style
                          ? "bg-indigo-600/15 border-indigo-500 text-indigo-300"
                          : "bg-gray-900 border-gray-800 text-gray-400 hover:text-white hover:border-gray-700"
                      }`}
                    >
                      {style === "stepped" &&
                        (translateText("Stepped", "پله‌ای", lang))}
                      {style === "horizontal" &&
                        (translateText("Horizontal", "افقی", lang))}
                      {style === "vertical" &&
                        (translateText("Vertical", "عمودی", lang))}
                    </button>
                  ),
                )}
              </div>
            </div>

            {/* Hidden toggle options or quick notes */}
            <div className="bg-[#090d16] p-4 border border-gray-800/60 rounded-xl space-y-3 justify-center flex flex-col">
              <span className="block text-xs uppercase tracking-wider text-gray-400 font-semibold mb-1">
                {translateText("ℹ️ Layout Guidelines", "ℹ️ راهنمای چیدمان", lang)}
              </span>
              <p className="text-[11px] text-gray-400 leading-relaxed whitespace-pre-line">
                {translateText("• Stepped: The first key takes standard full width, other keys follow grouped in pairs (default).\n• Horizontal: Arranges all action inputs side-by-side in columns.\n• Vertical: Extends all keys across full width on separate lines.", "• چیدمان پله‌ای: دکمه اول بزرگتر در ردیف بالا قرار می‌گیرد و سایر دکمه‌ها منظم در کنار هم قرار می‌گیرند (پیش‌فرض).\n• چیدمان افقی: دکمه‌ها دو به دو روبروی هم چیده می‌شوند.\n• چیدمان عمودی: هر دکمه در یک ردیف جداگانه و بزرگ نمایش داده می‌شود.", lang)}
              </p>
            </div>
          </div>

          {/* Bot Features Toggles (Premium Emojis & Colored Buttons) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#0a0e17] p-4 border border-gray-800/60 rounded-xl">
            <div className="flex items-center justify-between p-3 bg-[#111827] rounded-lg border border-gray-800/40">
              <div className="flex flex-col gap-1">
                <span className="text-sm font-medium text-white">
                  {translateText("Enable Telegram Premium Emojis", "استفاده از ایموجی‌های پریمیوم تلگرام", lang)}
                </span>
                <span className="text-[10px] text-gray-400">
                  {translateText("Use premium/animated emojis in panels and menus", "نمایش ایموجی‌های پریمیوم متحرک در پنل‌ها و منوهای ربات", lang)}
                </span>
                <span className="text-[10px] text-amber-400/90 leading-tight mt-1">
                  {translateText("ℹ️ To retrieve premium emoji IDs, you can refer to the @ShowJsonBot bot.", "ℹ️ جهت دریافت شناسه ایموجی‌های پریمیوم می‌توانید به ربات @ShowJsonBot مراجعه کنید.", lang)}
                </span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={usePremiumEmojis}
                  onChange={(e) => setUsePremiumEmojis(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-10 h-5 bg-gray-700 rounded-full peer peer-focus:ring-1 peer-focus:ring-indigo-500 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
              </label>
            </div>

            <div className="flex items-center justify-between p-3 bg-[#111827] rounded-lg border border-gray-800/40">
              <div className="flex flex-col gap-1">
                <span className="text-sm font-medium text-white">
                  {translateText("Enable Colored Bot Buttons", "دکمه‌های رنگی ربات", lang)}
                </span>
                <span className="text-[10px] text-gray-400">
                  {translateText("Render custom colors for Telegram bot keyboard buttons", "فعال‌سازی رنگ‌های سفارشی برای دکمه‌های کیبورد ربات تلگرام", lang)}
                </span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={useButtonColors}
                  onChange={(e) => setUseButtonColors(e.target.checked)}
                  className="sr-only peer"
                />
                <div className="w-10 h-5 bg-gray-700 rounded-full peer peer-focus:ring-1 peer-focus:ring-indigo-500 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
              </label>
            </div>
          </div>

          {/* Telegram WebApp / Start Command Mode Card */}
          <div className="bg-[#0a0e17] p-4 border border-indigo-500/30 rounded-xl space-y-4 shadow-lg shadow-indigo-950/20">
            <div className="flex items-center justify-between pb-3 border-b border-gray-800/80">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-indigo-500/20 text-indigo-400 rounded-xl border border-indigo-500/30">
                  <Globe className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <span>{translateText("Telegram WebApp / Mini App Mode", "تنظیمات مینی‌اپ (Telegram WebApp Mode)", lang)}</span>
                    <span className="text-[10px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 px-2 py-0.5 rounded-full font-medium">
                      {useMiniAppMode ? translateText("Active", "فعال", lang) : translateText("Disabled", "خاموش", lang)}
                    </span>
                  </h4>
                  <p className="text-[11px] text-gray-400 mt-0.5">
                    {translateText("Enable MiniApp functionality and select behavior on /start", "فعالسازی قابلیت مینی‌اپ و انتخاب رفتار ربات هنگام ارسال استارت (/start)", lang)}
                  </p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={useMiniAppMode}
                  onChange={(e) => {
                    const checked = e.target.checked;
                    setUseMiniAppMode(checked);
                    if (!checked) {
                      setStartCommandMode("buttons");
                    } else {
                      setStartCommandMode("miniapp");
                    }
                  }}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-gray-700 rounded-full peer peer-focus:ring-1 peer-focus:ring-indigo-500 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
              </label>
            </div>

            {useMiniAppMode ? (
              <div className="space-y-4 animate-fadeIn">
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-gray-300 block">
                    {translateText("Select MiniApp Behavior on /start", "انتخاب رفتار مینی‌اپ هنگام استارت (/start):", lang)}
                  </label>

                  {/* 2 Sub-options when MiniApp is ON */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {/* Option 1: Direct Mini App */}
                    <button
                      type="button"
                      onClick={() => setStartCommandMode("miniapp")}
                      className={`p-3.5 rounded-xl border text-right transition-all flex flex-col justify-between space-y-2 relative overflow-hidden ${
                        startCommandMode === "miniapp"
                          ? "bg-indigo-950/40 border-indigo-500 text-white shadow-md shadow-indigo-950/50 ring-1 ring-indigo-500"
                          : "bg-[#111827]/80 border-gray-800 text-gray-400 hover:border-gray-700 hover:text-gray-200"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="p-1.5 bg-indigo-500/20 text-indigo-400 rounded-lg">
                          <Globe className="w-4 h-4" />
                        </div>
                        {startCommandMode === "miniapp" && (
                          <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 animate-pulse"></span>
                        )}
                      </div>
                      <div>
                        <h5 className="text-xs font-bold text-white">
                          {translateText("1. Mini App Direct", "۱. ورود مستقیم به مینی‌اپ", lang)}
                        </h5>
                        <p className="text-[10px] text-gray-400 mt-1 leading-relaxed">
                          {translateText("Open Smart WebApp button is sent directly on /start.", "با ارسال استارت، مستقیماً دکمه ورود به برنامه هوشمند (مینی‌اپ) ارسال می‌شود.", lang)}
                        </p>
                      </div>
                    </button>

                    {/* Option 2: Dual Choice Question */}
                    <button
                      type="button"
                      onClick={() => setStartCommandMode("dual_choice")}
                      className={`p-3.5 rounded-xl border text-right transition-all flex flex-col justify-between space-y-2 relative overflow-hidden ${
                        startCommandMode === "dual_choice"
                          ? "bg-emerald-950/40 border-emerald-500 text-white shadow-md shadow-emerald-950/50 ring-1 ring-emerald-500"
                          : "bg-[#111827]/80 border-gray-800 text-gray-400 hover:border-gray-700 hover:text-gray-200"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="p-1.5 bg-emerald-500/20 text-emerald-400 rounded-lg">
                          <Sliders className="w-4 h-4" />
                        </div>
                        {startCommandMode === "dual_choice" && (
                          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                        )}
                      </div>
                      <div>
                        <h5 className="text-xs font-bold text-white">
                          {translateText("2. Dual Dashboard Choice Question", "۲. پرسش و انتخاب دوگانه (ساده و حرفه‌ای)", lang)}
                        </h5>
                        <p className="text-[10px] text-gray-400 mt-1 leading-relaxed">
                          {translateText("Greeting message asks user to choose between Simple & Pro dashboards. Clicking Pro directly opens MiniApp.", "ربات ابتدا سوال می‌پرسد و ۲ دکمه می‌فرستد. با کلیک روی «داشبورد حرفه‌ای»، مینی‌اپ مستقیماً باز می‌شود.", lang)}
                        </p>
                      </div>
                    </button>
                  </div>
                </div>

                <div className="p-3 bg-indigo-950/40 border border-indigo-500/30 rounded-xl text-xs text-indigo-300 flex items-center gap-2.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shrink-0"></span>
                  <span className="leading-relaxed">
                    {startCommandMode === "miniapp"
                      ? translateText(
                          "Direct MiniApp Mode Active: On /start, users directly receive the MiniApp button.",
                          "حالت ورود مستقیم مینی‌اپ فعال است: کاربر با ارسال /start مستقیماً دکمه مینی‌اپ را دریافت می‌کند.",
                          lang
                        )
                      : translateText(
                          "Dual Dashboard Choice Active: On /start, users choose between Simple Dashboard and Professional Dashboard. Tapping 'Professional Dashboard' directly opens the WebApp popup without extra steps.",
                          "حالت سوال دوگانه فعال است: با ارسال /start دو گزینه پیشنهاد می‌شود. کاربر با زدن روی «داشبورد حرفه‌ای» بدون هیچ مرحله اضافی مستقیماً وارد مینی‌اپ می‌شود.",
                          lang
                        )}
                  </span>
                </div>
              </div>
            ) : (
              /* When MiniApp switch is OFF */
              <div className="p-3.5 bg-[#111827]/90 border border-gray-800 rounded-xl text-xs text-gray-300 flex items-center gap-3">
                <div className="p-2 bg-blue-500/20 text-blue-400 rounded-lg shrink-0">
                  <Smartphone className="w-4 h-4" />
                </div>
                <div className="space-y-0.5">
                  <span className="font-semibold text-white block">
                    {translateText("Mode 1: Classic Buttons Direct (MiniApp Off)", "حالت ۱: نمایش مستقیم دکمه‌های عادی (مینی‌اپ خاموش)", lang)}
                  </span>
                  <span className="text-[11px] text-gray-400 block leading-relaxed">
                    {translateText(
                      "When disabled, standard glass bot buttons appear directly on /start without asking.",
                      "در این حالت، با ارسال /start توسط کاربر، دکمه‌های اصلی و شیشه‌ای ربات مستقیماً و بدون پرسش سوال نمایش داده می‌شوند.",
                      lang
                    )}
                  </span>
                </div>
              </div>
            )}

            {useMiniAppMode && (
              <div className="space-y-4 pt-1 animate-fadeIn">
                {startCommandMode === "miniapp" ? (
                  /* Mode 1: Direct Mini App Settings (Classic WebApp button configuration) */
                  <div className="p-4 bg-[#0f172a]/90 border border-indigo-500/30 rounded-xl space-y-4 relative overflow-hidden shadow-md">
                    <div className="flex items-center justify-between border-b border-indigo-500/20 pb-2.5">
                      <div className="flex items-center gap-2">
                        <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-lg">
                          <Globe className="w-4 h-4" />
                        </div>
                        <div>
                          <h5 className="text-xs font-bold text-white">
                            {translateText("Direct Mini App WebApp Button Settings", "تنظیمات دکمه ورود مستقیم به مینی‌اپ", lang)}
                          </h5>
                          <p className="text-[10px] text-gray-400 mt-0.5">
                            {translateText("Configure title, color, and WebApp URL sent directly on /start", "تنظیم اسم دکمه، رنگ و آدرس وب‌اپ که با ارسال استارت مستقیماً ارسال می‌شود", lang)}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {/* Button Title */}
                      <div className="space-y-1.5">
                        <label className="text-[11px] font-medium text-gray-300 block">
                          {translateText("Button Title & Emoji", "اسم و شکلک دکمه مینی‌اپ", lang)}
                        </label>
                        <input
                          type="text"
                          className="w-full bg-[#111827] border border-gray-700/80 rounded-lg px-3 py-2 text-xs text-white focus:ring-1 focus:ring-indigo-500 font-medium"
                          value={btnTextMiniApp}
                          onChange={(e) => {
                            setBtnTextMiniApp(e.target.value);
                            setBtnTextDashPro(e.target.value);
                          }}
                          placeholder="🚀 ورود به برنامه هوشمند"
                        />
                      </div>

                      {/* Button Color */}
                      <div className="space-y-1.5">
                        <label className="text-[11px] font-medium text-gray-300 block">
                          {translateText("Button Color Style", "رنگ و استایل دکمه", lang)}
                        </label>
                        <CustomSelect
                          value={primaryButtonColors["btnMiniApp"] || primaryButtonColors["btnDashPro"] || "none"}
                          onChange={(val) =>
                            setPrimaryButtonColors({
                              ...primaryButtonColors,
                              btnMiniApp: val,
                              btnDashPro: val,
                            })
                          }
                          options={[
                            { value: "none", label: translateText("No Color (Default)", "بدون رنگ (عادی)", lang) },
                            { value: "primary", label: translateText("Blue (Primary)", "🔵 آبی (اصلی)", lang) },
                            { value: "success", label: translateText("Green (Success)", "🟢 سبز (موفقیت)", lang) },
                            { value: "danger", label: translateText("Red (Warning/Danger)", "🔴 قرمز (هشدار)", lang) },
                          ]}
                          title={translateText("Button Color Style", "رنگ و استایل دکمه", lang)}
                          dir={lang === "fa" ? "rtl" : "ltr"}
                        />
                      </div>
                    </div>

                    {/* WebApp URL */}
                    <div className="space-y-1.5">
                      <label className="text-[11px] font-medium text-gray-300 block">
                        {translateText("Mini App Web URL", "آدرس مینی‌اپ (Telegram WebApp URL)", lang)}
                      </label>
                      <input
                        type="text"
                        className="w-full bg-[#111827] border border-gray-700/80 rounded-lg px-3 py-2 text-xs text-white focus:ring-1 focus:ring-indigo-500 font-mono"
                        value={miniAppUrl}
                        onChange={(e) => setMiniAppUrl(e.target.value)}
                        placeholder={translateText("https://your-domain.com/miniapp (Empty = auto-detect)", "مثلا https://domain.com/miniapp (خالی بگذارید تا از آدرس پنل استفاده شود)", lang)}
                      />
                    </div>

                    {/* Live Preview for Direct MiniApp */}
                    <div className="p-3 bg-[#0b1329] border border-indigo-500/20 rounded-xl space-y-2 mt-2">
                      <div className="flex items-center justify-between text-[11px] text-gray-400">
                        <span className="font-semibold text-gray-300 flex items-center gap-1.5">
                          <Eye className="w-3.5 h-3.5 text-indigo-400" />
                          {translateText("Live Telegram Preview", "پیش‌نمایش زنده دکمه مینی‌اپ در تلگرام", lang)}
                        </span>
                      </div>

                      <div className="p-3 bg-[#17212b] rounded-lg border border-gray-800 text-xs font-medium space-y-2 shadow-inner">
                        <p className="text-[11px] text-gray-300 leading-relaxed border-b border-gray-700/50 pb-2">
                          👋 سلام کاربر گرامی! برای ورود به برنامه روی دکمه زیر کلیک کنید:
                        </p>
                        <div
                          className={`w-full py-2.5 px-3 rounded-md text-center border font-semibold transition-all shadow-sm ${
                            (primaryButtonColors["btnMiniApp"] || primaryButtonColors["btnDashPro"]) === "success"
                              ? "bg-emerald-600/30 border-emerald-500/60 text-emerald-300"
                              : (primaryButtonColors["btnMiniApp"] || primaryButtonColors["btnDashPro"]) === "danger"
                              ? "bg-rose-600/30 border-rose-500/60 text-rose-300"
                              : (primaryButtonColors["btnMiniApp"] || primaryButtonColors["btnDashPro"]) === "primary"
                              ? "bg-blue-600/30 border-blue-500/60 text-blue-300"
                              : "bg-[#242f3d] border-gray-600 text-cyan-300"
                          }`}
                        >
                          {btnTextMiniApp || "🚀 ورود به برنامه هوشمند"}
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Mode 2: Dual Choice Question Settings & Cards */
                  <>
                    {/* Grid for Button 1 (Simple) & Button 2 (Pro) */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                      {/* Card 1: Simple Dashboard Button */}
                      <div className="p-3.5 bg-[#0f172a]/90 border border-emerald-500/30 rounded-xl space-y-3 relative overflow-hidden">
                        <div className="flex items-center justify-between border-b border-emerald-500/20 pb-2">
                          <div className="flex items-center gap-2">
                            <div className="p-1.5 bg-emerald-500/20 text-emerald-400 rounded-lg">
                              <Smartphone className="w-4 h-4" />
                            </div>
                            <h5 className="text-xs font-bold text-white">
                              {translateText("Button 1: Simple Dashboard", "دکمه ۱: داشبورد ساده", lang)}
                            </h5>
                          </div>
                          <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-gray-300">
                            <input
                              type="checkbox"
                              checked={!hideBtnDashSimple}
                              onChange={(e) => setHideBtnDashSimple(!e.target.checked)}
                              className="rounded border-gray-700 bg-gray-900 text-emerald-500 focus:ring-emerald-500/40 w-3.5 h-3.5"
                            />
                            <span>{translateText("Show Button", "نمایش دکمه", lang)}</span>
                          </label>
                        </div>

                        <div className="space-y-1.5">
                          <label className="text-[11px] font-medium text-gray-300 block">
                            {translateText("Title & Emoji", "اسم و شکلک دکمه", lang)}
                          </label>
                          <input
                            type="text"
                            className="w-full bg-[#111827] border border-gray-700/80 rounded-lg px-3 py-2 text-xs text-white focus:ring-1 focus:ring-emerald-500 font-medium"
                            value={btnTextDashSimple}
                            onChange={(e) => setBtnTextDashSimple(e.target.value)}
                            placeholder="📱 داشبورد ساده"
                          />
                        </div>

                        <div className="space-y-1.5">
                          <label className="text-[11px] font-medium text-gray-300 block">
                            {translateText("Button Color Style", "رنگ و استایل دکمه", lang)}
                          </label>
                          <CustomSelect
                            value={primaryButtonColors["btnDashSimple"] || "none"}
                            onChange={(val) => setPrimaryButtonColors({ ...primaryButtonColors, btnDashSimple: val })}
                            options={[
                              { value: "none", label: translateText("No Color (Default)", "بدون رنگ (عادی)", lang) },
                              { value: "success", label: translateText("Green (Success)", "🟢 سبز (موفقیت)", lang) },
                              { value: "primary", label: translateText("Blue (Primary)", "🔵 آبی (اصلی)", lang) },
                              { value: "danger", label: translateText("Red (Warning/Danger)", "🔴 قرمز (هشدار)", lang) },
                            ]}
                            title={translateText("Button Color Style", "رنگ و استایل دکمه", lang)}
                            dir={lang === "fa" ? "rtl" : "ltr"}
                          />
                        </div>
                      </div>

                      {/* Card 2: Pro Dashboard Button */}
                      <div className="p-3.5 bg-[#0f172a]/90 border border-indigo-500/30 rounded-xl space-y-3 relative overflow-hidden">
                        <div className="flex items-center justify-between border-b border-indigo-500/20 pb-2">
                          <div className="flex items-center gap-2">
                            <div className="p-1.5 bg-indigo-500/20 text-indigo-400 rounded-lg">
                              <Globe className="w-4 h-4" />
                            </div>
                            <h5 className="text-xs font-bold text-white">
                              {translateText("Button 2: Professional Dashboard (Mini App)", "دکمه ۲: داشبورد حرفه‌ای (مینی‌اپ)", lang)}
                            </h5>
                          </div>
                          <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-gray-300">
                            <input
                              type="checkbox"
                              checked={!hideBtnDashPro}
                              onChange={(e) => setHideBtnDashPro(!e.target.checked)}
                              className="rounded border-gray-700 bg-gray-900 text-indigo-500 focus:ring-indigo-500/40 w-3.5 h-3.5"
                            />
                            <span>{translateText("Show Button", "نمایش دکمه", lang)}</span>
                          </label>
                        </div>

                        <div className="space-y-1.5">
                          <label className="text-[11px] font-medium text-gray-300 block">
                            {translateText("Title & Emoji", "اسم و شکلک دکمه", lang)}
                          </label>
                          <input
                            type="text"
                            className="w-full bg-[#111827] border border-gray-700/80 rounded-lg px-3 py-2 text-xs text-white focus:ring-1 focus:ring-indigo-500 font-medium"
                            value={btnTextDashPro}
                            onChange={(e) => {
                              setBtnTextDashPro(e.target.value);
                              setBtnTextMiniApp(e.target.value);
                            }}
                            placeholder="🚀 داشبورد حرفه‌ای"
                          />
                        </div>

                        <div className="space-y-1.5">
                          <label className="text-[11px] font-medium text-gray-300 block">
                            {translateText("Button Color Style", "رنگ و استایل دکمه", lang)}
                          </label>
                          <CustomSelect
                            value={primaryButtonColors["btnDashPro"] || primaryButtonColors["btnMiniApp"] || "none"}
                            onChange={(val) => setPrimaryButtonColors({ ...primaryButtonColors, btnDashPro: val, btnMiniApp: val })}
                            options={[
                              { value: "none", label: translateText("No Color (Default)", "بدون رنگ (عادی)", lang) },
                              { value: "primary", label: translateText("Blue (Primary)", "🔵 آبی (اصلی)", lang) },
                              { value: "success", label: translateText("Green (Success)", "🟢 سبز (موفقیت)", lang) },
                              { value: "danger", label: translateText("Red (Warning/Danger)", "🔴 قرمز (هشدار)", lang) },
                            ]}
                            title={translateText("Button Color Style", "رنگ و استایل دکمه", lang)}
                            dir={lang === "fa" ? "rtl" : "ltr"}
                          />
                        </div>

                        <div className="space-y-1.5">
                          <label className="text-[11px] font-medium text-gray-300 block">
                            {translateText("Mini App Web URL", "آدرس مینی‌اپ (Telegram WebApp URL)", lang)}
                          </label>
                          <input
                            type="text"
                            className="w-full bg-[#111827] border border-gray-700/80 rounded-lg px-3 py-2 text-xs text-white focus:ring-1 focus:ring-indigo-500 font-mono"
                            value={miniAppUrl}
                            onChange={(e) => setMiniAppUrl(e.target.value)}
                            placeholder={translateText("https://your-domain.com/miniapp (Empty = auto-detect)", "مثلا https://domain.com/miniapp (خالی بگذارید تا از آدرس پنل استفاده شود)", lang)}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Layout Mode (Single vs Double) & Position/Order Controls */}
                    <div className="p-3.5 bg-[#0a0e17] border border-gray-800 rounded-xl space-y-3">
                      <h5 className="text-xs font-bold text-gray-200 flex items-center gap-2">
                        <Sliders className="w-4 h-4 text-indigo-400" />
                        <span>{translateText("Layout Mode & Button Placement Position", "تنظیمات چیدمان و جایگاه دکمه‌ها", lang)}</span>
                      </h5>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Single vs Double Row Choice */}
                        <div className="space-y-1.5">
                          <label className="text-[11px] font-medium text-gray-300 block">
                            {translateText("Button Row Layout Mode", "چیدمان دکمه‌ها (تکی یا دوتایی)", lang)}
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() => setDashButtonsLayout("single")}
                              className={`px-3 py-2 rounded-lg text-xs font-medium border flex items-center justify-center gap-1.5 transition-all ${
                                dashButtonsLayout === "single"
                                  ? "bg-indigo-600/30 border-indigo-500 text-indigo-200 shadow-sm shadow-indigo-950"
                                  : "bg-[#111827] border-gray-800 text-gray-400 hover:text-white"
                              }`}
                            >
                              <Layers className="w-3.5 h-3.5" />
                              <span>{translateText("Single (2 Rows)", "📱 تکی (۲ ردیف)", lang)}</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setDashButtonsLayout("double")}
                              className={`px-3 py-2 rounded-lg text-xs font-medium border flex items-center justify-center gap-1.5 transition-all ${
                                dashButtonsLayout === "double"
                                  ? "bg-indigo-600/30 border-indigo-500 text-indigo-200 shadow-sm shadow-indigo-950"
                                  : "bg-[#111827] border-gray-800 text-gray-400 hover:text-white"
                              }`}
                            >
                              <Grid2X2 className="w-3.5 h-3.5" />
                              <span>{translateText("Double (1 Row)", "📱 دوتایی (۱ ردیف)", lang)}</span>
                            </button>
                          </div>
                        </div>

                        {/* Order Choice */}
                        <div className="space-y-1.5">
                          <label className="text-[11px] font-medium text-gray-300 block">
                            {translateText("Button Position Priority", "جایگاه / اولویت نمایش دکمه‌ها", lang)}
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() => setDashButtonsOrder("simple_first")}
                              className={`px-3 py-2 rounded-lg text-xs font-medium border flex items-center justify-center gap-1.5 transition-all ${
                                dashButtonsOrder === "simple_first"
                                  ? "bg-emerald-600/30 border-emerald-500 text-emerald-200 shadow-sm shadow-emerald-950"
                                  : "bg-[#111827] border-gray-800 text-gray-400 hover:text-white"
                              }`}
                            >
                              <span>{translateText("Simple First", "⬅️ ساده اول", lang)}</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setDashButtonsOrder("pro_first")}
                              className={`px-3 py-2 rounded-lg text-xs font-medium border flex items-center justify-center gap-1.5 transition-all ${
                                dashButtonsOrder === "pro_first"
                                  ? "bg-indigo-600/30 border-indigo-500 text-indigo-200 shadow-sm shadow-indigo-950"
                                  : "bg-[#111827] border-gray-800 text-gray-400 hover:text-white"
                              }`}
                            >
                              <span>{translateText("Pro First", "➡️ حرفه‌ای اول", lang)}</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Live Interactive Telegram Button Preview */}
                    <div className="p-3.5 bg-[#0b1329] border border-indigo-500/20 rounded-xl space-y-2">
                      <div className="flex items-center justify-between text-[11px] text-gray-400">
                        <span className="font-semibold text-gray-300 flex items-center gap-1.5">
                          <Eye className="w-3.5 h-3.5 text-indigo-400" />
                          {translateText("Live Telegram Preview", "پیش‌نمایش زنده چیدمان دکمه‌ها در تلگرام", lang)}
                        </span>
                        <span className="text-[10px] text-indigo-300 bg-indigo-950/60 border border-indigo-500/30 px-2 py-0.5 rounded-md">
                          {dashButtonsLayout === "double" ? "۱ ردیف (دوتایی)" : "۲ ردیف (تکی)"} • {dashButtonsOrder === "simple_first" ? "اول ساده" : "اول حرفه‌ای"}
                        </span>
                      </div>

                      <div className="p-3 bg-[#17212b] rounded-lg border border-gray-800 text-xs font-medium space-y-2 shadow-inner">
                        <p className="text-[11px] text-gray-300 leading-relaxed border-b border-gray-700/50 pb-2">
                          👋 سلام کاربر گرامی! لطفاً نوع داشبورد خود را انتخاب کنید:
                        </p>

                        <div className={dashButtonsLayout === "double" ? "grid grid-cols-2 gap-2" : "space-y-2"}>
                          {(dashButtonsOrder === "simple_first"
                            ? [
                                { key: "simple", text: btnTextDashSimple, hide: hideBtnDashSimple, color: primaryButtonColors["btnDashSimple"] },
                                { key: "pro", text: btnTextDashPro, hide: hideBtnDashPro, color: primaryButtonColors["btnDashPro"] || primaryButtonColors["btnMiniApp"] }
                              ]
                            : [
                                { key: "pro", text: btnTextDashPro, hide: hideBtnDashPro, color: primaryButtonColors["btnDashPro"] || primaryButtonColors["btnMiniApp"] },
                                { key: "simple", text: btnTextDashSimple, hide: hideBtnDashSimple, color: primaryButtonColors["btnDashSimple"] }
                              ]
                          ).map((b) => {
                            if (b.hide) return null;
                            const colorClass =
                              b.color === "success"
                                ? "bg-emerald-600/30 border-emerald-500/60 text-emerald-300"
                                : b.color === "danger"
                                ? "bg-rose-600/30 border-rose-500/60 text-rose-300"
                                : b.color === "primary"
                                ? "bg-blue-600/30 border-blue-500/60 text-blue-300"
                                : "bg-[#242f3d] border-gray-600 text-cyan-300";

                            return (
                              <div
                                key={b.key}
                                className={`w-full py-2 px-3 rounded-md text-center border font-medium transition-all shadow-sm ${colorClass}`}
                              >
                                {b.text || (b.key === "simple" ? "📱 داشبورد ساده" : "🚀 داشبورد حرفه‌ای")}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {/* Splash Screen Logo Upload & Input for MiniApp */}
                <div className="bg-[#0b101d] border border-purple-500/30 p-4 rounded-xl space-y-4 mt-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#111827]/70 p-3 rounded-xl border border-gray-800">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 rounded-lg bg-purple-600/20 border border-purple-500/30 text-purple-400">
                        <ImageIcon className="w-4 h-4" />
                      </div>
                      <div>
                        <label className="text-xs font-bold text-white block">
                          {translateText("Mini App Loading Splash Logo", "🖼️ عکس پیش‌نمایش / لودینگ مینی‌اپ", lang)}
                        </label>
                        <span className="text-[11px] text-gray-400 block mt-0.5">
                          {miniAppSplashEnabled
                            ? translateText("Custom splash image is active", "عکس اختصاصی مینی‌اپ فعال است", lang)
                            : translateText("Default dashboard image is used", "عکس پیش‌فرض داشبورد نمایش داده می‌شود", lang)}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 self-end sm:self-auto">
                      {/* Switch Toggle Button */}
                      <button
                        type="button"
                        role="switch"
                        aria-checked={miniAppSplashEnabled}
                        dir="ltr"
                        onClick={() => {
                          const nextVal = !miniAppSplashEnabled;
                          setMiniAppSplashEnabled(nextVal);
                          if (typeof localStorage !== "undefined") {
                            try {
                              localStorage.setItem("daltoon_mini_app_splash_enabled", String(nextVal));
                            } catch (e) {}
                          }
                        }}
                        className={`relative inline-flex h-7 w-12 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                          miniAppSplashEnabled
                            ? "bg-emerald-500 shadow-md shadow-emerald-950/40"
                            : "bg-gray-700 hover:bg-gray-650"
                        }`}
                      >
                        <span className="sr-only">تغییر وضعیت عکس مینی اپ</span>
                        <span
                          className={`pointer-events-none inline-flex h-6 w-6 transform items-center justify-center rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                            miniAppSplashEnabled ? "translate-x-5" : "translate-x-0"
                          }`}
                        >
                          {miniAppSplashEnabled ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600 stroke-[3]" />
                          ) : (
                            <Power className="w-3 h-3 text-gray-400" />
                          )}
                        </span>
                      </button>

                      {miniAppSplashLogo && (
                        <button
                          type="button"
                          onClick={() => {
                            setMiniAppSplashLogo("");
                            setMiniAppSplashEnabled(false);
                            if (typeof localStorage !== "undefined") {
                              try {
                                localStorage.setItem("daltoon_mini_app_splash_logo", "");
                                localStorage.setItem("daltoon_mini_app_splash_enabled", "false");
                              } catch (e) {}
                            }
                          }}
                          className="text-[11px] text-rose-400 hover:text-rose-300 flex items-center gap-1 transition cursor-pointer px-2.5 py-1 rounded-lg hover:bg-rose-500/10 border border-transparent hover:border-rose-500/30"
                          title={translateText("Restore Default", "حذف و بازگردانی به پیش‌فرض", lang)}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>{translateText("Restore Default", "حذف", lang)}</span>
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="p-2.5 rounded-lg bg-purple-950/20 border border-purple-800/30 text-[11px] text-purple-200/90 leading-relaxed space-y-1">
                    <p>
                      {translateText(
                        "Configure the image shown strictly during Telegram Mini App loading. In case this is disabled or no image is uploaded, the default dashboard image (/icon.svg) will be used automatically.",
                        "این بخش منحصراً عکس پیش‌نمایش صفحه لودینگ مینی‌اپ را تنظیم می‌کند. در صورت خاموش بودن یا عدم آپلود، به صورت خودکار عکس پیش‌فرض داشبورد (/icon.svg) لود خواهد شد.",
                        lang
                      )}
                    </p>
                    <p className="text-[10px] text-purple-300/70 font-mono">
                      {translateText(
                        "ℹ️ Note: Main Dashboard preview is completely isolated and maintains its own fixed classic preview.",
                        "ℹ️ نکته: عکس پیش‌نمایش داشبورد همیشه مستقل بوده و تداخلی با عکس مینی‌اپ نخواهد داشت.",
                        lang
                      )}
                    </p>
                  </div>

                  {miniAppSplashEnabled && (
                    <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center pt-1">
                      <div className="flex-1 w-full">
                        <input
                          type="text"
                          placeholder="https://example.com/logo.png یا آپلود تصویر از دکمه روبرو..."
                          className="w-full bg-[#111827] border border-gray-700 rounded-lg p-2.5 text-xs text-purple-200 font-mono focus:ring-1 focus:ring-purple-500"
                          value={miniAppSplashLogo}
                          onChange={(e) => setMiniAppSplashLogo(e.target.value)}
                        />
                      </div>

                      <label className="px-3.5 py-2.5 bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-500/30 rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition shrink-0">
                        <Upload className="w-4 h-4" />
                        <span>{translateText("Upload Image", "آپلود تصویر", lang)}</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              const reader = new FileReader();
                              reader.onload = (ev) => {
                                if (ev.target?.result) {
                                  setMiniAppSplashLogo(String(ev.target.result));
                                  setMiniAppSplashEnabled(true);
                                }
                              };
                              reader.readAsDataURL(file);
                            }
                          }}
                        />
                      </label>
                    </div>
                  )}

                  {/* Live Preview of Splash Logo */}
                  <div className="pt-2 border-t border-gray-800/80">
                    <span className="text-[11px] font-medium text-gray-400 block mb-2">
                      {translateText("Live Mini App Loading Preview:", "پیش‌نمایش زنده صفحه لودینگ مینی‌اپ:", lang)}
                    </span>
                    <div className="bg-[#0d1117] border border-gray-800 rounded-2xl p-6 flex flex-col items-center justify-center space-y-3 relative overflow-hidden">
                      <div className="relative group">
                        <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 opacity-30 blur-md animate-pulse" />
                        <div className={`relative ${(miniAppSplashEnabled && miniAppSplashLogo.trim()) ? "bg-white p-2.5 rounded-2xl shadow-2xl" : ""}`}>
                          <img
                            src={(miniAppSplashEnabled && miniAppSplashLogo.trim()) ? miniAppSplashLogo.trim() : "/icon.svg"}
                            alt="Loading Splash Logo Preview"
                            className={`w-28 h-28 object-contain ${(miniAppSplashEnabled && miniAppSplashLogo.trim()) ? "rounded-xl" : "rounded-2xl shadow-2xl border border-white/10"}`}
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = "/icon.svg";
                            }}
                          />
                        </div>
                      </div>
                      <div className="text-center">
                        <span className="text-xs font-bold text-white tracking-wider font-mono uppercase block mb-1">
                          {(miniAppSplashEnabled && miniAppSplashLogo.trim())
                            ? (settings.botNickname?.trim() || "دالتون")
                            : "Telegram Daltoon Bot"}
                        </span>
                        <span className="text-[10px] text-gray-400 block">
                          {(miniAppSplashEnabled && miniAppSplashLogo.trim())
                            ? `✨ پیش‌نمایش با عکس اختصاصی + نام ربات (${settings.botNickname?.trim() || "دالتون"})`
                            : "🖼️ پیش‌نمایش با عکس پیش‌فرض داشبورد (/icon.svg)"}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Part A: Default Primary keyboard button labels */}
          <div className="space-y-3">
            <label className="block text-xs uppercase tracking-wider text-gray-400 font-semibold">
              {translateText("✍️ Custom Primary Keyboard Button Labels", "✍️ برچسب متنی دکمه‌های اصلی کیبورد", lang)}
            </label>
            <div className="grid grid-cols-1 gap-4 bg-[#0a0e17] p-4 border border-gray-800/60 rounded-xl">
              {(() => {
                const primaryButtonsDefinition: Record<
                  string,
                  {
                    label: string;
                    value: string;
                    setter: (val: string) => void;
                    disabled: boolean;
                    toggleDisabled: () => void;
                  }
                > = {
                  btnBuyNew: {
                    label:
                      translateText("Buy Sub Button Label", "عنوان دکمه خرید اشتراک", lang),
                    value: btnTextBuyNew,
                    setter: setBtnTextBuyNew,
                    disabled: hideBtnBuyNew,
                    toggleDisabled: () => setHideBtnBuyNew(!hideBtnBuyNew),
                  },
                  btnMySubs: {
                    label:
                      translateText("My Subs Button Label", "عنوان دکمه اشتراک‌ها", lang),
                    value: btnTextMySubs,
                    setter: setBtnTextMySubs,
                    disabled: hideBtnMySubs,
                    toggleDisabled: () => setHideBtnMySubs(!hideBtnMySubs),
                  },
                  btnGuides: {
                    label:
                      translateText("Connection Guide Button Label", "عنوان دکمه راهنمای اتصال", lang),
                    value: btnTextGuides,
                    setter: setBtnTextGuides,
                    disabled: hideBtnGuides,
                    toggleDisabled: () => setHideBtnGuides(!hideBtnGuides),
                  },
                  btnProfile: {
                    label:
                      translateText("Profile Button Label", "عنوان دکمه حساب کاربری", lang),
                    value: btnTextProfile,
                    setter: setBtnTextProfile,
                    disabled: hideBtnProfile,
                    toggleDisabled: () => setHideBtnProfile(!hideBtnProfile),
                  },
                  btnSupport: {
                    label:
                      translateText("Support Button Label", "عنوان دکمه پشتیبانی", lang),
                    value: btnTextSupport,
                    setter: setBtnTextSupport,
                    disabled: hideBtnSupport,
                    toggleDisabled: () => setHideBtnSupport(!hideBtnSupport),
                  },
                  btnTicketSupport: {
                    label:
                      translateText("Ticket Support Button Label", "عنوان دکمه تیکت به پشتیبانی", lang),
                    value: btnTextTicketSupport,
                    setter: setBtnTextTicketSupport,
                    disabled: hideBtnTicketSupport,
                    toggleDisabled: () =>
                      setHideBtnTicketSupport(!hideBtnTicketSupport),
                  },
                  btnFreeTest: {
                    label:
                      translateText("Free Test Button Label", "عنوان دکمه موجوده رایگان/تست", lang),
                    value: btnTextFreeTest,
                    setter: setBtnTextFreeTest,
                    disabled: hideBtnFreeTest,
                    toggleDisabled: () => setHideBtnFreeTest(!hideBtnFreeTest),
                  },
                  btnAiChat: {
                    label:
                      translateText("AI Chat Button Label", "عنوان دکمه چت با ربات", lang),
                    value: btnTextAiChat,
                    setter: setBtnTextAiChat,
                    disabled: hideBtnAiChat,
                    toggleDisabled: () => setHideBtnAiChat(!hideBtnAiChat),
                  },
                  btnColleagues: {
                    label:
                      translateText("Colleagues Button Label", "عنوان دکمه همکاران", lang),
                    value: btnTextColleagues,
                    setter: setBtnTextColleagues,
                    disabled: hideBtnColleagues,
                    toggleDisabled: () =>
                      setHideBtnColleagues(!hideBtnColleagues),
                  },
                  btnInstantSupport: {
                    label:
                      translateText("Instant Support Button Label", "عنوان دکمه پشتیبانی آنی", lang),
                    value: btnTextInstantSupport,
                    setter: setBtnTextInstantSupport,
                    disabled: hideBtnInstantSupport,
                    toggleDisabled: () =>
                      setHideBtnInstantSupport(!hideBtnInstantSupport),
                  },
                  btnFeedback: {
                    label:
                      translateText("Feedback Button Label", "عنوان دکمه بازخورد", lang),
                    value: btnTextFeedback,
                    setter: setBtnTextFeedback,
                    disabled: hideBtnFeedback,
                    toggleDisabled: () => setHideBtnFeedback(!hideBtnFeedback),
                  },
                  btnReferral: {
                    label:
                      translateText("Referral Button Label", "عنوان دکمه مجموعه‌گیری", lang),
                    value: btnTextReferral,
                    setter: setBtnTextReferral,
                    disabled: hideBtnReferral,
                    toggleDisabled: () => setHideBtnReferral(!hideBtnReferral),
                  },
                  btnWallet: {
                    label:
                      translateText("Wallet Button Label", "عنوان دکمه کیف پول و شارژ", lang),
                    value: btnTextWallet,
                    setter: setBtnTextWallet,
                    disabled: hideBtnWallet,
                    toggleDisabled: () => setHideBtnWallet(!hideBtnWallet),
                  },
                  btnAddConfig: {
                    label:
                      translateText("Add Config Button Label", "عنوان دکمه افزودن کانفیگ", lang),
                    value: btnTextAddConfig,
                    setter: setBtnTextAddConfig,
                    disabled: hideBtnAddConfig,
                    toggleDisabled: () => setHideBtnAddConfig(!hideBtnAddConfig),
                  },
                  btnConfigDetails: {
                    label:
                      translateText("Config Details Button Label", "عنوان دکمه مشخصات کانفیگ", lang),
                    value: btnTextConfigDetails,
                    setter: setBtnTextConfigDetails,
                    disabled: hideBtnConfigDetails,
                    toggleDisabled: () => setHideBtnConfigDetails(!hideBtnConfigDetails),
                  },
                  btnSearchConfig: {
                    label:
                      translateText("Search Config Button Label", "عنوان دکمه سرچ کانفیگ (مدیریت) - (فقط برای ادمین‌ها نمایش داده می‌شود)", lang),
                    value: btnTextSearchConfig,
                    setter: setBtnTextSearchConfig,
                    disabled: hideBtnSearchConfig,
                    toggleDisabled: () => setHideBtnSearchConfig(!hideBtnSearchConfig),
                  },
                };

                return mainButtonsOrder.map((key, idx) => {
                  const btn = primaryButtonsDefinition[key];
                  if (!btn) return null; // Fallback for invalid keys

                  return (
                    <div key={key} className="bg-[#141923]/60 p-3 rounded-xl border border-gray-800/80 mb-3 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <label className="text-xs font-medium text-gray-300">
                          {btn.label}
                        </label>
                        <div className="flex gap-1 items-center bg-[#1b2230] px-1.5 py-0.5 rounded-md border border-gray-700/50">
                          <button
                            type="button"
                            onClick={() => moveMainButton(idx, "up")}
                            className="text-gray-400 hover:text-white p-0.5"
                            title="Move Up"
                          >
                            <ChevronUp className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => moveMainButton(idx, "down")}
                            className="text-gray-400 hover:text-white p-0.5"
                            title="Move Down"
                          >
                            <ChevronDown className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Full-width button label input */}
                      <div>
                        <input
                          type="text"
                          disabled={btn.disabled}
                          className={`w-full bg-[#1b2230] border border-gray-700/80 rounded-lg px-3 py-2 text-xs text-white focus:ring-1 focus:ring-indigo-500 font-medium transition ${btn.disabled ? "opacity-50 line-through" : ""}`}
                          value={btn.value}
                          onChange={(e) => btn.setter(e.target.value)}
                          placeholder={translateText("Button text...", "متن دکمه...", lang)}
                        />
                      </div>

                      {/* Controls row */}
                      <div className="flex flex-wrap items-center gap-2 pt-0.5">
                        {/* Power ON/OFF toggle button */}
                        <button
                          type="button"
                          onClick={btn.toggleDisabled}
                          title={
                            translateText("Toggle visibility", "فعال/غیرفعال کردن این دکمه در ربات", lang)
                          }
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                            !btn.disabled
                              ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shadow-[0_0_8px_rgba(52,211,153,0.2)]"
                              : "bg-red-500/10 text-red-400 border border-red-500/20 opacity-75"
                          }`}
                        >
                          <Power className="w-3.5 h-3.5" />
                          <span>{!btn.disabled ? translateText("Active", "روشن (فعال)", lang) : translateText("Disabled", "خاموش (غیرفعال)", lang)}</span>
                        </button>

                        {/* Single vs Paired select */}
                        <div className="flex-1 min-w-[110px]">
                          <CustomSelect
                            value={singleButtons.includes(key) ? "single" : "pair"}
                            onChange={(val) => {
                              const isSingle = val === "single";
                              setSingleButtons((prev) => {
                                if (isSingle && !prev.includes(key)) return [...prev, key];
                                if (!isSingle && prev.includes(key)) return prev.filter((k) => k !== key);
                                return prev;
                              });
                            }}
                            options={[
                              { value: "pair", label: translateText("Paired", "👥 دوتایی", lang) },
                              { value: "single", label: translateText("Single", "👤 تکی", lang) },
                            ]}
                            title={translateText("Button layout format", "چیدمان تکی یا دوتایی دکمه", lang)}
                            dir={lang === "fa" ? "rtl" : "ltr"}
                          />
                        </div>

                        {/* Color selection dropdown */}
                        <div className="flex-1 min-w-[110px]">
                          <CustomSelect
                            value={primaryButtonColors[key] || "none"}
                            onChange={(val) => setPrimaryButtonColors({...primaryButtonColors, [key]: val})}
                            options={[
                              { value: "none", label: translateText("No Color", "بدون رنگ", lang) },
                              { value: "success", label: translateText("Green", "🟢 سبز", lang) },
                              { value: "danger", label: translateText("Red", "🔴 قرمز", lang) },
                              { value: "primary", label: translateText("Blue", "🔵 آبی", lang) },
                            ]}
                            title={translateText("Select button color", "انتخاب رنگ دکمه", lang)}
                            dir={lang === "fa" ? "rtl" : "ltr"}
                          />
                        </div>

                        {/* Edit wallet amounts if applicable */}
                        {key === "btnWallet" && (
                          <button
                            type="button"
                            onClick={() => {
                              setTempChargeAmounts([...walletChargeAmounts]);
                              setShowWalletAmountsModal(true);
                            }}
                            title={
                              translateText("Edit Wallet Charge Amounts", "ویرایش مبالغ شارژ کیف پول", lang)
                            }
                            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-400 text-xs font-medium transition-all cursor-pointer border border-amber-500/30"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                            <span>{translateText("Edit Amounts", "مبالغ شارژ", lang)}</span>
                          </button>
                        )}
                      </div>
                    </div>
                  );
                });
              })()}
            </div>
          </div>
        </div>

        {/* Part B: Extra Words Colors */}
        <div className="bg-[#111827] border border-emerald-500/25 p-5 rounded-xl space-y-4 shadow-lg shadow-emerald-500/5">
          <button
            type="button"
            onClick={() => setIsExtraWordsOpen(!isExtraWordsOpen)}
            className="w-full flex items-center justify-between text-left focus:outline-none pb-2 border-b border-gray-800"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
                <Palette className="w-5 h-5" />
              </div>
              <div className="text-right">
                <h4 className="font-display font-medium text-base text-white">
                  {translateText("🎨 Custom Colored Words (Inline Buttons)", "🎨 کلمات رنگی سفارشی (برای دکمه‌های شیشه‌ای)", lang)}
                </h4>
                <p className="text-xs text-gray-400 mt-1">
                  {translateText("Define custom colors (Green, Red, Blue) for inline/keyboard button keywords with smart matching.", "تعیین رنگ‌های سفارشی (سبز، قرمز، آبی) برای کلمات دکمه‌ها با کادربندی واضح و خوانا.", lang)}
                </p>
              </div>
            </div>
            <span className="text-gray-500 bg-gray-800/40 p-1.5 rounded-lg border border-gray-700/50 hover:bg-gray-800 transition">
              {isExtraWordsOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </span>
          </button>
          
          {isExtraWordsOpen && (
            <div className="space-y-4 mt-3 animate-fade-in">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 bg-[#0a0e17] p-4 border border-gray-800/60 rounded-xl">
                {extraButtonColors.map((item, idx) => (
                  <div key={idx} className="flex gap-2">
                    <input
                      type="text"
                      className="flex-1 bg-[#1b2230] border border-gray-700/80 rounded-lg p-2.5 text-xs text-white focus:ring-1 focus:ring-indigo-500"
                      placeholder={translateText("Keyword", "کلمه", lang)}
                      value={item.keyword}
                      onChange={(e) => {
                        const newList = [...extraButtonColors];
                        newList[idx].keyword = e.target.value;
                        setExtraButtonColors(newList);
                      }}
                    />
                    <div className="w-[105px] shrink-0">
                      <CustomSelect
                        value={item.color}
                        onChange={(val) => {
                          const newList = [...extraButtonColors];
                          newList[idx].color = val;
                          setExtraButtonColors(newList);
                        }}
                        options={[
                          { value: "none", label: translateText("None", "بدون رنگ", lang) },
                          { value: "success", label: translateText("Green", "سبز", lang) },
                          { value: "danger", label: translateText("Red", "قرمز", lang) },
                          { value: "primary", label: translateText("Blue", "آبی", lang) },
                        ]}
                        title={translateText("Color", "رنگ", lang)}
                        dir={lang === "fa" ? "rtl" : "ltr"}
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const newList = extraButtonColors.filter((_, i) => i !== idx);
                        setExtraButtonColors(newList);
                      }}
                      className="bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white p-2.5 rounded-lg transition"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                    </button>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setExtraButtonColors([...extraButtonColors, { keyword: "", color: "none" }])}
                  className="py-2.5 px-4 bg-indigo-600/10 text-indigo-400 border border-indigo-500/20 rounded-lg hover:bg-indigo-600 hover:text-white transition text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                  {translateText("Add New Word", "افزودن کلمه جدید", lang)}
                </button>
                <button
                  type="button"
                  onClick={() => setExtraButtonColors(extraButtonColors.map(item => ({ ...item, color: "none" })))}
                  className="py-2.5 px-4 bg-amber-500/10 text-amber-500 border border-amber-500/20 rounded-lg hover:bg-amber-500 hover:text-white transition text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/></svg>
                  {translateText("Remove All Colors", "بدون رنگ کردن همه کلمات", lang)}
                </button>
                <button
                  type="button"
                  onClick={() => setExtraButtonColors([])}
                  className="py-2.5 px-4 bg-red-500/10 text-red-500 border border-red-500/20 rounded-lg hover:bg-red-500 hover:text-white transition text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>
                  {translateText("Clear All Words", "حذف همه کلمات از لیست", lang)}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Part C: Premium Emojis */}
        <div className="bg-[#111827] border border-amber-500/25 p-5 rounded-xl space-y-4 shadow-lg shadow-amber-500/5">
          <button
            type="button"
            onClick={() => setIsPremiumEmojisOpen(!isPremiumEmojisOpen)}
            className="w-full flex items-center justify-between text-left focus:outline-none pb-2 border-b border-gray-800"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
                <Sparkles className="w-5 h-5 animate-pulse" />
              </div>
              <div className="text-right">
                <h4 className="font-display font-medium text-base text-white">
                  {translateText("✨ Premium Animated Emojis", "✨ جایگزین‌های ایموجی متحرک تلگرام", lang)}
                </h4>
                <p className="text-xs text-gray-400 mt-1">
                  {translateText("Map plain emojis to custom high-quality Telegram Premium animated emoji IDs.", "تعریف شناسه‌های ایموجی پرمیوم متحرک تلگرام به کدهای عددی در کادری مجزا و خوانا.", lang)}
                </p>
              </div>
            </div>
            <span className="text-gray-500 bg-gray-800/40 p-1.5 rounded-lg border border-gray-700/50 hover:bg-gray-800 transition">
              {isPremiumEmojisOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </span>
          </button>
          
          {isPremiumEmojisOpen && (
            <div className="space-y-4 mt-3 animate-fade-in">
              <div className="bg-[#0a0e17] p-4 border border-gray-800/60 rounded-xl text-xs text-amber-400/90 leading-tight space-y-1">
                <p>💡 {translateText("How to get Premium Emoji IDs?", "راهنمای به دست آوردن شناسه ایموجی متحرک:", lang)}</p>
                <p>{translateText("You can send any premium emoji to the @ShowJsonBot or @ShowIdBot in Telegram, get the long numeric 'custom_emoji_id' value, and map it here.", "شما می‌توانید هر ایموجی پریمیوم را به ربات @ShowJsonBot در تلگرام بفرستید، مقدار عددی طولانی custom_emoji_id را برداشته و در کادرهای زیر تنظیم کنید.", lang)}</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 bg-[#0a0e17] p-4 border border-gray-800/60 rounded-xl">
                {premiumEmojiList.map((item, idx) => (
                  <div key={idx} className="flex gap-2">
                    <input
                      type="text"
                      className="bg-[#1b2230] border border-gray-700/80 rounded-lg p-2.5 text-xs text-center text-white focus:ring-1 focus:ring-indigo-500 w-12 shrink-0"
                      placeholder="✨"
                      value={item.emoji}
                      onChange={(e) => {
                        const newList = [...premiumEmojiList];
                        newList[idx].emoji = e.target.value;
                        setPremiumEmojiList(newList);
                      }}
                    />
                    <input
                      type="text"
                      className="flex-1 bg-[#1b2230] border border-gray-700/80 rounded-lg p-2.5 text-xs text-left text-white focus:ring-1 focus:ring-indigo-500 font-mono tracking-wider"
                      placeholder="Custom Emoji ID (e.g. 5449...)"
                      value={item.customId}
                      onChange={(e) => {
                        const newList = [...premiumEmojiList];
                        newList[idx].customId = e.target.value;
                        setPremiumEmojiList(newList);
                      }}
                      dir="ltr"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const newList = premiumEmojiList.filter((_, i) => i !== idx);
                        setPremiumEmojiList(newList);
                      }}
                      className="bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white p-2.5 rounded-lg transition"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>
                    </button>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPremiumEmojiList([...premiumEmojiList, { emoji: "", customId: "" }])}
                  className="py-2.5 px-4 bg-indigo-600/10 text-indigo-400 border border-indigo-500/20 rounded-lg hover:bg-indigo-600 hover:text-white transition text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
                  {translateText("Add Emoji Mapping", "افزودن ایموجی جدید", lang)}
                </button>
                <button
                  type="button"
                  onClick={() => setPremiumEmojiList([])}
                  className="py-2.5 px-4 bg-red-500/10 text-red-500 border border-red-500/20 rounded-lg hover:bg-red-500 hover:text-white transition text-xs font-medium flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>
                  {translateText("Clear All Emojis", "حذف همه ایموجی‌ها از لیست", lang)}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Client Video Tutorials Section */}
        <div className="bg-[#111827] border border-[#1f2937] p-5 rounded-xl space-y-6">
          <div className="flex items-center gap-3 border-b border-gray-800 pb-3">
            <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400">
              <Activity className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h4 className="font-display font-medium text-base text-white">
                {translateText("🎥 Client Setup Video Tutorials", "🎥 ویدیوها و فایل‌های آموزش اتصال کلاینت‌ها", lang)}
              </h4>
              <p className="text-xs text-gray-400">
                {translateText("Associate a Direct Video URL, Playable GIF link, or Telegram File ID for each connection client guide.", "لینک مستقیم ویدیو/GIF یا شناسه فایل تلگرامی (File ID) را قرار دهید تا آموزش کلاینت مربوطه تصویری ارسال شود.", lang)}
              </p>
            </div>
          </div>

          <div className="bg-indigo-650/10 border border-indigo-500/20 p-4 rounded-xl text-xs text-gray-300 space-y-2 leading-relaxed">
            <p className="font-semibold text-indigo-300">
              💡{" "}
              {translateText("How to specify an educational media file?", "چگونه یک منبع تصویری یا ویدیو اضافه کنیم؟", lang)}
            </p>
            <p>
              {translateText("1. Telegram File ID (Recommended): Best for high-speed delivery. Send any tutorial video/GIF file to your bot, note the generated file ID in terminal/logs, and paste it below.", "۱. شناسه فایل تلگرام (File ID): برای ارسال سریع و پرسرعت مستقیم در تلگرام، ویدیو یا GIF مورد نظرتان را به ربات بفرستید؛ شناسه آن در لاگ‌های کنسول به شما نشان داده می‌شود. کپی کرده و در کادرهای زیر بگذارید.", lang)}
            </p>
            <p>
              {translateText("2. Direct Web Link: Provide a direct cloud hosted URL (e.g., https://yourdomain.com/setup.mp4) for users to interact or play natively.", "۲. لینک مستقیم (URL): می‌توانید لینک مستقیم فایل ویدیویی خود (مثلاً https://example.com/guide.mp4) را قرار دهید تا ربات از آن جهت نمایش ویدیو استفاده کند.", lang)}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] text-gray-400 mb-1 font-semibold">
                {translateText("📱 HAPP Client Video / File ID", "📱 کلاینت HAPP (موبایل)", lang)}
              </label>
              <input
                type="text"
                placeholder={
                  translateText("e.g., AgACAgIAAx...", "شناسه فایل یا آدرس ویدیو", lang)
                }
                className="w-full bg-[#1b2230] border border-gray-700/80 rounded-lg p-2.5 text-xs text-white focus:ring-1 focus:ring-indigo-500 font-sans"
                value={guideVideoHapp}
                onChange={(e) => setGuideVideoHapp(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-[11px] text-gray-400 mb-1 font-semibold">
                {translateText("🍎 iOS Clients Video / File ID", "🍎 کلاینت‌های آیفون / iOS", lang)}
              </label>
              <input
                type="text"
                placeholder={
                  translateText("e.g., AgACAgIAAx...", "شناسه فایل یا آدرس ویدیو", lang)
                }
                className="w-full bg-[#1b2230] border border-gray-700/80 rounded-lg p-2.5 text-xs text-white focus:ring-1 focus:ring-indigo-500 font-sans"
                value={guideVideoIos}
                onChange={(e) => setGuideVideoIos(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-[11px] text-gray-400 mb-1 font-semibold">
                {translateText("🤖 Android v2rayNG Video / File ID", "🤖 کلاینت اندروید (v2rayNG)", lang)}
              </label>
              <input
                type="text"
                placeholder={
                  translateText("e.g., AgACAgIAAx...", "شناسه فایل یا آدرس ویدیو", lang)
                }
                className="w-full bg-[#1b2230] border border-gray-700/80 rounded-lg p-2.5 text-xs text-white focus:ring-1 focus:ring-indigo-500 font-sans"
                value={guideVideoAndroid}
                onChange={(e) => setGuideVideoAndroid(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-[11px] text-gray-400 mb-1 font-semibold">
                {translateText("💻 Windows v2rayN Video / File ID", "💻 کلاینت ویندوز (v2rayN)", lang)}
              </label>
              <input
                type="text"
                placeholder={
                  translateText("e.g., AgACAgIAAx...", "شناسه فایل یا آدرس ویدیو", lang)
                }
                className="w-full bg-[#1b2230] border border-gray-700/80 rounded-lg p-2.5 text-xs text-white focus:ring-1 focus:ring-indigo-500 font-sans"
                value={guideVideoV2rayn}
                onChange={(e) => setGuideVideoV2rayn(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-[11px] text-gray-400 mb-1 font-semibold">
                {translateText("💻 Windows Karing Video / File ID", "💻 کلاینت ویندوز (Karing)", lang)}
              </label>
              <input
                type="text"
                placeholder={
                  translateText("e.g., AgACAgIAAx...", "شناسه فایل یا آدرس ویدیو", lang)
                }
                className="w-full bg-[#1b2230] border border-gray-700/80 rounded-lg p-2.5 text-xs text-white focus:ring-1 focus:ring-indigo-500 font-sans"
                value={guideVideoKaring}
                onChange={(e) => setGuideVideoKaring(e.target.value)}
              />
            </div>

            <div>
              <label className="block text-[11px] text-gray-400 mb-1 font-semibold">
                {translateText("💻 macOS Client Video / File ID", "💻 کلاینت مک (macOS)", lang)}
              </label>
              <input
                type="text"
                placeholder={
                  translateText("e.g., AgACAgIAAx...", "شناسه فایل یا آدرس ویدیو", lang)
                }
                className="w-full bg-[#1b2230] border border-gray-700/80 rounded-lg p-2.5 text-xs text-white focus:ring-1 focus:ring-indigo-500 font-sans"
                value={guideVideoMac}
                onChange={(e) => setGuideVideoMac(e.target.value)}
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-[11px] text-gray-400 mb-1 font-semibold">
                {translateText("🐧 Linux Client Video / File ID", "🐧 کلاینت لینوکس (Linux)", lang)}
              </label>
              <input
                type="text"
                placeholder={
                  translateText("e.g., AgACAgIAAx...", "شناسه فایل یا آدرس ویدیو", lang)
                }
                className="w-full bg-[#1b2230] border border-gray-700/80 rounded-lg p-2.5 text-xs text-white focus:ring-1 focus:ring-indigo-500 font-sans"
                value={guideVideoLinux}
                onChange={(e) => setGuideVideoLinux(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Part B: Custom Dynamic reply buttons */}
        <div className="bg-[#111827] border border-[#1f2937] p-5 rounded-xl space-y-6">
          <div className="flex items-center gap-3 border-b border-gray-800 pb-3">
            <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400">
              <Command className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-display font-medium text-base text-white">
                {translateText("Custom Auto-Reply Buttons", "دکمه‌های سفارشی پاسخ خودکار (Custom Submenus)", lang)}
              </h4>
              <p className="text-xs text-gray-400">
                {translateText("Add custom reply options that trigger instant preset responses (like free test links, guides).", "دکمه‌های فرعی ایجاد کنید که با کلیک روی آنها، ربات بلافاصله پاسخ متنی تنظیم شده را به کاربر بفرستد.", lang)}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Input Action Form */}
            <div className="space-y-4 bg-[#0a0e17] p-4 border border-gray-800/60 rounded-xl flex flex-col justify-between">
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="block text-[11px] text-gray-400 flex items-center gap-1 font-medium">
                      <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                      {translateText("Button Keyboard Display Label", "عنوان دکمه (مثال: 🎁 تست رایگان)", lang)}
                    </label>
                  </div>
                  <input
                    type="text"
                    placeholder={
                      translateText("e.g., 🎁 Get Free Test", "مثلا: 🎁 تست رایگان ۲ ساعته", lang)
                    }
                    className="w-full bg-[#1f2937] border border-gray-700 rounded-lg p-2.5 text-xs text-white focus:ring-1 focus:ring-indigo-500 focus:outline-none font-sans"
                    value={btnText}
                    onChange={(e) => setBtnText(e.target.value)}
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="block text-[11px] text-gray-400 font-medium">
                      {translateText("Auto Reply Text (Telegram HTML allowed)", "متن پاسخ ربات (پشتیبانی از تگ‌های HTML تلگرام)", lang)}
                    </label>
                  </div>
                  <textarea
                    rows={5}
                    placeholder={
                      translateText("Hello! Here is your quick configuration...", "سلام! جهت دریافت سرویس تست دکمه فعال شد:\nvless://test-configs-vpn...", lang)
                    }
                    className="w-full bg-[#1f2937] border border-gray-700 rounded-lg p-2.5 text-xs text-gray-200 focus:ring-1 focus:ring-indigo-500 focus:outline-none leading-relaxed font-sans"
                    value={btnReplyText}
                    onChange={(e) => setBtnReplyText(e.target.value)}
                  />
                </div>

                {buttonError && (
                  <p className="text-xs text-rose-400 flex items-center gap-1 font-semibold">
                    <span className="h-1.5 w-1.5 bg-rose-500 rounded-full"></span>
                    {buttonError}
                  </p>
                )}

                {buttonSuccess && (
                  <p className="text-xs text-emerald-400 flex items-center gap-1 font-semibold">
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    {translateText("✅ Button state synchronized!", "✅ تغییرات دکمه با موفقیت همگام شد!", lang)}
                  </p>
                )}
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={handleAddButton}
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-bold rounded-lg transition text-xs shadow-md shadow-emerald-600/15 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <PlusCircle className="w-4 h-4" />
                  {editingButtonId
                    ? translateText("Save Modified Button", "ذخیره تغییرات دکمه", lang)
                    : translateText("Create & Add Button", "ذخیره و افزودن دکمه جدید", lang)}
                </button>
                {editingButtonId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingButtonId(null);
                      setBtnText("");
                      setBtnReplyText("");
                    }}
                    className="px-4 py-2.5 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded-lg text-xs cursor-pointer"
                  >
                    {translateText("Cancel", "انصراف", lang)}
                  </button>
                )}
              </div>
            </div>

            {/* List and Actions rendering section */}
            <div className="bg-[#0b0f19] border border-gray-800 rounded-xl p-4 flex flex-col justify-between max-h-[380px] overflow-y-auto">
              <div>
                <h4 className="text-xs uppercase font-mono border-b border-gray-800 pb-2 mb-3 text-gray-400 font-semibold tracking-wider flex justify-between items-center">
                  <span>
                    {translateText("Live Custom Reply Buttons:", "دکمه‌های سفارشی فعال شده در ربات:", lang)}
                  </span>
                  <span className="bg-[#1f2937] text-indigo-400 px-2 py-0.5 rounded text-[10px] font-mono">
                    {customButtons.length}
                  </span>
                </h4>

                {customButtons.length === 0 ? (
                  <div className="py-16 text-center flex flex-col items-center justify-center">
                    <p className="text-xs text-gray-400 font-medium">
                      {translateText("No custom buttons created yet. Create one on the left.", "هیچ دکمه‌ی سفارشی ثبت نشده است. از فرم سمت چپ یکی اضافه کنید.", lang)}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3 max-h-[290px] overflow-y-auto no-scrollbar pr-1">
                    {customButtons.map((btn) => (
                      <div
                        key={btn.id}
                        className="bg-[#111827] border border-gray-800/80 p-3 rounded-lg flex items-start justify-between gap-3 shadow-sm hover:border-gray-700 transition"
                      >
                        <div className="space-y-1 flex-1 min-w-0">
                          <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/15 truncate max-w-full">
                            {btn.text}
                          </span>
                          <p className="text-[10px] text-gray-400 leading-normal font-sans line-clamp-3">
                            {btn.replyText}
                          </p>
                        </div>

                        <div className="flex gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() =>
                              moveButton(customButtons.indexOf(btn), "up")
                            }
                            className="text-gray-400 hover:text-white hover:bg-gray-700/50 p-1 rounded transition cursor-pointer"
                            title="Move up"
                          >
                            <ChevronUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              moveButton(customButtons.indexOf(btn), "down")
                            }
                            className="text-gray-400 hover:text-white hover:bg-gray-700/50 p-1 rounded transition cursor-pointer"
                            title="Move down"
                          >
                            <ChevronDown className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setEditingButtonId(btn.id);
                              setBtnText(btn.text);
                              setBtnReplyText(btn.replyText);
                            }}
                            className="text-indigo-400 hover:text-white hover:bg-indigo-500/15 p-1 rounded transition cursor-pointer"
                            title="Edit button"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setDeleteConfirmConfig({
                                isOpen: true,
                                action: () => handleDeleteButton(btn.id),
                                message:
                                  translateText("Are you sure you want to delete this custom button?", "آیا از حذف این دکمه اختصاصی اطمینان دارید؟", lang),
                              })
                            }
                            className="text-rose-400 hover:text-white hover:bg-rose-500/15 p-1 rounded transition cursor-pointer"
                            title="Remove button"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Telegram Bot Message & Layout Customization */}
        <div className="bg-[#111827] border border-[#1f2937] p-5 rounded-xl space-y-4">
          <h3 className="font-display font-medium text-lg text-white flex items-center gap-2">
            <Settings className="w-5 h-5 text-indigo-400" />
            {translateText("Telegram Bot Message & Button Customization", "سفارشی‌سازی متن‌ها و دکمه‌های ربات تلگرام", lang)}
          </h3>
          <p className="text-xs text-gray-400">
            {translateText("Customize primary bot responses and visibility of buttons without editing Python files directly.", "بدون نیاز به ویرایش فایل‌های پایتون در سرور لینوکس، متن‌های اصلی و دکمه‌های فعال ربات را سفارشی کنید.", lang)}
          </p>

          <div className="space-y-4 pt-2">
            {/* Welcome text */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-xs uppercase tracking-wider text-gray-400">
                  {translateText("Welcome Message Text (/start)", "متن خوش‌آمدگویی استارت ربات (/start)", lang)}
                </label>
              </div>
              <textarea
                rows={4}
                className="w-full bg-[#1f2937] border border-gray-700 rounded-lg p-2.5 text-sm text-yellow-100 focus:ring-1 focus:ring-indigo-500 font-mono"
                value={welcomeText}
                onChange={(e) => setWelcomeText(e.target.value)}
              />
              <span className="text-[10px] text-gray-500 mt-1 block">
                {translateText("Tip: Use {tg_id} for user's ID and {wallet_balance} for wallet credit. HTML tags are supported.", "نکته: می‌توانید از کدهای {tg_id} برای نمایش آیدی کاربری و {wallet_balance} برای نمایش مانده اعتبار استفاده کنید. قالب‌بندی HTML مجاز است.", lang)}
              </span>
            </div>

            {/* Support text */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-xs uppercase tracking-wider text-gray-400">
                  {translateText("Support Button Content", "متن دکمه پشتیبانی فنی", lang)}
                </label>
              </div>
              <textarea
                rows={4}
                className="w-full bg-[#1f2937] border border-gray-700 rounded-lg p-2.5 text-sm text-indigo-200 focus:ring-1 focus:ring-indigo-500 font-mono"
                value={supportText}
                onChange={(e) => setSupportText(e.target.value)}
              />
              <span className="text-[10px] text-gray-500 mt-1 block">
                {translateText("Tip: HTML tags are supported.", "نکته: قالب‌بندی HTML مجاز است.", lang)}
              </span>
            </div>

            {/* Pinned Message Section */}
            <div className="border border-indigo-500/20 bg-indigo-950/10 p-4 rounded-xl space-y-3.5">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <label className="text-sm font-semibold text-white flex items-center gap-1.5">
                    📌 {translateText("Enable Auto-Pinned Message", "فعالسازی پین خودکار پیام", lang)}
                  </label>
                  <p className="text-[11px] text-gray-400">
                    {translateText("If enabled, this message will be sent and pinned in the user's private chat when they /start the bot.", "با فعالسازی این گزینه، پیام مشخص شده به محض ورود کاربر به ربات (/start) در چت خصوصی او فرستاده و پین می‌شود.", lang)}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setPinnedMessageActive(!pinnedMessageActive)}
                  className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                    pinnedMessageActive ? "bg-indigo-600" : "bg-gray-800"
                  }`}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      pinnedMessageActive ? (translateText("translate-x-5", "-translate-x-5", lang)) : "translate-x-0"
                    }`}
                  />
                </button>
              </div>

              {pinnedMessageActive && (
                <div className="space-y-1.5 animate-fadeIn">
                  <div className="flex justify-between items-center mb-1">
                    <label className="block text-xs uppercase tracking-wider text-gray-400">
                      {translateText("Pinned Message Text", "متن پیام پین‌شونده", lang)}
                    </label>
                  </div>
                  <textarea
                    rows={3}
                    className="w-full bg-[#1f2937] border border-gray-700 rounded-lg p-2.5 text-sm text-indigo-200 focus:ring-1 focus:ring-indigo-500 font-mono"
                    placeholder={
                      translateText("e.g. 📢 Follow our new channel: @My_New_Channel", "مثال: 📢 آدرس جدید کانال ما را حتما دنبال کنید: @My_New_Channel", lang)
                    }
                    value={pinnedMessageText}
                    onChange={(e) => setPinnedMessageText(e.target.value)}
                  />
                  <span className="text-[10px] text-gray-500 mt-1 block">
                    {translateText("Tip: HTML tags are supported in the pinned message.", "نکته: قالب‌بندی HTML در پیام پین شده مجاز است.", lang)}
                  </span>
                </div>
              )}
            </div>

            {/* Purchase success note text */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-xs uppercase tracking-wider text-gray-400">
                  {translateText("📝 Config Delivery Success Note", "📝 توضیحات پیوست پس از تحویل اکانت به مشتری", lang)}
                </label>
              </div>
              <textarea
                rows={3}
                placeholder={
                  translateText("e.g., Client Tutorial Channel: @example_setup", "مثلا: کانال آموزش کلاینت‌ها: @example_setup", lang)
                }
                className="w-full bg-[#1f2937] border border-gray-700 rounded-lg p-2.5 text-sm text-emerald-200 focus:ring-1 focus:ring-indigo-500 font-mono"
                value={purchaseSuccessNote}
                onChange={(e) => setPurchaseSuccessNote(e.target.value)}
              />

              {/* Media Attachment Actions for Purchase Note */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <span className="text-[11px] text-gray-500">
                  {t.attachMedia}
                </span>
                <button
                  type="button"
                  onClick={() => triggerPurchaseUpload("image")}
                  className="px-2 py-1 rounded bg-[#111827] border border-gray-700 hover:border-indigo-500 text-gray-400 hover:text-indigo-400 text-[10px] transition flex items-center gap-1"
                >
                  <ImageIcon className="w-3 h-3 text-purple-400" />
                  {t.mediaImage}
                </button>
                <button
                  type="button"
                  onClick={() => triggerPurchaseUpload("video")}
                  className="px-2 py-1 rounded bg-[#111827] border border-gray-700 hover:border-indigo-500 text-gray-400 hover:text-indigo-400 text-[10px] transition flex items-center gap-1"
                >
                  <Film className="w-3 h-3 text-blue-400" />
                  {t.mediaVideo}
                </button>
                <button
                  type="button"
                  onClick={() => triggerPurchaseUpload("voice")}
                  className="px-2 py-1 rounded bg-[#111827] border border-gray-700 hover:border-indigo-500 text-gray-400 hover:text-indigo-400 text-[10px] transition flex items-center gap-1"
                >
                  <Mic className="w-3 h-3 text-emerald-400" />
                  {t.mediaVoice}
                </button>
                <button
                  type="button"
                  onClick={() => triggerPurchaseUpload("file")}
                  className="px-2 py-1 rounded bg-[#111827] border border-gray-700 hover:border-indigo-500 text-gray-400 hover:text-indigo-400 text-[10px] transition flex items-center gap-1"
                >
                  <Paperclip className="w-3 h-3 text-amber-400" />
                  {t.mediaFile}
                </button>
                {activePurchaseAttachment && (
                  <button
                    type="button"
                    onClick={() => setActivePurchaseAttachment(null)}
                    className="px-2 py-1 rounded bg-rose-500/10 border border-rose-500/20 text-rose-400 hover:bg-rose-500/20 text-[10px] transition flex items-center gap-1 ml-auto"
                  >
                    <Trash2 className="w-3 h-3" />
                    {translateText("Remove", "حذف رسانه", lang)}
                  </button>
                )}
              </div>
              <input
                type="file"
                ref={purchaseAttachmentInputRef}
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = () => {
                    setActivePurchaseAttachment({
                      fileData: reader.result as string,
                      fileName: file.name,
                      fileType: activePurchaseUploadType,
                    });
                  };
                  reader.readAsDataURL(file);
                  e.target.value = "";
                }}
              />
              {activePurchaseAttachment && (
                <div className="flex items-center gap-3 p-2 mt-2 rounded bg-gray-900 border border-indigo-500/20">
                  {activePurchaseAttachment.fileType === "image" && (
                    <img
                      src={activePurchaseAttachment.fileData}
                      alt="Preview"
                      className="w-8 h-8 rounded object-cover"
                    />
                  )}
                  {activePurchaseAttachment.fileType === "video" && (
                    <Film className="w-5 h-5 text-indigo-400" />
                  )}
                  {activePurchaseAttachment.fileType === "voice" && (
                    <Mic className="w-5 h-5 text-emerald-400" />
                  )}
                  {activePurchaseAttachment.fileType === "file" && (
                    <Paperclip className="w-5 h-5 text-amber-400" />
                  )}
                  <div className="text-[10px] text-gray-300 truncate max-w-[200px]">
                    {activePurchaseAttachment.fileName}
                  </div>
                </div>
              )}

              <span className="text-[10px] text-gray-500 mt-2 block">
                {translateText("Tip: This text will be appended automatically beneath the premium config link upon successful customer checkout.", "نکته: این متن به عنوان راهنما، بلافاصله در زیر کانفیگ صادر شده به مشتری تحویل داده می‌شود.", lang)}
              </span>
            </div>
          </div>
        </div>

        {/* Actions Save footer */}
        <div className="flex items-center justify-between pt-4 border-t border-[#1f2937]">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-gray-500" />
            <span className="text-[10px] uppercase font-mono text-gray-500">
              {translateText("Saves straight to JSON Daltoon_Bot.json", "ذخیره‌سازی آنی در دیتابیس ربات (Daltoon_Bot.json)", lang)}
            </span>
          </div>

          <div className="flex items-center gap-3">
            {saved && (
              <span className="text-emerald-400 text-sm font-semibold flex items-center gap-1">
                <Check className="w-4 h-4" /> {t.parametersFlushed}
              </span>
            )}
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white rounded-lg text-sm font-semibold cursor-pointer transition shadow-lg shadow-indigo-600/10"
            >
              <Save className="w-4 h-4" />
              {translateText("Save Button Layout & Labels", "ذخیره تغییرات دکمه‌ها و چیدمان", lang)}
            </button>
          </div>
        </div>
      </form>

      {showGuidesModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-xl bg-[#0d121f] border border-gray-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden max-h-[90vh]">
            <div className="p-5 border-b border-gray-800/60 flex items-center justify-between">
              <span className="text-sm font-semibold text-white flex items-center gap-2">
                <Pencil className="w-4 h-4 text-amber-400" />
                {translateText("Edit Connection Guide Text", "ویرایش توضیحات راهنمای اتصال", lang)}
              </span>
              <button
                type="button"
                onClick={() => setShowGuidesModal(false)}
                className="text-gray-400 hover:text-white transition duration-150 text-xl font-bold p-1 cursor-pointer"
              >
                &times;
              </button>
            </div>

            <div className="p-5 flex-1 overflow-auto space-y-3">
              <div className="flex justify-between items-center mb-1">
                <label className="block text-xs uppercase tracking-wider text-gray-400 font-semibold">
                  {translateText("📝 Description for Connection Guide button", "📝 توضیحات برای دکمه راهنمای اتصال", lang)}
                </label>
              </div>
              <textarea
                value={tempGuidesText}
                onChange={(e) => setTempGuidesText(e.target.value)}
                rows={10}
                className="w-full bg-[#161c2a] border border-gray-700/80 rounded-xl p-3.5 text-xs text-white focus:ring-1 focus:ring-indigo-500 font-medium transition resize-y leading-relaxed text-right"
                dir="rtl"
                placeholder={
                  translateText("Write connection guide content here...", "توضیحات دکمه آموزش را اینجا بنویسید...", lang)
                }
              />
              <p
                className="text-[10px] text-gray-400 leading-relaxed text-right"
                dir="rtl"
              >
                {translateText("• You can use HTML codes like <b>bold</b> and <code>monospace</code> for rich formatting.", "• می‌توانید از کدهای HTML مانند <b>برای ضخیم کردن متن</b> و یا <code>برای کپی سریع کلمات</code> استفاده فرمایید.", lang)}
              </p>
            </div>

            <div className="p-4 bg-[#0a0e17] border-t border-gray-800/60 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowGuidesModal(false)}
                className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-lg text-xs font-semibold cursor-pointer transition border border-gray-700/60"
              >
                {translateText("Cancel", "انصراف", lang)}
              </button>
              <button
                type="button"
                onClick={() => {
                  setGuidesText(tempGuidesText);
                  onSaveSettings({
                    ...getPayload(),
                    guidesText: tempGuidesText,
                  });
                  setShowGuidesModal(false);
                }}
                className="px-5 py-2 bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white rounded-lg text-xs font-semibold cursor-pointer transition shadow-lg shadow-emerald-600/10 flex items-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5" />
                {translateText("Save Changes & Close", "ذخیره نهایی و بستن", lang)}
              </button>
            </div>
          </div>
        </div>
      )}



      {/* Wallet Charge Amounts Modal */}
      {showWalletAmountsModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center p-4 z-50 animate-fade-in font-sans">
          <div className="bg-[#111827] border border-slate-700/60 p-6 rounded-2xl w-full max-w-lg shadow-[0_0_40px_rgba(0,0,0,0.5)] max-h-[85vh] overflow-y-auto">
            <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
              <Coins className="w-5 h-5 text-amber-400" />
              {translateText("Wallet Charge Amounts", "تنظیم مبالغ شارژ کیف پول", lang)}
            </h3>
            <p className="text-xs text-gray-400 mb-5 leading-relaxed">
              {translateText("Set preset charge amounts (in Tomans) for quick recharging buttons in the bot. Users will be shown these ready options.", "مبالغی که جهت دکمه‌های شارژ سریع در ربات برای افزایش موجودی نمایش داده می‌شود را مشخص کنید (به تومان). کاربران با انتخاب هرکدام، لینک پرداخت کارت‌به‌کارت دریافت می‌کنند.", lang)}
            </p>

            <div className="space-y-3">
              {tempChargeAmounts.map((amt, idx) => (
                <div
                  key={idx}
                  className="flex gap-2 items-center bg-[#0a0e17] p-2.5 rounded-xl border border-slate-800"
                >
                  <div className="text-gray-500 font-mono text-xs w-6 text-center">
                    #{idx + 1}
                  </div>
                  <input
                    type="number"
                    className="flex-1 bg-[#1b2230] border border-gray-700/80 rounded-lg p-2 text-xs text-white focus:ring-1 focus:ring-indigo-500 font-medium font-mono"
                    value={amt || ""}
                    onChange={(e) => {
                      const val = e.target.value === "" ? 0 : parseInt(e.target.value) || 0;
                      const copy = [...tempChargeAmounts];
                      copy[idx] = val;
                      setTempChargeAmounts(copy);
                    }}
                    placeholder="مبلغ به تومان"
                  />
                  <div className="text-[10px] text-gray-400 font-mono font-bold w-28 text-left">
                    {amt > 0 ? `${amt.toLocaleString()} تومان` : "۰"}
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setTempChargeAmounts(
                        tempChargeAmounts.filter((_, i) => i !== idx),
                      );
                    }}
                    className="p-1 px-2 text-red-400 hover:bg-red-500/10 rounded-lg border border-red-500/10 transition cursor-pointer"
                    title={translateText("Remove", "حذف", lang)}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}

              {tempChargeAmounts.length === 0 && (
                <p className="text-xs text-center text-gray-500 py-4">
                  {translateText("No amounts defined.", "هیچ مبلغی تعریف نشده است.", lang)}
                </p>
              )}
            </div>

            <button
              type="button"
              onClick={() => {
                setTempChargeAmounts([...tempChargeAmounts, 100000]);
              }}
              className="mt-4 w-full py-2 border border-dashed border-gray-700 hover:border-gray-500 text-indigo-400 text-xs flex items-center justify-center gap-1.5 rounded-xl transition cursor-pointer hover:bg-indigo-500/5 font-semibold"
            >
              <Plus className="w-4 h-4" />
              {translateText("Add New Preset Amount", "افزودن مبلغ جدید", lang)}
            </button>

            <div className="flex justify-end gap-3 mt-6 border-t border-gray-800/60 pt-4">
              <button
                type="button"
                onClick={() => {
                  setShowWalletAmountsModal(false);
                }}
                className="px-4 py-2 bg-[#1f2937] hover:bg-slate-700 text-gray-300 rounded-lg text-xs font-semibold cursor-pointer transition border border-slate-700/50 hover:border-slate-600"
              >
                {translateText("Cancel", "انصراف", lang)}
              </button>
              <button
                type="button"
                onClick={() => {
                  setWalletChargeAmounts(tempChargeAmounts);
                  onSaveSettings({
                    ...getPayload(),
                    walletChargeAmounts: tempChargeAmounts,
                  });
                  setShowWalletAmountsModal(false);
                }}
                className="px-5 py-2 bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white rounded-lg text-xs font-semibold cursor-pointer transition shadow-lg shadow-emerald-600/10 flex items-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5" />
                {translateText("Save Changes", "ذخیره و تایید", lang)}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Style Modal */}

      {/* Emoji Modal */}

      <ConfirmationModal
        isOpen={deleteConfirmConfig.isOpen}
        message={deleteConfirmConfig.message}
        lang={lang}
        isDangerous={true}
        onCancel={() =>
          setDeleteConfirmConfig({ isOpen: false, action: null, message: "" })
        }
        onConfirm={() => {
          if (deleteConfirmConfig.action) {
            deleteConfirmConfig.action();
          }
          setDeleteConfirmConfig({ isOpen: false, action: null, message: "" });
        }}
      />
    </div>
  );
}
