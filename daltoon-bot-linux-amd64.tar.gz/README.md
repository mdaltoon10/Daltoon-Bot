[English](README.md) | [فارسی](README_FA.md) | [العربية](README_AR.md) | [Русский](README_RU.md) | [Türkçe](README_TR.md) | [Español](README_ES.md)

<div align="center">
  <img src="https://i.ibb.co/zhrG6Ljn/Banner.png" alt="Daltoon Bot" width="800">
</div>

<p align="center">
  <img src="https://img.shields.io/github/v/release/mdaltoon10/Daltoon-Bot?color=blue&label=release" alt="release">
  <img src="https://img.shields.io/badge/build-passing-brightgreen" alt="build">
  <img src="https://img.shields.io/badge/dynamic/json?url=https://raw.githubusercontent.com/mdaltoon10/Daltoon-Bot/main/downloads.json&query=$.downloads&color=orange&label=downloads" alt="downloads">
  <img src="https://img.shields.io/github/license/mdaltoon10/Daltoon-Bot?color=blue" alt="license">
</p>

**Daltoon Bot** is an advanced, real-time solution for managing VPN services through Telegram. It provides a clean, automated interface for deploying, configuring, and monitoring a wide range of VPN protocols across multiple panels.

Built as an all-in-one system, Daltoon Bot adds broader panel support, improved stability, and a modern web-based management experience.

> [!IMPORTANT]
> This project is intended for personal use only. Please do not use it for illegal purposes or in a production environment.

## 🚀 Features

- **Multi-Panel Support** — Seamless integration and synchronization with **Sanaei (3x-ui)**, **D-UI (v1.5.8)**, **Reebeka**, and **Pasarguard** panels.
- **Telegram Mini App (WebApp)** — Interactive WebApp inside Telegram allowing users to view plans, purchase services, charge wallet, and check active subscriptions seamlessly.
- **Wallet System** — Integrated user wallet allowing users to charge accounts and purchase subscriptions instantly.
- **Per-Server Customization & Config Delivery** — Configure allowed payment gateways per server, customize subscription & direct link delivery formats, header/footer text, and separators per server.
- **Bot Notification Manager** — Toggle and manage 24 direct notification alerts for user PMs and admin PMs (purchase alerts, receipt approval/rejections, ticket updates, wallet charges, server alerts).
- **SSL Certificate & Domain Setup** — Integrated SSL certificate issuance (ZeroSSL / Certbot / Self-signed) and custom domain management directly from CLI option [9] or Admin Panel.
- **Real-time Monitoring** — Automated traffic tracking, per-client usage quotas, and live connection status.
- **Admin Dashboard** — A modern, full-stack React interface for managing users, servers, and system settings.
- **Multi-Node Management** — Control and scale across multiple VPN servers from a single centralized bot.
- **Automated Installation** — Quick-start script that handles all dependencies, including Python, Node.js, and PM2.
- **Security** — Centralized SQLite database with secure API handling and encrypted configuration.
- **Process Management** — Fully managed by PM2 for high availability and automated service recovery.

## 🌐 Supported Languages

Daltoon Bot is fully internationalized and supports multiple languages for both the Telegram Bot and the Admin Dashboard. The following languages are supported:

- 🇺🇸 **English** (Default)
- 🇮🇷 **Persian** (فارسی)
- 🇸🇦 **Arabic** (العربية)
- 🇷🇺 **Russian** (Русский)
- 🇹🇷 **Turkish** (Türkçe)
- 🇪🇸 **Spanish** (Español)

Users can seamlessly switch between these languages in the application settings, adapting the entire UI and message outputs instantly.

## 📥 Downloads

You can download the project manually or check the latest releases on our [GitHub Releases Page](https://github.com/mdaltoon10/Daltoon-Bot/releases).

## ⚡ Quick Start

To install Daltoon Bot instantly on your Linux server, run:

```bash
bash <(curl -Ls https://raw.githubusercontent.com/mdaltoon10/Daltoon-Bot/main/install.sh)
```

## 🛠 Management CLI (`daltoon-dashboard`)

After installation, you can manage your services using the `daltoon-dashboard` command. This is an interactive CLI tool that simplifies all administrative tasks.

### 📋 Command Table

| Command Item | Description | Functionality |
| :--- | :--- | :--- |
| **[1] Update** | `🔄 Update Project` | Fetches latest updates from GitHub and rebuilds the project. |
| **[2] Uninstall** | `🗑️ Uninstall` | Completely removes the project and background services. |
| **[3] Status** | `📊 View Status` | Shows CPU/RAM usage and status for Dashboard and Bot. |
| **[4] Start** | `🚀 Start Services` | Launches the Dashboard and Bot using PM2. |
| **[5] Stop** | `🛑 Stop Services` | Stops all running Daltoon services via PM2. |
| **[6] Restart** | `♻️ Restart Services` | Restarts all services (Dashboard and Bot). |
| **[7] Credentials** | `🔑 Change Login` | Update the username and password for the Admin Dashboard. |
| **[8] Port** | `🔌 Change Port` | Change the web port for the Admin Dashboard. |
| **[9] SSL** | `🔒 SSL Certificate Setup` | Issue and configure SSL certificates and custom domain for web access. |
| **[10] Exit** | `🚪 Exit` | Closes the management CLI. |

## 🛠 Manual Installation

Follow these steps to get your bot up and running manually:

1. **Clone the Repository**:
   ```bash
   git clone https://github.com/mdaltoon10/Daltoon-Bot.git
   ```

2. **Run the Installer**:
   ```bash
   cd Daltoon-Bot
   chmod +x install.sh
   ./install.sh
   ```

## 🛠 Tech Stack

- **Bot**: Python (Telebot)
- **Dashboard**: React, Vite, Tailwind CSS
- **Backend**: Node.js, Express, TypeScript
- **Database**: SQLite
- **Process Manager**: PM2

## 🛡 License

MIT License.

## 💖 Support Us
If you find this project useful and would like to support its development, you can donate via the following crypto addresses:

**Bep20:**
```text
0x7316A874F562FBCe67Cd0540E6b0EA6001FA09c8
```

**Trx:**
```text
TEZtgumuwyRn8brLSbks5HQSsnJKnZc6cr
```


---
**Maintained by [mDaltoon](https://t.me/mDaltoon)**
