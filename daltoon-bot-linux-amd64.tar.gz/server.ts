import express from "express"; // core
import path from "path";
import fs from "fs";
import os from "os";
import https from "https";
import http from "http";
import net from "net";
import tls from "tls";
import { createServer as createViteServer } from "vite";
import { spawn, ChildProcess, exec, execSync } from "child_process";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import dns from "dns";
import { setGlobalDispatcher, Agent } from "undici";

// Prefer IPv4 DNS resolution first to fix native fetch failing on self-hosted VPS servers (especially with dual-stack domain names like AwanLLM)
dns.setDefaultResultOrder("ipv4first");

// Configure undici global dispatcher to allow all SSL/TLS connections (self-signed certs, custom panel domains)
try {
  setGlobalDispatcher(
    new Agent({
      connect: {
        rejectUnauthorized: false,
      },
    })
  );
  console.log("[TLS Resilience] Undici global dispatcher configured for domain/SSL connectivity.");
} catch (e: any) {
  console.warn("[TLS Warning] Could not set undici global dispatcher:", e?.message || e);
}

// Explicit absolute dotenv loads for absolute correctness across nested builds
dotenv.config();
dotenv.config({ path: path.resolve(process.cwd(), ".env") });

const _dirname = typeof __dirname !== "undefined" ? __dirname : process.cwd();

try {
  dotenv.config({ path: path.resolve(_dirname, ".env") });
  dotenv.config({ path: path.resolve(_dirname, "..", ".env") });
} catch (e) {}

// ===== GLOBAL PROCESS RESILIENCE (prevents total panel outage) =====
// Since Node 15, an unhandled promise rejection CRASHES the whole process by
// default, and Express 4 does not forward async route errors to its error
// middleware. A single rejected promise inside any of the 100+ async API routes
// would therefore take the entire panel down (PM2 restart loop = outage for
// every installed copy). These handlers keep the process alive, log loudly,
// and let the rest of the API continue serving.
process.on("unhandledRejection", (reason: any, promise: Promise<any>) => {
  console.error("[Process Safety] Unhandled promise rejection (server kept alive):", reason instanceof Error ? reason.stack || reason.message : reason);
});
process.on("uncaughtException", (err: Error) => {
  console.error("[Process Safety] Uncaught exception (server kept alive):", err.stack || err.message || err);
});

// Disable SSL verification for outgoing requests to 3x-ui panels
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
import { readSqliteDb, writeSqliteDb, getSystemSettings, extractDbFromSqliteBuffer, isKeyForColleague, sqliteDb, dbSqlitePath, clearMiniappDataCache, miniappDataCacheMap } from "./src/db/database.js";
import { createSslMiddleware } from "./src/middleware/ssl.js";
import { registerAdminRoutes } from "./src/routes/admin.js";
import {
  requireAdminAuth,
  createAdminSession,
  getAdminSession,
  destroyAdminSession,
  getAdminTokenFromRequest,
  checkLoginRateLimit,
  recordFailedLogin,
  resetFailedLogins,
  getClientIp,
} from "./src/middleware/auth.js";

// Set up server port strictly to 3000 as required by the platform reverse proxy
const PORT = 3000;
const app = express();

console.log(
  "[Debug] process.env.GEMINI_API_KEY loaded:",
  process.env.GEMINI_API_KEY
    ? `Yes (length: ${process.env.GEMINI_API_KEY.length}, starts with: ${process.env.GEMINI_API_KEY.substring(0, 5)})`
    : "No (undefined/empty)",
);
app.use(express.json({ limit: "250mb" }));
app.use(express.urlencoded({ limit: "250mb", extended: true }));
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (err) {
    console.error("[Express Payload Error]", err.message);
    if (err.type === "entity.too.large" || err.status === 413) {
      return res.status(413).json({
        success: false,
        error: "حجم فایل بکاپ بیشتر از حد مجاز (۲۵۰ مگابایت) است."
      });
    }
    return res.status(err.status || 400).json({
      success: false,
      error: `خطا در پردازش بکاپ: ${err.message || "فرمت داده ارسال شده معتبر نیست."}`
    });
  }
  next();
});
const uploadsDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadsDir)) {
  try { fs.mkdirSync(uploadsDir, { recursive: true }); } catch (e) {}
}
const receiptsDir = path.join(process.cwd(), "receipts");
if (!fs.existsSync(receiptsDir)) {
  try { fs.mkdirSync(receiptsDir, { recursive: true }); } catch (e) {}
}

app.use("/uploads", express.static(uploadsDir));
app.use("/receipts", express.static(receiptsDir));

// SSL domain enforcement (extracted to src/middleware/ssl.ts)
app.use(createSslMiddleware(PORT));
registerAdminRoutes(app);

console.log(`[Database] Connecting to JSON file database at: ${dbSqlitePath}`);

// Define types for pure JSON database to align perfectly with schema
let botProcess: ChildProcess | null = null;
let pythonDepsInstalled = false;

function startPythonBot() {

  const isPM2 =
    process.env.PM2_HOME !== undefined ||
    process.env.pm_id !== undefined ||
    process.env.name === "daltoon-store";

  // Check if we should use PM2 by checking if daltoon-bot exists in PM2
  if (isPM2) {
    exec("pm2 info daltoon-bot", (infoErr) => {
      if (!infoErr) {
        console.log("[Bot Manager] Delegating bot restart to PM2 daemon...");
        exec("pm2 restart daltoon-bot", (err) => {
          if (err) {
            console.error("[Bot Manager] Failed to restart daltoon-bot via PM2:", err.message);
          } else {
            console.log("[Bot Manager] daltoon-bot restarted successfully via PM2.");
          }
        });
      } else {
        console.log("[Bot Manager] PM2 detected but 'daltoon-bot' not found in PM2 list. Spawning internally...");
        spawnInternalBot();
      }
    });
    return;
  }
  
  spawnInternalBot();
}

function spawnInternalBot() {

  if (botProcess) {
    console.log("[Bot Manager] Stopping old Python bot process...");
    botProcess.kill("SIGKILL");
    botProcess = null;
  }

  // Load latest settings to check if BOT_TOKEN is empty
  const db = readSqliteDb();
  const settings = getSystemSettings(db);
  const token = settings.botToken;

  if (!token || token === "DUMMY_TOKEN" || token.trim() === "") {
    console.log(
      "[Bot Manager] Bot token is empty or dummy. Python bot will not start.",
    );
    return;
  }

  const runBot = () => {
    console.log(
      `[Bot Manager] Starting Python Telegram Bot with token ${token.substring(0, 6)}...`,
    );
    try {
      const pythonCmd = "python3";
      const botScriptPath = path.resolve(process.cwd(), "bot.py");

      botProcess = spawn(pythonCmd, ["-u", botScriptPath], {
        cwd: process.cwd(),
        env: {
          ...process.env,
          PYTHONUNBUFFERED: "1",
          PYTHONPATH: (process.env.PYTHONPATH ? process.env.PYTHONPATH + ":" : "") + path.join(process.env.HOME || "/root", ".local/lib/python3.10/site-packages"),
        },
        stdio: "pipe",
      });

      const logStream = fs.createWriteStream("bot_dev.log", { flags: "a" });

      botProcess.stdout?.on("data", (data) => {
        const msg = data.toString();
        console.log(`[Bot Output]: ${msg.trim()}`);
        logStream.write(`[STDOUT] ${msg}`);
      });

      botProcess.stderr?.on("data", (data) => {
        const msg = data.toString();
        console.error(`[Bot Error]: ${msg.trim()}`);
        logStream.write(`[STDERR] ${msg}`);
      });

      botProcess.on("close", (code) => {
        console.log(
          `[Bot Manager] Python bot process closed with code ${code}`,
        );
        botProcess = null;
      });

      botProcess.on("error", (err) => {
        console.error("[Bot Manager] Failed to start Python bot process:", err);
      });
    } catch (err) {
      console.error("[Bot Manager] Exception when spawning python:", err);
    }
  };

  if (!pythonDepsInstalled) {
    exec('python3 -c "import telebot, dotenv, requests, deep_translator"', (err) => {
      if (!err) {
        pythonDepsInstalled = true;
        runBot();
      } else {
        console.log("[Bot Manager] Installing Python dependencies (pyTelegramBotAPI, python-dotenv, requests, deep-translator)...");
        exec(
          "curl -sSL https://bootstrap.pypa.io/get-pip.py -o get-pip_fresh.py && python3 get-pip_fresh.py --user || true",
          () => {
            exec(
              "python3 -m pip install pyTelegramBotAPI python-dotenv requests deep-translator --break-system-packages --user || ~/.local/bin/pip install pyTelegramBotAPI python-dotenv requests deep-translator --user || pip install pyTelegramBotAPI python-dotenv requests deep-translator --user || true",
              () => {
                pythonDepsInstalled = true;
                runBot();
              }
            );
          }
        );
      }
    });
  } else {
    runBot();
  }
}

// Ensure database file gets seeded on startup
readSqliteDb();
console.log(`[Database] Using active database at: ${dbSqlitePath}`);
startPythonBot();

// --- API Endpoints ---

// Full Wipe Database API
app.post("/api/database/wipe-all", requireAdminAuth, async (req, res) => {
  try {
    const targetDbFile = path.resolve(process.cwd(), "Daltoon_Bot.db");
    if (fs.existsSync(targetDbFile)) {
      try {
        sqliteDb.close();
      } catch (e) {}
      try { fs.unlinkSync(targetDbFile); } catch (e) {}
      try { fs.unlinkSync(targetDbFile + "-wal"); } catch (e) {}
      try { fs.unlinkSync(targetDbFile + "-shm"); } catch (e) {}
    }
    // Also clear process-level cache if any (though here it's just variables)
    res.json({
      success: true,
      message: "System wiped and will re-initialize on next load.",
    });

    // Optional: delay exit to allow response to be sent
    setTimeout(() => {
      process.exit(0);
    }, 1000);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Reset Database API
app.post("/api/database/reset", requireAdminAuth, async (req, res) => {
  try {
    if (fs.existsSync(dbSqlitePath)) {
      fs.unlinkSync(dbSqlitePath);
    }
    try {
      sqliteDb.exec("DELETE FROM kv;");
    } catch (e) {}
    const freshDb = readSqliteDb();
    res.json({
      success: true,
      message: "Database reset to empty template successfully.",
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// AESTHETIC TELEGRAM WEB APP SUBSCRIPTION COPY CONTAINER
app.get("/copy", (req, res) => {
  let botNickname = "دالتون";
  try {
    const db = readSqliteDb();
    if (db.settings) {
      let pcObj: any = {};
      if (db.settings.panel_config) {
        try {
          pcObj = JSON.parse(db.settings.panel_config);
          if (pcObj.botNickname) {
            botNickname = pcObj.botNickname;
          }
        } catch (err) {}
      }
      
      // Dynamic host domain auto-detection & registration for Python Bot synchrony
      const host = req.headers.host;
      if (host) {
        const protocol =
          req.headers["x-forwarded-proto"] || (req.secure ? "https" : "http");
        const dynamicUrl = `${protocol}://${host}`;
        if (pcObj.botWebUrl !== dynamicUrl) {
          pcObj.botWebUrl = dynamicUrl;
          db.settings.panel_config = JSON.stringify(pcObj);
          writeSqliteDb(db);
        }
      }
    }
  } catch (err) {
    console.error("[Dynamic Host/Nickname Load Failed]", err);
  }

  const link = (req.query.link as string) || "";

  res.send(`
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>دریافت لینک اتصال ${botNickname}</title>
    <!-- Tailwind CSS Play CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Telegram Web App SDK -->
    <script src="https://telegram.org/js/telegram-web-app.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;600;800&family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Vazirmatn', 'Inter', sans-serif;
            background-color: #080512;
            overflow-x: hidden;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in { animation: fadeIn 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        .animate-slide-up { animation: slideUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        .scrollbar-none::-webkit-scrollbar { display: none; }
    </style>
</head>
<body class="flex flex-col items-center justify-between min-h-screen text-slate-100 p-4 select-none relative">
    <!-- Visual Ambient Glow Lights -->
    <div class="absolute -top-10 -left-10 w-48 h-48 bg-purple-600/10 rounded-full blur-[80px] pointer-events-none"></div>
    <div class="absolute -bottom-10 -right-10 w-64 h-64 bg-indigo-600/10 rounded-full blur-[80px] pointer-events-none"></div>
    
    <!-- Top Brand Logo Header -->
    <div class="w-full flex flex-col items-center mt-6 z-10 animate-fade-in">
         <div class="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 flex items-center justify-center shadow-[0_0_20px_rgba(139,92,246,0.25)] mb-3">
          <svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101" />
            <path stroke-linecap="round" stroke-linejoin="round" d="M10.172 13.828a4 4 0 015.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
          </svg>
        </div>
        <h1 class="text-xl font-extrabold text-white tracking-wide">روتر اختصاصی ${botNickname}</h1>
        <p class="text-[10px] text-indigo-400 mt-1 font-semibold tracking-widest uppercase">${botNickname} Subscription Gateway</p>
    </div>

    <!-- Main Content Glass Box -->
    <div class="w-full max-w-sm bg-slate-900/60 backdrop-blur-xl border border-indigo-500/20 rounded-3xl p-6 shadow-[0_20px_50px_rgba(0,0,0,0.5)] z-10 my-4 space-y-5 animate-slide-up">
        <div id="toast" class="hidden fixed top-6 right-1/2 translate-x-1/2 z-50 bg-emerald-500 text-white text-xs font-semibold px-4 py-2.5 rounded-full shadow-lg flex items-center gap-1.5 transition-all duration-300 transform scale-90 opacity-0">
          <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" viewBox="0 0 20 20" fill="currentColor">
            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
          </svg>
          <span dir="rtl">لینک با موفقیت کپی شد! ✅</span>
        </div>

        <div class="space-y-2">
            <label class="text-xs font-bold text-slate-400 flex items-center gap-1.5 mr-1 justify-between">
              <span>🔗 لینک اشتراک سابسکریپشن:</span>
              <span class="text-[10px] text-pink-400/80 font-mono">VLESS / X-UI Link</span>
            </label>
            <!-- Link Display Area -->
            <div class="relative group">
              <textarea id="subLinkTextarea" readonly class="w-full h-28 p-3.5 bg-black/40 border border-slate-700/50 rounded-xl text-left text-xs font-mono text-zinc-300 resize-none break-all outline-none focus:border-indigo-500/50 transition scrollbar-none" style="direction: ltr; font-family: 'Inter', monospace;"></textarea>
              <div class="absolute inset-x-0 bottom-0 h-6 bg-gradient-to-t from-black/20 to-transparent rounded-b-xl pointer-events-none"></div>
            </div>
        </div>

        <!-- Copy Action Button -->
        <button id="copyBtn" class="w-full py-4 px-5 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white text-sm font-extrabold flex items-center justify-center gap-2 shadow-[0_10px_25px_-5px_rgba(124,58,237,0.4)] hover:brightness-110 active:scale-95 transition transform duration-150 cursor-pointer">
          <svg xmlns="http://www.w3.org/2000/svg" id="copyIcon" class="w-5 h-5 text-indigo-100" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
            <path stroke-linecap="round" stroke-linejoin="round" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
          </svg>
          <svg xmlns="http://www.w3.org/2000/svg" id="checkIcon" class="w-5 h-5 text-emerald-300 hidden animate-bounce" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="3">
            <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
          </svg>
          <span id="btnText">کپی کردن لینک اشتراک</span>
        </button>

        <p class="text-[10px] text-center text-slate-400 font-medium leading-relaxed px-1">
          💡 این لینک را کپی کرده و در برنامه کلاینت (مانند v2rayNG ،V2box ،Happ یا Streisand) اضافه نمایید تا تمام کانفیگ‌های فعال به طور خودکار بارگذاری شوند.
        </p>
    </div>

    <!-- Bottom Close Button Area -->
    <div class="w-full max-w-sm px-4 mb-6 z-10">
        <button id="closeBtn" class="w-full py-3.5 px-4 bg-slate-900/60 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer">
          <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
            <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
          <span>بستن پنجره</span>
        </button>
    </div>

    <script>
        const WebApp = window.Telegram?.WebApp;
        if (WebApp) {
            WebApp.ready();
            WebApp.expand();
        }

        const subLink = decodeURIComponent("${encodeURIComponent(link)}");
        const textarea = document.getElementById('subLinkTextarea');
        textarea.value = subLink;

        const copyBtn = document.getElementById('copyBtn');
        const copyIcon = document.getElementById('copyIcon');
        const checkIcon = document.getElementById('checkIcon');
        const btnText = document.getElementById('btnText');
        const toast = document.getElementById('toast');

        copyBtn.addEventListener('click', () => {
            if (!subLink) return;
            
            textarea.select();
            textarea.setSelectionRange(0, 99999);
            
            const performCopy = () => {
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(subLink).then(handleSuccess).catch(fallbackCopy);
                } else {
                    fallbackCopy();
                }
            };

            const fallbackCopy = () => {
                try {
                    document.execCommand('copy');
                    handleSuccess();
                } catch(err) {
                    // console.error(err);
                }
            };

            performCopy();
        });

        function handleSuccess() {
            if (WebApp?.HapticFeedback) {
                WebApp.HapticFeedback.notificationOccurred('success');
            }

            copyIcon.classList.add('hidden');
            checkIcon.classList.remove('hidden');
            btnText.textContent = 'لینک با موفقیت کپی شد! ✅';
            copyBtn.classList.remove('from-purple-600', 'to-indigo-600');
            copyBtn.classList.add('from-emerald-600', 'to-green-600', 'shadow-[0_10px_25px_-5px_rgba(16,185,129,0.3)]');

            toast.classList.remove('hidden', 'scale-90', 'opacity-0');
            toast.classList.add('scale-100', 'opacity-100');

            setTimeout(() => {
                copyIcon.classList.remove('hidden');
                checkIcon.classList.add('hidden');
                btnText.textContent = 'کپی کردن لینک اشتراک';
                copyBtn.classList.add('from-purple-600', 'to-indigo-600');
                copyBtn.classList.remove('from-emerald-600', 'to-green-600', 'shadow-[0_10px_25px_-5px_rgba(16,185,129,0.3)]');
                
                toast.classList.add('scale-90', 'opacity-0');
                setTimeout(() => toast.classList.add('hidden'), 350);
            }, 3000);
        }

        const closeBtn = document.getElementById('closeBtn');
        closeBtn.addEventListener('click', () => {
            if (WebApp) {
                WebApp.close();
            } else {
                window.close();
            }
        });
    </script>
</body>
</html>
  `);
});

const sanitizeTicketsList = (tickets: any[]): any[] => {
  if (!Array.isArray(tickets)) return [];
  return tickets.map((t: any) => {
    const createdAt = t.createdAt || t.updatedAt || new Date().toISOString();
    const updatedAt = t.updatedAt || t.createdAt || new Date().toISOString();
    const subject = t.subject || "درخواست پشتیبانی";
    const status = t.status || "open";
    
    const messages = Array.isArray(t.messages) ? t.messages.map((m: any) => {
      const msgText = m.message || m.text || "";
      const msgDate = m.date || m.timestamp || new Date().toISOString();
      return {
        ...m,
        message: msgText,
        text: msgText,
        date: msgDate,
        timestamp: msgDate
      };
    }) : [];

    const firstMsgText = messages.length > 0 ? messages[0].text : "";
    const lastMsg = messages.length > 0 ? messages[messages.length - 1].text : "";
    const lastAdminReply = [...messages].reverse().find((m: any) => m.sender === "admin")?.text || "";

    return {
      ...t,
      subject,
      status,
      createdAt,
      updatedAt,
      messages,
      message: t.message || firstMsgText,
      lastMessage: t.lastMessage || lastMsg,
      reply: t.reply || lastAdminReply
    };
  });
};

// 1. Get complete aggregated database snapshot
app.get("/api/data", requireAdminAuth, async (req, res) => {
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  res.setHeader("Pragma", "no-cache");
  try {
    const db = readSqliteDb();
    if ((db as any)._isReadError) {
      return res.status(503).json({ success: false, error: "دیتابیس در حال حاضر مشغول یا در وضعیت خطا است. لطفاً مجدداً تلاش کنید." });
    }
    const settings = getSystemSettings(db);

    // Ensure admins list is properly formatted
    if (!settings.admins || !Array.isArray(settings.admins)) {
      settings.admins = [];
    }

    console.log(
      "[DEBUG] /api/data returned settings.botToken:",
      settings.botToken,
    );

    res.json({
      success: true,
      users: db.users,
      transactions: db.transactions,
      keys: db.subscription_keys,
      inbounds: db.inbounds,
      customButtons: db.custom_buttons,
      vpnPlans: db.vpn_plans || [],
      giftCodes: db.gift_codes || [],
      promoCodes: db.promo_codes || [],
      tickets: sanitizeTicketsList(db.tickets || []),
      colleaguePackages: db.colleague_packages || [],
      colleagueAccounts: db.colleague_accounts || [],
      colleagueCategories: db.colleague_categories || [],
      plan_categories: db.plan_categories || [],
      logs: db.logs || [],
      settings,
      isNewInstall: db.isNewInstall === true,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 2. Save panel configuration
// --- Colleague Endpoints ---
// [EXTRACTED → src/routes/admin.ts] colleague categories

// [EXTRACTED → src/routes/admin.ts] colleague accounts CRUD

app.post("/api/colleague-accounts/sync", requireAdminAuth, async (req, res) => {
  try {
    const pythonCode = `
import bot
try:
    bot.sync_all_colleagues()
    print("SUCCESS")
except Exception as e:
    print(f"ERROR: {e}")
`;
    const tempPy = path.join(os.tmpdir(), `sync_col_${Math.random().toString(36).substring(7)}.py`);
    fs.writeFileSync(tempPy, pythonCode, "utf8");
    exec(`python3 "${tempPy}"`, { encoding: "utf8" }, () => {
      try { if (fs.existsSync(tempPy)) fs.unlinkSync(tempPy); } catch(e){}
      const db = readSqliteDb();
      res.json({
        success: true,
        colleagueAccounts: db.colleague_accounts || [],
        keys: db.subscription_keys || []
      });
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// --- TICKETS ENDPOINTS ---
app.post("/api/tickets/create", (req, res) => {
  try {
    const { userId, username, subject, message } = req.body;
    const db = readSqliteDb();
    if (!db.tickets) db.tickets = [];

    const ticketId = "TKB-" + Math.floor(Math.random() * 9000 + 1000);
    const newTicket = {
      id: ticketId,
      userId: Number(userId),
      username: username || "user_" + userId,
      subject: subject,
      status: "open",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: [
        {
          sender: "user",
          message: message,
          date: new Date().toISOString(),
        },
      ],
    };

    db.tickets.push(newTicket);
    writeSqliteDb(db);

    res.json({
      success: true,
      ticketId,
      tickets: sanitizeTicketsList(db.tickets || []),
      ticket: sanitizeTicketsList([newTicket])[0],
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post("/api/tickets/delete", requireAdminAuth, (req, res) => {
  try {
    const { ticketId } = req.body;
    const db = readSqliteDb();
    if (!db.tickets) db.tickets = [];

    db.tickets = db.tickets.filter((t: any) => t.id !== ticketId);
    writeSqliteDb(db);

    res.json({ success: true, tickets: sanitizeTicketsList(db.tickets || []) });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post("/api/tickets/reply", requireAdminAuth, (req, res) => {
  try {
    const { ticketId, reply } = req.body;
    const db = readSqliteDb();
    if (!db.tickets) db.tickets = [];

    const ticketIdx = db.tickets.findIndex((t: any) => t.id === ticketId);
    if (ticketIdx >= 0) {
      const ticket = db.tickets[ticketIdx];
      ticket.messages.push({
        sender: "admin",
        message: reply,
        date: new Date().toISOString(),
      });
      ticket.status = "answered";
      ticket.updatedAt = new Date().toISOString();

      writeSqliteDb(db);

      // Notify the user on Telegram of the admin reply
      const settings = getSystemSettings(db);
      if (settings.botToken && ticket.userId && isBotNotificationEnabled(db, "notifyUserTicketReply", true)) {
        const notifyMsg =
          `📨 <b>پاسخ پشتیبانی به تیکت شما!</b>\n\n` +
          `🆔 <b>شناسه تیکت:</b> <code>${ticket.id}</code>\n` +
          `💬 <b>متن پاسخ:</b>\n` +
          `<blockquote>${reply}</blockquote>\n\n` +
          `🍀 <i>از اعتماد و شکیبایی شما سپاسگزاریم.</i>`;

        const replyMarkup = {
          inline_keyboard: [
            [
              {
                text: "✍️ پاسخ به این تیکت",
                callback_data: `tkt_reply_${ticket.id}`,
              },
            ],
          ],
        };

        sendTelegramMessage(
          settings.botToken,
          ticket.userId,
          notifyMsg,
          replyMarkup,
        ).catch((err) => {
          console.error("[Telegram Ticket Reply Auto-Notify Error]", err);
        });
      }

      res.json({ success: true, ticket: sanitizeTicketsList([ticket])[0] });
    } else {
      res.status(404).json({ success: false, error: "Ticket not found" });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post("/api/tickets/close", requireAdminAuth, (req, res) => {
  try {
    const { ticketId } = req.body;
    const db = readSqliteDb();
    if (!db.tickets) db.tickets = [];

    const ticketIdx = db.tickets.findIndex((t: any) => t.id === ticketId);
    if (ticketIdx >= 0) {
      const ticket = db.tickets[ticketIdx];
      ticket.status = "closed";
      ticket.updatedAt = new Date().toISOString();
      writeSqliteDb(db);

      // Notify the user on Telegram of ticket closure
      const settings = getSystemSettings(db);
      if (settings.botToken && ticket.userId) {
        const nickname = settings.botNickname || "دالتون بات";
        const notifyMsg =
          `🔒 <b>تیکت شما بسته شد!</b>\n\n` +
          `🆔 <b>شناسه تیکت:</b> <code>${ticket.id}</code>\n\n` +
          `💬 تیکت شما توسط پشتیبانی فنی ${nickname} بررسی و بسته شد.\n` +
          `اگر همچنان نیاز به راهنمایی بیشتری دارید، می‌توانید تیکت جدیدی در ربات ثبت فرمایید.`;
        sendTelegramMessage(settings.botToken, ticket.userId, notifyMsg).catch(
          (err) => {
            console.error("[Telegram Ticket Close Auto-Notify Error]", err);
          },
        );
      }

      res.json({ success: true, ticket: sanitizeTicketsList([ticket])[0] });
    } else {
      res.status(404).json({ success: false, error: "Ticket not found" });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- REGEN UUID & TRANSFER KEY CONNECTIONS ---
async function handleRegenerateKeyLogic(id: string) {
  const db = readSqliteDb();
  const subIdx = (db.subscription_keys || []).findIndex((k: any) => String(k.id) === String(id) || String(k.clientUuid) === String(id));
  if (subIdx < 0) {
    return { success: false, status: 404, error: "اشتراک مورد نظر یافت نشد." };
  }

  const key = db.subscription_keys[subIdx];
  const clientName = key.clientName || key.clientEmail || key.planName || "";
  const settings = getSystemSettings(db);

  let resetResult: any;
  if (!clientName) {
    // Fallback: This is a custom/manual key, regenerate locally in DB immediately
    const crypto = await import("crypto");
    const newUuid = crypto.randomUUID();
    const newSubId = crypto.randomBytes(8).toString("hex");
    const activeServers = getActiveServers(settings);
    let chosenServer = activeServers.length > 0 ? activeServers[0] : null;
    if (key.serverId) {
      const found = activeServers.find((s: any) => String(s.id) === String(key.serverId));
      if (found) {
        chosenServer = found;
      }
    }
    const subBase =
      chosenServer && chosenServer.subUrl && chosenServer.subUrl.trim() !== ""
        ? normalizeXuiUrl(chosenServer.subUrl)
        : chosenServer
          ? normalizeXuiUrl(chosenServer.panelUrl)
          : "https://vpn.daltoon.online";
    const subLink = `${subBase}/sub/${newSubId}`;
    resetResult = { success: true, clientUuid: newUuid, subLink };
  } else {
    resetResult = await resetVpnClientUuidApi(clientName, key.serverId);
  }

  if (resetResult.success) {
    key.clientUuid = resetResult.clientUuid || key.clientUuid;
    key.subLink = resetResult.subLink || key.subLink;

    // Regenerate direct VLESS config strings with the new UUID
    try {
      const vlessRes = generateVlessConfigsForClient(
        key.clientUuid,
        clientName || "user",
        key.serverId,
        settings,
        key.activeInboundIds
      );
      if (vlessRes && vlessRes.vlessConfigs && vlessRes.vlessConfigs.length > 0) {
        key.vlessConfigs = vlessRes.vlessConfigs;
      }
    } catch (e) {}

    db.subscription_keys[subIdx] = key;

    // Sync in user configs array
    if (key.userId) {
      const u = (db.users || []).find((usr: any) => Number(usr.userId) === Number(key.userId));
      if (u && Array.isArray(u.configs)) {
        const cIdx = u.configs.findIndex((c: any) => String(c.id) === String(id) || String(c.uuid) === String(id));
        if (cIdx >= 0) {
          u.configs[cIdx].uuid = key.clientUuid;
          u.configs[cIdx].subLink = key.subLink;
          u.configs[cIdx].vlessConfigs = key.vlessConfigs;
        }
      }
    }

    writeSqliteDb(db);

    try {
      const userInfoText = getUserDisplayInfo(key.userId, clientName, db);
      const srvDisplay = getServerDisplayForNotification(key.serverId, settings, db, key.subLink);
      const shamsiTime = formatShamsiDate(new Date(), true);
      const resetMsg =
        `🔄 <b>[اعلان تغییر لینک / بازنشانی UUID]</b>\n\n` +
        `${userInfoText}\n` +
        `🌐 <b>سرور:</b> ${srvDisplay}\n` +
        `🔑 <b>شناسه جدید (UUID):</b> <code>${key.clientUuid}</code>\n` +
        `⏱ <b>زمان:</b> ${shamsiTime}`;
      sendAdminNotification(resetMsg, settings).catch(() => {});
    } catch (e) {
      console.error("[regenerate uuid notify error]", e);
    }

    // Send Telegram Notification to user if botToken configured
    if (key.userId && settings.botToken) {
      const userMsg =
        `🔄 <b>لینک اتصال اشتراک شما تغییر یافت</b>\n\n` +
        `📦 <b>پلن:</b> ${key.planName || "اشتراک اختصاصی"}\n` +
        `🔑 <b>شناسه جدید (UUID):</b>\n<code>${key.clientUuid}</code>\n\n` +
        `🔗 <b>لینک ساب جدید شما:</b>\n<code>${key.subLink}</code>\n\n` +
        `⚠️ <i>اتصال لینک قبلی شما قطع شد. لطفاً لینک جدید را در برنامه خود وارد و بروزرسانی نمایید.</i>`;
      sendTelegramMessage(settings.botToken, key.userId, userMsg).catch(() => {});
    }

    return {
      success: true,
      key,
      newUuid: key.clientUuid,
      newSubLink: key.subLink,
      vlessConfigs: key.vlessConfigs || [],
    };
  } else {
    return {
      success: false,
      status: 500,
      error: resetResult.error || "خطا در بازنشانی و تغییر لینک در پنل سرور",
    };
  }
}

app.post("/api/subscription-keys/regenerate-uuid", async (req, res) => {
  try {
    const { id } = req.body;
    const result = await handleRegenerateKeyLogic(id);
    if (result.success) {
      res.json(result);
    } else {
      res.status(result.status || 500).json(result);
    }
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post("/api/subscription-keys/:id/regenerate", async (req, res) => {
  try {
    const id = req.params.id || req.body.id;
    const result = await handleRegenerateKeyLogic(id);
    if (result.success) {
      res.json(result);
    } else {
      res.status(result.status || 500).json(result);
    }
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post("/api/subscription-keys/transfer-ownership", requireAdminAuth, async (req, res) => {
  try {
    const { id, targetUserIdOrUsername } = req.body;
    const db = readSqliteDb();

    const cleanTarget = String(targetUserIdOrUsername).replace("@", "").trim();
    const targetUser = db.users.find(
      (u: any) =>
        String(u.userId) === cleanTarget ||
        String(u.username).toLowerCase() === cleanTarget.toLowerCase(),
    );

    if (!targetUser) {
      return res.status(400).json({
        success: false,
        error:
          "کاربر مقصد در سیستم یافت نشد. دوست شما باید حداقل یکبار دکمه /start را در ربات زده باشد.",
      });
    }

    const subIdx = db.subscription_keys.findIndex((k: any) => k.id === id);
    if (subIdx >= 0) {
      const key = db.subscription_keys[subIdx];
      const oldUserId = key.userId;

      // Transfer
      key.userId = targetUser.userId;
      db.subscription_keys[subIdx] = key;

      // Recalculate
      const oldUser = db.users.find((u: any) => u.userId === oldUserId);
      if (oldUser) {
        oldUser.activePlansCount = db.subscription_keys.filter(
          (k: any) => k.userId === oldUserId && k.status === "active",
        ).length;
      }
      targetUser.activePlansCount = db.subscription_keys.filter(
        (k: any) => k.userId === targetUser.userId && k.status === "active",
      ).length;

      writeSqliteDb(db);
      res.json({
        success: true,
        key,
        targetUsername: targetUser.username || String(targetUser.userId),
      });
    } else {
      res
        .status(404)
        .json({ success: false, error: "کانفیگ مورد نظر یافت نشد." });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post("/api/transactions/instant-pay", requireAdminAuth, async (req, res) => {
  try {
    const { userId, amount, description } = req.body;
    const db = readSqliteDb();

    const user = db.users.find((u: any) => u.userId === Number(userId));
    if (!user) {
      return res.status(404).json({ success: false, error: "User not found" });
    }

    const amountNum = Number(amount);
    user.walletBalance = Number(user.walletBalance) + amountNum;

    const newTx = {
      id: "TX-AUTO-" + Math.floor(Math.random() * 90000 + 10000),
      userId: Number(userId),
      username: user.username,
      amount: amountNum,
      receiptImage: "bg-gradient-to-br from-emerald-500 to-teal-700",
      status: "approved",
      date: new Date().toISOString(),
      description: description || "پرداخت خودکار آنلاین",
    };

    db.transactions.unshift(newTx);
    writeSqliteDb(db);
    res.json({
      success: true,
      userWalletBalance: user.walletBalance,
      tx: newTx,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- AI Chatbot Feature ---
let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    let key: string | undefined = undefined;

    // 1. Try to load from database settings first (User Preferred)
    try {
      const db = readSqliteDb();
      // Ensure we check both stringified panel_config and direct settings for robustness
      let settingsObj = db.settings || {};
      if (db.settings && db.settings.panel_config) {
        try {
          const cfg = JSON.parse(db.settings.panel_config);
          settingsObj = { ...settingsObj, ...cfg };
        } catch (e) {}
      }

      if (settingsObj.geminiApiKey && settingsObj.geminiApiKey.trim() !== "") {
        key = settingsObj.geminiApiKey.trim();
        console.log(
          "[System] Successfully loaded GEMINI_API_KEY from database settings.",
        );
      }
    } catch (e: any) {
      console.warn(
        "[System] Could not load API key from database:",
        e.message,
      );
    }

    // 2. Fallback to process.env if not found in DB
    if (!key) {
      key = process.env.GEMINI_API_KEY;
      if (key)
        console.log(
          "[System] Using GEMINI_API_KEY from environment variables.",
        );
    }

    // 3. Last fallback: Direct .env file parsing (for local dev environments)
    if (!key) {
      try {
        const envPaths = [
          path.resolve(process.cwd(), ".env"),
          path.resolve(_dirname, ".env"),
          path.resolve(_dirname, "..", ".env"),
          "/.env",
        ];
        for (const envPath of envPaths) {
          if (fs.existsSync(envPath)) {
            const content = fs.readFileSync(envPath, "utf8");
            const match = content.match(
              /GEMINI_API_KEY\s*=\s*["']?([^"'\r\n]+)["']?/,
            );
            if (match && match[1]) {
              key = match[1].trim();
              console.log(
                `[System] Loaded GEMINI_API_KEY from .env file: ${envPath}`,
              );
              break;
            }
          }
        }
      } catch (e: any) {}
    }

    if (key) {
      key = key.trim();
      // Remove accidental quotes if they exist in file/env
      if (
        (key.startsWith('"') && key.endsWith('"')) ||
        (key.startsWith("'") && key.endsWith("'"))
      ) {
        key = key.substring(1, key.length - 1);
      }
      key = key.trim();
    }

    if (!key || key === "") {
      throw new Error(
        "دستیار هوشمند فعال نیست. لطفا کلید (GEMINI_API_KEY) را در تنظیمات داشبورد ست کنید.",
      );
    }

    aiClient = new GoogleGenAI({
      apiKey: key,
    });
  }
  return aiClient;
}

// Helper to perform web search using Google Custom Search API or Brave Search API
async function performWebSearch(query: string, googleKey?: string, cx?: string, braveKey?: string): Promise<string> {
  if (!query) return "";
  let resultsText = "";

  // 1. Try Google Custom Search API
  if (googleKey && googleKey.trim() !== "") {
    const searchCx = cx && cx.trim() !== "" ? cx.trim() : "";
    try {
      console.log(`[Web Search] Querying Google Custom Search API for: "${query}"`);
      const url = `https://www.googleapis.com/customsearch/v1?key=${encodeURIComponent(googleKey.trim())}&cx=${encodeURIComponent(searchCx)}&q=${encodeURIComponent(query)}`;
      const res = await fetch(url);
      if (res.ok) {
        const data: any = await res.json();
        const items = data.items || [];
        if (items.length > 0) {
          resultsText += `نتایج جستجوی گوگل برای "${query}":\n`;
          items.slice(0, 5).forEach((item: any, idx: number) => {
            resultsText += `[${idx + 1}] عنوان: ${item.title}\nتوضیحات: ${item.snippet}\nلینک: ${item.link}\n\n`;
          });
        }
      } else {
        const errText = await res.text();
        console.error(`[Web Search] Google Search API error:`, errText);
      }
    } catch (err) {
      console.error(`[Web Search] Failed Google Search:`, err);
    }
  }

  // 2. Try Brave Search API if Google didn't return results
  if (resultsText === "" && braveKey && braveKey.trim() !== "") {
    try {
      console.log(`[Web Search] Querying Brave Search API for: "${query}"`);
      const url = `https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}`;
      const res = await fetch(url, {
        headers: {
          "Accept": "application/json",
          "Accept-Encoding": "gzip",
          "X-Subscription-Token": braveKey.trim()
        }
      });
      if (res.ok) {
        const data: any = await res.json();
        const items = data.web?.results || [];
        if (items.length > 0) {
          resultsText += `نتایج جستجوی وب (Brave) برای "${query}":\n`;
          items.slice(0, 5).forEach((item: any, idx: number) => {
            resultsText += `[${idx + 1}] عنوان: ${item.title}\nتوضیحات: ${item.description}\nلینک: ${item.url}\n\n`;
          });
        }
      } else {
        const errText = await res.text();
        console.error(`[Web Search] Brave Search API error:`, errText);
      }
    } catch (err) {
      console.error(`[Web Search] Failed Brave Search:`, err);
    }
  }

  return resultsText;
}

app.post("/api/ai/chat", requireAdminAuth, async (req, res) => {
  try {
    const { message, userId, type } = req.body;
    const isSupport = type === "support" || !type;

    if (!message) {
      return res.status(400).json({ error: "Message is required." });
    }

    const dbData = readSqliteDb();
    const systemSettings = getSystemSettings(dbData);

    const activeUsersCount = (dbData.users || []).filter(
      (u: any) => u.status === "active",
    ).length;

    const aiSearchEnabled = systemSettings.aiSearchEnabled !== false;

    // Custom Web Search Context (Google / Brave Search fallback for custom models)
    let injectedSearchContext = "";
    if (aiSearchEnabled) {
      const googleKey = systemSettings.googleSearchApiKey || process.env.GOOGLE_SEARCH_API_KEY || "";
      const googleCx = systemSettings.googleSearchCx || process.env.GOOGLE_SEARCH_CX || "";
      const braveKey = systemSettings.braveSearchApiKey || process.env.BRAVE_SEARCH_API_KEY || "";
      
      if ((googleKey && googleKey.trim() !== "") || (braveKey && braveKey.trim() !== "")) {
        const searchResults = await performWebSearch(message, googleKey, googleCx, braveKey);
        if (searchResults && searchResults.trim() !== "") {
          injectedSearchContext = `\n\n[اطلاعات زنده جستجوی وب]\nاطلاعات زیر آخرین نتایج جستجوی اینترنت درباره سوال کاربر است. از این اطلاعات برای پاسخ به سوالات مربوط به رویدادهای روز استفاده کنید:\n${searchResults}`;
        }
      }
    }

    let geminiApiKey = systemSettings.geminiApiKey || "";

    // Fallback to process.env if not set in DB
    if (!geminiApiKey || geminiApiKey.trim() === "") {
      geminiApiKey = process.env.GEMINI_API_KEY || "";
    }

    let geminiBaseUrl = systemSettings.geminiBaseUrl || "";
    let customAiApiKey = systemSettings.customAiApiKey || "";
    let aiBaseUrl = systemSettings.aiBaseUrl || "";
    let aiModelName = systemSettings.aiModelName || "";

    // Determine target key and parameters
    let apiKeyToUse = "";
    let finalBaseUrl = "";
    let finalModelName = "";

    if (isSupport) {
      // Support assistant strictly uses geminiApiKey
      apiKeyToUse = geminiApiKey.trim();
      finalBaseUrl = geminiBaseUrl ? geminiBaseUrl.trim() : "";
      if (!apiKeyToUse || apiKeyToUse.trim() === "") {
        return res.status(400).json({
          error:
            "کلید API جیمینای ثبت نشده است. لطفاً ابتدا در تنظیمات داشبورد کلید معتبر را وارد کنید.",
        });
      }
    } else {
      // General AI strictly uses customAiApiKey
      apiKeyToUse = customAiApiKey.trim();
      finalBaseUrl = aiBaseUrl ? aiBaseUrl.trim() : "";
      finalModelName = aiModelName ? aiModelName.trim() : "";

      if (!apiKeyToUse || apiKeyToUse.trim() === "") {
        return res.status(400).json({
          error:
            "کلید API هوش مصنوعی عمومی تنظیم نشده است. لطفاً تنظیمات را بررسی کنید.",
        });
      }
    }

    // Support Assistant uses Gemini, General AI uses the custom API key (or auto-detects if Custom API key happens to be Gemini)
    const isDirectGemini = isSupport
      ? true
      : apiKeyToUse.startsWith("AIzaSy") &&
        (!finalBaseUrl || finalBaseUrl === "");

    // Prepare system instruction prompt based on bot identity or general purpose
    let systemPrompt = "";
    if (isSupport) {
      const pricingBoxes = systemSettings.customPricingBoxes || [];
      const serversList = (systemSettings.servers || []).map((s: any) => ({ id: s.id, name: s.name }));
      
      systemPrompt = `شما یک دستیار هوش مصنوعی مودب و پاسخگو متعلق به ربات تلگرام به نام "${systemSettings.botNickname || "دالتون بات"}" (Daltoon Bot) هستید. 
شما باید به سوالات مرتبط با خدمات و خرید از ربات پاسخ دهید.

مهم‌ترین نکته: در صورتی که کاربر نیاز به پشتیبانی انسانی، شارژ ولت، رفع مشکل درگاه، قطعی یا خرید دارد، او را راهنمایی کنید که از منوی اصلی ربات از دکمه «🎫 ثبت تیکت پشتیبانی» استفاده کند.

اطلاعات فعلی سیستم:
- تعرفه های ثابت: ${JSON.stringify(dbData.vpn_plans || [])}
- ویژگی ساخت کانفیگ با حجم دلخواه (سفارشی): 
  کاربران می‌توانند علاوه بر خرید تعرفه‌های ثابت بالا، کانفیگ با حجم ترافیک (گیگابایت) و روزهای اعتبار کاملاً سفارشی و دلخواه خود بسازند.
  روش استفاده در ربات: کاربر باید به منوی اصلی برود، دکمه «🛍️ خرید سرویس» (یا خرید سرویس جدید) را انتخاب کند، سرور موردنظر خود را انتخاب کند، و سپس روی دکمه «✨ ساخت کانفیگ با حجم دلخواه» کلیک کند. ربات از او می‌خواهد که میزان حجم (گیگابایت) و مدت زمان (روزها) و یک نام کاربری دلخواه وارد کند.
  فرمول محاسبه قیمت: هزینه نهایی = (حجم به گیگابایت * قیمت هر گیگابایت) + (تعداد روزها * قیمت هر روز)
  به طور پیش‌فرض قیمت هر گیگابایت ترافیک 3,000 تومان و قیمت هر روز اعتبار 2,000 تومان است (مگر اینکه برای آن سرور خاص قیمت متفاوتی تنظیم شده باشد).
- اطلاعات جعبه‌های قیمت‌گذاری دلخواه سرورها: ${JSON.stringify(pricingBoxes)}
- لیست سرورهای فعال: ${JSON.stringify(serversList)}
- تعداد کاربران: ${activeUsersCount}
- راهنما: ${systemSettings.supportText || ""}${injectedSearchContext}`;
    } else {
      systemPrompt = `شما یک هوش مصنوعی عمومی هستید که به کاربر در گفتگوهای عمومی کمک می‌کنید. پاسخ‌ها را به زبان فارسی روان و مودبانه ارائه دهید.${injectedSearchContext}`;
    }

    if (isDirectGemini) {
      // Direct Google Gemini API call
      console.log(
        `[AI Chat] Making direct Google Gemini API call (isSupport: ${isSupport})`,
      );
      const ai = new GoogleGenAI({ apiKey: apiKeyToUse, ...(finalBaseUrl ? { httpOptions: { baseUrl: finalBaseUrl } } : {}) });

      const modelName = finalModelName || "gemini-2.5-flash";
      
      const configObj: any = {
        systemInstruction: systemPrompt,
        temperature: 0.7,
      };

      if (aiSearchEnabled) {
        configObj.tools = [{ googleSearch: {} }];
      }

      const response = await ai.models.generateContent({
        model: modelName,
        contents: message,
        config: configObj,
      });

      if (response && response.text) {
        let replyText = response.text;
        
        // Extract references if available
        const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
        if (chunks && chunks.length > 0) {
          let refs = "\n\n🌐 **منابع جستجو:**\n";
          let hasRefs = false;
          const seenUris = new Set<string>();
          chunks.forEach((chunk: any) => {
            if (chunk.web && chunk.web.uri && !seenUris.has(chunk.web.uri)) {
              seenUris.add(chunk.web.uri);
              refs += `- [${chunk.web.title || "منبع"}](${chunk.web.uri})\n`;
              hasRefs = true;
            }
          });
          if (hasRefs) {
            replyText += refs;
          }
        }

        return res.json({ response: replyText });
      } else {
        throw new Error("پاسخی از سرور جیمینای دریافت نشد.");
      }
    } else {
      // OpenAI-compatible / Custom endpoint routing (e.g. AwanLLM, DeepSeek, etc.)
      if (!finalBaseUrl) {
        // Auto-detect/default to AwanLLM base URL for non-Gemini keys
        finalBaseUrl = "https://api.awanllm.com/v1";
        if (!finalModelName) {
          finalModelName = "Meta-Llama-3-8B-Instruct";
        }
      }

      const trimmedUrl = finalBaseUrl.replace(/\/$/, "");
      const completionUrl = `${trimmedUrl}/chat/completions`;
      const modelToUse =
        finalModelName && finalModelName.trim() !== ""
          ? finalModelName.trim()
          : "gpt-4o-mini";

      console.log(
        `[AI Chat Custom] Routing to OpenAI Compatible URL: ${completionUrl} with model: ${modelToUse} (isSupport: ${isSupport})`,
      );
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 45000);

      const response = await fetch(completionUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKeyToUse}`,
        },
        body: JSON.stringify({
          model: modelToUse,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: message },
          ],
          temperature: 0.7,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(
          `خطای سرویس‌دهنده هوش مصنوعی (کد ${response.status}): ${errText}`,
        );
      }

      const resData: any = await response.json();
      const responseText = resData.choices?.[0]?.message?.content || "";
      if (responseText) {
        return res.json({ response: responseText });
      } else {
        throw new Error("پاسخ دریافتی از سرور هوش مصنوعی خالی بود.");
      }
    }
  } catch (error: any) {
    console.error("[AI Chat API Error]:", error);
    let errMsg = error.message || "Failed to generate AI response.";
    
    // Sanitize HTML errors
    if (errMsg.toLowerCase().includes("<!doctype") || errMsg.toLowerCase().includes("<html")) {
      errMsg = "خطای ارتباط با سرور هوش مصنوعی (Forbidden/Proxy Error). لطفاً آدرس Base URL یا وضعیت شبکه را بررسی کنید.";
    }

    if (errMsg.startsWith("{")) {
      try {
        const parsed = JSON.parse(errMsg);
        if (parsed.error && parsed.error.message) {
          errMsg = parsed.error.message;
        }
      } catch (e) {}
    }

    if (errMsg.includes("API key not valid")) {
      errMsg = "کلید API ثبت شده نامعتبر است. لطفاً به مدیریت اطلاع دهید.";
    } else if (
      errMsg.toLowerCase().includes("quota") ||
      errMsg.toLowerCase().includes("rate limit") ||
      errMsg.includes("429")
    ) {
      errMsg =
        "محدودیت استفاده از کلید API هوش مصنوعی به پایان رسیده است (Quota Exceeded). لطفاً به مدیریت اطلاع دهید.";
    }

    res.status(500).json({ error: errMsg });
  }
});

app.post("/api/ai/test-key", requireAdminAuth, async (req, res) => {
  try {
    let { apiKey, baseUrl, modelName, type } = req.body;
    if (!apiKey || apiKey.trim() === "") {
      return res
        .status(400)
        .json({ error: "لطفاً ابتدا کلید API را وارد کنید." });
    }

    const trimmedKey = apiKey.trim();
    let finalBaseUrl = baseUrl ? baseUrl.trim() : "";
    let finalModelName = modelName ? modelName.trim() : "";

    // If type is explicitly 'gemini', test as Google Gemini.
    // Otherwise, auto-detect (useful if type is custom but they put a gemini key without base url)
    const isDirectGemini =
      type === "gemini"
        ? true
        : trimmedKey.startsWith("AIzaSy") &&
          (!finalBaseUrl || finalBaseUrl === "");

    if (isDirectGemini) {
      // Test direct Gemini Key
      console.log(`[AI Key Test] Testing direct Gemini API key`);
      const ai = new GoogleGenAI({
        apiKey: trimmedKey,
        ...(finalBaseUrl ? { httpOptions: { baseUrl: finalBaseUrl } } : {})
      });

      const model = finalModelName || "gemini-2.5-flash";
      const response = await ai.models.generateContent({
        model: model,
        contents: "سلام",
        config: {
          maxOutputTokens: 5,
        },
      });

      if (response && response.text) {
        return res.json({
          success: true,
          message: "اتصال با موفقیت برقرار شد! کلید API جیمینای معتبر است.",
        });
      } else {
        throw new Error("پاسخ دریافتی از جیمینای خالی بود.");
      }
    } else {
      // Test OpenAI-compatible / Custom API key (e.g. AwanLLM, DeepSeek, etc.)
      if (!finalBaseUrl) {
        // Auto-detect/default to AwanLLM base URL for custom/OpenAI-compatible keys
        finalBaseUrl = "https://api.awanllm.com/v1";
        if (!finalModelName) {
          finalModelName = "Meta-Llama-3-8B-Instruct";
        }
      }

      const trimmedUrl = finalBaseUrl.replace(/\/$/, "");
      const completionUrl = `${trimmedUrl}/chat/completions`;
      const modelToUse =
        finalModelName && finalModelName.trim() !== ""
          ? finalModelName.trim()
          : "gpt-4o-mini";

      console.log(
        `[AI Key Test] Testing OpenAI compatible API key for model: ${modelToUse} at ${completionUrl}`,
      );

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 45000); // 45s timeout

      const response = await fetch(completionUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${trimmedKey}`,
        },
        body: JSON.stringify({
          model: modelToUse,
          messages: [{ role: "user", content: "سلام" }],
          max_tokens: 5,
        }),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errText = await response.text();
        throw new Error(
          `خطای سرور سرویس‌دهنده (کد ${response.status}): ${errText}`,
        );
      }

      return res.json({
        success: true,
        message: "اتصال با موفقیت برقرار شد! کلید API معتبر است.",
      });
    }
  } catch (err: any) {
    console.error("[AI Key Test Error]:", err);
    let errMsg = err.message || "بررسی کلید API با خطا مواجه شد.";

    // Parse GoogleGenAI JSON error messages to be user-friendly
    if (errMsg.startsWith("{")) {
      try {
        const parsed = JSON.parse(errMsg);
        if (parsed.error && parsed.error.message) {
          errMsg = parsed.error.message;
        }
      } catch (e) {}
    }

    if (
      err.name === "AbortError" ||
      errMsg.includes("aborted") ||
      errMsg.includes("timeout")
    ) {
      errMsg =
        "زمان اتصال به سرور هوش مصنوعی به پایان رسید (Timeout). این مشکل معمولاً ناشی از کندی موقت سرور هوش مصنوعی یا عدم پاسخگویی مناسب فیلترشکن/اینترنت سرور است. لطفاً چند لحظه دیگر دوباره تلاش کنید.";
    } else if (errMsg.includes("API key not valid")) {
      errMsg = "کلید API وارد شده نامعتبر است. لطفاً کلید صحیح را وارد کنید.";
    } else if (errMsg.includes("fetch failed")) {
      errMsg = "خطا در برقراری ارتباط با سرور هوش مصنوعی (Network Error).";
    } else if (
      errMsg.toLowerCase().includes("quota") ||
      errMsg.toLowerCase().includes("rate limit") ||
      errMsg.includes("429")
    ) {
      errMsg =
        "محدودیت استفاده از این کلید به پایان رسیده است (Quota Exceeded). لطفاً کلید دیگری وارد کنید.";
    }

    res.status(500).json({ error: errMsg });
  }
});

// ---------------------------

app.post("/api/gift-codes/edit", requireAdminAuth, (req, res) => {
  const db = readSqliteDb();
  if (!db.gift_codes) db.gift_codes = [];
  const { id, code, amount, maxUsage, durationDays } = req.body;
  if (!id || !code || amount === undefined || maxUsage === undefined) {
    return res.status(400).json({ error: "Missing fields" });
  }

  let updatedCode = null;
  db.gift_codes = db.gift_codes.map((c) => {
    if (c.id === id) {
      updatedCode = {
        ...c,
        code,
        amount: parseInt(amount, 10),
        maxUsage: parseInt(maxUsage, 10),
        durationDays: durationDays ? parseInt(durationDays, 10) : undefined,
      };
      return updatedCode;
    }
    return c;
  });

  if (updatedCode) {
    writeSqliteDb(db);
    res.json({ success: true, item: updatedCode });
  } else {
    res.status(404).json({ error: "Code not found" });
  }
});

app.post("/api/bot/validate-token", requireAdminAuth, async (req, res) => {
  try {
    const { token } = req.body;
    if (!token || typeof token !== "string" || !token.includes(":")) {
      return res.json({
        success: false,
        error: "توکن نامعتبر است (فرمت نامعتبر)",
      });
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 8000);

    try {
      const response = await fetch(
        `https://api.telegram.org/bot${token}/getMe`,
        {
          signal: controller.signal,
        },
      );
      clearTimeout(timeout);

      const data: any = await response.json();
      if (data && data.ok) {
        return res.json({ success: true, bot: data.result });
      } else {
        const errorDesc =
          data && data.description ? data.description : "Unauthorized (401)";
        return res.json({ success: false, error: errorDesc });
      }
    } catch (fetchErr: any) {
      clearTimeout(timeout);
      console.warn(
        "[Token Validation Error] Telegram request timed out or was filtered:",
        fetchErr.message,
      );
      // Because telegram is filtered in Iran, we allow proceeding if a network error occurs
      return res.json({
        success: true,
        warning: true,
        message:
          "به دلیل فیلترینگ تلگرام روی سرور، بررسی خودکار انجام نشد اما تنظیمات ثبت خواهد شد.",
      });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post("/api/settings/verify-ssl", requireAdminAuth, async (req, res) => {
  try {
    const { domain, pubKey, privKey } = req.body;
    
    const db = readSqliteDb();
    const prevSettings = getSystemSettings(db);

    if (!domain && !pubKey && !privKey) {
      if (!db.settings) db.settings = {};
      db.settings.domainName = "";
      db.settings.sslPublicKeyPath = "";
      db.settings.sslPrivateKeyPath = "";
      
      const newConfig = {
        ...prevSettings,
        domainName: "",
        sslPublicKeyPath: "",
        sslPrivateKeyPath: "",
        sslCertificateStatus: "not_configured"
      };
      
      db.settings.panel_config = JSON.stringify(newConfig);
      writeSqliteDb(db);

      // Clean cert files from disk
      try {
        if (fs.existsSync("/root/cert")) {
          const files = fs.readdirSync("/root/cert");
          for (const file of files) {
            fs.rmSync(path.join("/root/cert", file), { recursive: true, force: true });
          }
        }
      } catch(e) {}

      return res.json({ success: true, message: "تنظیمات و فایل‌های سرتیفیکت با موفقیت پاکسازی شدند" });
    }

    if (!domain || !pubKey || !privKey) {
      return res.status(400).json({ success: false, error: "Missing required parameters" });
    }

    if (!fs.existsSync(pubKey) || !fs.existsSync(privKey)) {
      return res.json({ success: false, error: "فایل‌های سرتیفیکت در مسیرهای مشخص‌شده یافت نشدند" });
    }
    
    // Read and verify the cert format
    const pubKeyContent = fs.readFileSync(pubKey, "utf8");
    const privKeyContent = fs.readFileSync(privKey, "utf8");
    
    if (!pubKeyContent.includes("BEGIN CERTIFICATE") || !privKeyContent.includes("PRIVATE KEY")) {
      return res.json({ success: false, error: "فرمت فایل‌های سرتیفیکت معتبر نیست" });
    }
    
    if (!db.settings) db.settings = {};
    db.settings.domainName = domain;
    db.settings.sslPublicKeyPath = pubKey;
    db.settings.sslPrivateKeyPath = privKey;
    
    const newConfig = {
      ...prevSettings,
      domainName: domain,
      sslPublicKeyPath: pubKey,
      sslPrivateKeyPath: privKey,
      sslCertificateStatus: "active"
    };
    
    db.settings.panel_config = JSON.stringify(newConfig);
    writeSqliteDb(db);
    
    res.json({ success: true, message: "با موفقیت ذخیره شد" });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post("/api/settings", requireAdminAuth, async (req, res) => {
  try {
    const payload = { ...req.body };
    if (payload.ownerId) {
      payload.ownerId = Number(payload.ownerId);
    }

    const db = readSqliteDb();

    // Compare admins list to find newly added ones
    const prevSettings = getSystemSettings(db);
    
    // Preserve existing critical fields if not provided in the payload
    const finalPayload = {
      ...prevSettings,
      ...payload
    };
    
    const configValue = JSON.stringify(finalPayload);

    const prevAdmins = prevSettings.admins || [];
    const newAdmins = payload.admins || [];

    const addedAdmins = newAdmins.filter(
      (newAdm: any) =>
        newAdm.userId &&
        !prevAdmins.some(
          (prevAdm: any) => Number(prevAdm.userId) === Number(newAdm.userId),
        ),
    );

    if (!db.settings) db.settings = {};
    db.settings.panel_config = configValue;
    if (finalPayload.domainName !== undefined) db.settings.domainName = finalPayload.domainName;
    if (finalPayload.sslPublicKeyPath !== undefined) db.settings.sslPublicKeyPath = finalPayload.sslPublicKeyPath;
    if (finalPayload.sslPrivateKeyPath !== undefined) db.settings.sslPrivateKeyPath = finalPayload.sslPrivateKeyPath;

    const saveSuccess = writeSqliteDb(db);

    if (!saveSuccess) {
      return res.status(500).json({ 
        success: false, 
        error: "خطا در ذخیره دیتابیس. فایل ممکن است قفل باشد یا فضای دیسک پر شده باشد." 
      });
    }

    // Reset cached AI client so newly saved GEMINI_API_KEY settings will take effect immediately
    aiClient = null;

    // Restart Python Bot so updated button texts and configuration take effect immediately
    try {
      startPythonBot();
    } catch (botErr) {
      console.warn("Failed restarting python bot after settings update:", botErr);
    }

    // Notify newly appointed admins via Telegram Bot
    const botToken = payload.botToken || prevSettings.botToken;
    const botNickname =
      payload.botNickname || prevSettings.botNickname || "دالتون بات";
    if (botToken && addedAdmins.length > 0) {
      for (const adm of addedAdmins) {
        try {
          const roleText =
            adm.role === "super_admin"
              ? "سوپر ادمین (مدیر ارشد)"
              : "ادمین معمولی (مدیریت پشتیبانی)";
          const htmlMsg =
            `👑 <b>انتصاب شایسته شما به عنوان مدیریت سیستم</b>\n\n` +
            `کاربر گرامی <b>@${adm.username || "کاربر"}</b> (شناسه: <code>${adm.userId}</code>)؛\n` +
            `با سلام و احترام،\n\n` +
            `بدین‌وسیله به اطلاع می‌رساند دسترسی مدیریتی شما به عنوان <b>${roleText}</b> در ربات ${botNickname} با موفقیت فعال گردید.\n\n` +
            `🛡️ <b>برخی از مزایا و وظایف سطح دسترسی ادمین:</b>\n` +
            `🔹 <b>بررسی و تایید واریزی‌ها:</b> دسترسی به لیست فیش‌های ارسالی کاربران در بخش «تایید تراکنش‌ها» جهت شارژ خودکار کیف پول.\n` +
            `🔹 <b>مدیریت اعضا:</b> امکان ویرایش، افزایش و یا کاهش موجودی کاربران، مسدودسازی و رفع مسدودیت اعضا.\n` +
            `🔹 <b>پلان‌های ادمین:</b> استفاده رایگان از پلان‌ها بدون کسر موجودی جهت بررسی و کنترل کیفی سرورها.\n` +
            `🔹 <b>اعلان‌های هوشمند:</b> رصد و دریافت فوری اطلاعات فیش‌های ارسالی اعضا به محض بارگذاری در ربات.\n\n` +
            `<i>مفتخریم که در تیم توسعه و مدیریت ${botNickname} حضور دارید. با آرزوی موفقیت و همکاری مستمر.</i>\n\n` +
            `✨ <b>تیم پشتیبانی و فنی ${botNickname}</b>`;

          await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              chat_id: adm.userId,
              text: htmlMsg,
              parse_mode: "HTML",
            }),
          });
          console.log(
            `[Admin Welcomed] Successfully welcomed new admin ID: ${adm.userId}`,
          );
        } catch (err) {
          console.error(
            `[Admin Welcome Error] Failed to welcome admin ${adm.userId}:`,
            err,
          );
        }
      }
    }

    // Dynamic restart of the Python bot to reload newly added parameters/token
    startPythonBot();

    res.json({
      success: true,
      message: "Settings saved successfully to JSON store.",
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

function extractInboundListFromResponse(listJson: any): any[] | null {
  if (!listJson) return null;
  
  if (typeof listJson === "string") {
    try {
      listJson = JSON.parse(listJson);
    } catch (e) {
      return null;
    }
  }

  if (Array.isArray(listJson)) return listJson;

  if (typeof listJson === "object" && listJson !== null) {
    const keys = ["obj", "inbounds", "data", "result", "services", "groups", "list", "items", "body", "response", "value", "rows"];
    
    // Check direct keys
    for (const k of keys) {
      const val = listJson[k];
      if (Array.isArray(val)) return val;
      if (val && typeof val === "object") {
        for (const k2 of keys) {
          if (Array.isArray(val[k2])) return val[k2];
        }
      }
    }

    // Check deep object properties for any array of objects containing inbound properties
    for (const [, val] of Object.entries(listJson)) {
      if (Array.isArray(val) && val.length > 0 && typeof val[0] === "object" && val[0] !== null) {
        if ("id" in val[0] || "remark" in val[0] || "port" in val[0] || "protocol" in val[0] || "name" in val[0] || "title" in val[0] || "tag" in val[0]) {
          return val;
        }
      }
      if (val && typeof val === "object" && !Array.isArray(val) && val !== null) {
        for (const [, val2] of Object.entries(val)) {
          if (Array.isArray(val2) && val2.length > 0 && typeof val2[0] === "object" && val2[0] !== null) {
            if ("id" in val2[0] || "remark" in val2[0] || "port" in val2[0] || "protocol" in val2[0] || "name" in val2[0] || "title" in val2[0] || "tag" in val2[0]) {
              return val2;
            }
          }
        }
      }
    }

    // If an empty array key was present in standard keys, return that empty array
    for (const k of keys) {
      if (Array.isArray(listJson[k])) return listJson[k];
    }
  }

  return null;
}

function getInboundListCandidates(cleanedUrl: string): string[] {
  const baseCandidates = getCandidateBaseUrls(cleanedUrl);

  const endpoints = [
    "/panel/api/inbounds/list",
    "/panel/api/inbounds",
    "/panel/api/inbounds/",
    "/panel/api/inbound/list",
    "/panel/api/reseller/inbounds",
    "/panel/api/reseller/inbounds/list",
    "/panel/api/reseller/inbound/list",
    "/panel/api/reseller/getInbounds",
    "/xui/API/inbounds/list",
    "/xui/api/inbounds/list",
    "/xui/API/inbounds",
    "/xui/api/inbounds",
    "/xui/API/inbound/list",
    "/xui/api/inbound/list",
    "/xui/api/v1/inbounds/list",
    "/api/reseller/inbounds",
    "/api/reseller/inbounds/list",
    "/api/reseller/inbound/list",
    "/api/v1/inbounds/list",
    "/api/v1/inbound/list",
    "/panel/inbound/list",
    "/api/inbounds/list",
    "/api/inbounds",
    "/api/inbound/list",
    "/api/v2/services",
    "/api/services",
    "/api/groups",
    "/api/groups/simple",
    "/api/v1/groups",
    "/api/v2/inbounds",
    "/api/v2/inbounds/list"
  ];

  const results: string[] = [];
  for (const base of baseCandidates) {
    const cleanBase = base.replace(/\/+$/, "");
    for (const ep of endpoints) {
      const full = `${cleanBase}${ep}`;
      if (!results.includes(full)) {
        results.push(full);
      }
    }
  }
  return results;
}

// Cache to store detected API prefix per panel base URL
const apiPrefixCache = new Map<string, string>();

async function getApiPrefix(cleanedUrl: string, cookie: string = "", customHeaders: Record<string, string> = {}): Promise<string> {
  if (!cleanedUrl) return "/panel/api";
  const normalized = cleanedUrl.replace(/\/+$/, "");
  if (apiPrefixCache.has(normalized)) {
    return apiPrefixCache.get(normalized)!;
  }

  const candidates = ["/panel/api", "/xui/API", "/xui/api"];
  for (const prefix of candidates) {
    const url = `${normalized}${prefix}/inbounds/list`;
    try {
      const headers: Record<string, string> = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Accept: "application/json, text/plain, */*",
        ...customHeaders
      };
      if (cookie && !headers["Cookie"]) {
        headers["Cookie"] = cookie;
      }
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 4000);
      const res = await fetch(url, {
        method: "GET",
        headers,
        signal: controller.signal,
      }).catch(() => null);
      clearTimeout(timer);

      if (res && res.status !== 404) {
        const contentType = (res.headers.get("content-type") || "").toLowerCase();
        const text = await res.text().catch(() => "");
        const isJson = contentType.includes("application/json") || text.trim().startsWith("{") || text.trim().startsWith("[");
        const isHtml = contentType.includes("text/html") || text.trim().startsWith("<") || text.toLowerCase().includes("<!doctype");
        if (isJson && !isHtml) {
          console.log(`[API Path Auto-Detect] Found working API path prefix: '${prefix}' for URL: ${cleanedUrl}`);
          apiPrefixCache.set(normalized, prefix);
          return prefix;
        }
      }
    } catch (e) {
      // Ignore errors and try next
    }
  }

  return "/panel/api";
}

// Robust fetch helper with timeout and standardized browser headers to bypass WAF / strict server security rules
async function xuiFetch(url: string, options: any = {}, timeoutMs = 8000) {
  // Automatically adjust path prefix if we detect '/panel/api/' in the URL
  if (url.includes("/panel/api/")) {
    const idx = url.indexOf("/panel/api/");
    const baseUrl = url.substring(0, idx);
    const suffix = url.substring(idx + "/panel/api/".length);
    const cookie = options.headers?.Cookie || "";
    const prefix = await getApiPrefix(baseUrl, cookie, options.headers || {});
    if (prefix !== "/panel/api") {
      url = `${baseUrl}${prefix}/${suffix}`;
    }
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  const headers = {
    "User-Agent":
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    Accept: "application/json, text/plain, */*",
    "Accept-Language": "en-US,en;q=0.9,fa;q=0.8",
    ...options.headers,
  };

  try {
    const response = await fetch(url, {
      ...options,
      headers,
      signal: controller.signal,
    });
    clearTimeout(timer);
    return response;
  } catch (err) {
    clearTimeout(timer);
    throw err;
  }
}

function getActiveServers(settings: any) {
  let allServers: any[] = [];
  if (
    settings.servers &&
    Array.isArray(settings.servers)
  ) {
    allServers = allServers.concat(settings.servers.map((s: any) => ({
      ...s,
      subUrl: s.subUrl || s.sub_url || s.subLink || s.sub_link || s.subscriptionUrl || s.subscription_url || "",
      isColleague: s.isColleague === true || s.is_colleague === true || s.isReseller === true || s.is_reseller === true
    })));
  }
  if (
    settings.colleagueServers &&
    Array.isArray(settings.colleagueServers)
  ) {
    allServers = allServers.concat(settings.colleagueServers.map((s: any) => ({
      ...s,
      subUrl: s.subUrl || s.sub_url || s.subLink || s.sub_link || s.subscriptionUrl || s.subscription_url || "",
      isColleague: true
    })));
  }

  if (settings.panel_config) {
    try {
      const pc = typeof settings.panel_config === "string" ? JSON.parse(settings.panel_config) : settings.panel_config;
      if (pc && Array.isArray(pc.SERVERS)) {
        allServers = allServers.concat(pc.SERVERS.map((s: any) => ({
          ...s,
          subUrl: s.subUrl || s.sub_url || s.subLink || s.sub_link || s.subscriptionUrl || s.subscription_url || "",
          isColleague: s.isColleague === true || s.is_colleague === true || s.isReseller === true || s.is_reseller === true
        })));
      }
      if (pc && Array.isArray(pc.servers)) {
        allServers = allServers.concat(pc.servers.map((s: any) => ({
          ...s,
          subUrl: s.subUrl || s.sub_url || s.subLink || s.sub_link || s.subscriptionUrl || s.subscription_url || "",
          isColleague: s.isColleague === true || s.is_colleague === true || s.isReseller === true || s.is_reseller === true
        })));
      }
      if (pc && Array.isArray(pc.colleagueServers)) {
        allServers = allServers.concat(pc.colleagueServers.map((s: any) => ({
          ...s,
          subUrl: s.subUrl || s.sub_url || s.subLink || s.sub_link || s.subscriptionUrl || s.subscription_url || "",
          isColleague: true
        })));
      }
      if (pc && Array.isArray(pc.COLLEAGUE_SERVERS)) {
        allServers = allServers.concat(pc.COLLEAGUE_SERVERS.map((s: any) => ({
          ...s,
          subUrl: s.subUrl || s.sub_url || s.subLink || s.sub_link || s.subscriptionUrl || s.subscription_url || "",
          isColleague: true
        })));
      }
    } catch (e) {}
  }
  
  if (allServers.length > 0) {
    const seen = new Set();
    const unique = [];
    for (const s of allServers) {
      if (!s || typeof s !== "object") continue;
      const sid = s.id || s.panelUrl || s.baseUrl;
      if (sid && !seen.has(sid)) {
        seen.add(sid);
        if (s.status !== "inactive") {
          unique.push({
            ...s,
            subUrl: s.subUrl || s.sub_url || s.subLink || s.sub_link || s.subscriptionUrl || s.subscription_url || ""
          });
        }
      }
    }
    if (unique.length > 0) return unique;
  }

  // Fallback to legacy single server configuration if baseUrl is present
  if (
    settings.baseUrl &&
    (settings.panelUsername || settings.panelConnectionActive)
  ) {
    return [
      {
        id: "legacy_server",
        name: "پنل اصلی",
        panelUrl: settings.baseUrl,
        subUrl: settings.subUrl || settings.sub_url || "",
        panelUsername: settings.panelUsername || "admin",
        panelPassword: settings.panelPassword || "",
        activeInboundIds: settings.activeInboundIds || [],
        status: "active",
      },
    ];
  }

  // No fake servers - return empty list so no counterfeit servers are displayed
  return [];
}

function formatSubUrlWithToken(baseUrl: string, token: string): string {
  if (!baseUrl || !token) return baseUrl || "";
  let clean = baseUrl.trim().replace(/^['"\s]+|['"\s]+$/g, "");
  if (!clean.startsWith("http://") && !clean.startsWith("https://")) {
    if (/:(8443|2096|2083|2087|2053|443)($|\/|\?)/.test(clean) || /ssl|https/i.test(clean)) {
      clean = "https://" + clean;
    } else {
      clean = "http://" + clean;
    }
  }
  clean = clean.replace(/\/+$/, "");
  const cleanToken = token.trim().replace(/^\/+/, "");
  if (clean.endsWith("/sub")) {
    return `${clean}/${cleanToken}`;
  } else {
    return `${clean}/sub/${cleanToken}`;
  }
}

function formatShamsiDate(dateInput: any, includeTime = false): string {
  if (!dateInput) return "نامشخص";
  try {
    let d: Date;
    if (typeof dateInput === "number") {
      d = new Date(dateInput > 1e11 ? dateInput : dateInput * 1000);
    } else if (typeof dateInput === "string") {
      let str = dateInput.trim();
      if (/^\d{4}-\d{2}-\d{2}$/.test(str)) {
        str = str + "T12:00:00Z";
      }
      d = new Date(str);
    } else {
      d = dateInput;
    }
    if (isNaN(d.getTime())) return String(dateInput);
    const opts: Intl.DateTimeFormatOptions = {
      timeZone: "Asia/Tehran",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    };
    if (includeTime) {
      opts.hour = "2-digit";
      opts.minute = "2-digit";
      opts.second = "2-digit";
      opts.hour12 = false;
    }
    return new Intl.DateTimeFormat("fa-IR-u-ca-persian", opts).format(d);
  } catch (e) {
    return String(dateInput);
  }
}

function getServerRemark(serverId: any, settings: any, db?: any, subLink?: string): string {
  const activeSrvs = getActiveServers(settings);
  const targetId = (serverId !== undefined && serverId !== null) ? String(serverId).trim() : "";

  if (targetId) {
    // 1. Search in active servers (regular and colleague)
    const found = activeSrvs.find((s: any) =>
      String(s.id) === targetId ||
      String(s.name) === targetId ||
      String(s.remark) === targetId ||
      (s.panelUrl && String(s.panelUrl).includes(targetId))
    );
    if (found) return found.remark || found.name || "سرور اختصاصی";

    // 2. Search in db.servers or settings.servers / colleagueServers
    if (db && Array.isArray(db.servers)) {
      const inDb = db.servers.find((s: any) =>
        String(s.id) === targetId ||
        String(s.name) === targetId ||
        String(s.remark) === targetId
      );
      if (inDb) return inDb.remark || inDb.name || "سرور اختصاصی";
    }
    if (settings && Array.isArray(settings.servers)) {
      const inSet = settings.servers.find((s: any) =>
        String(s.id) === targetId ||
        String(s.name) === targetId ||
        String(s.remark) === targetId
      );
      if (inSet) return inSet.remark || inSet.name || "سرور اختصاصی";
    }
    if (settings && Array.isArray(settings.colleagueServers)) {
      const inCol = settings.colleagueServers.find((s: any) =>
        String(s.id) === targetId ||
        String(s.name) === targetId ||
        String(s.remark) === targetId
      );
      if (inCol) return inCol.remark || inCol.name || "سرور همکاران";
    }
  }

  // 3. If subLink is provided, match host/domain with server panelUrl or subDomain
  if (subLink && typeof subLink === "string") {
    const matchSrv = activeSrvs.find((s: any) => {
      if (s.subDomain && subLink.includes(s.subDomain)) return true;
      if (s.panelUrl) {
        try {
          const host = new URL(s.panelUrl).hostname;
          if (host && subLink.includes(host)) return true;
        } catch (e) {}
      }
      return false;
    });
    if (matchSrv) return matchSrv.remark || matchSrv.name || "سرور اختصاصی";
  }

  // 4. Fallback to first active server or settings remark
  if (activeSrvs.length > 0) {
    return activeSrvs[0].remark || activeSrvs[0].name || settings.panelRemark || settings.remark || "سرور اختصاصی";
  }
  return settings.panelRemark || settings.remark || "سرور اختصاصی دالتون";
}

function getUserDisplayInfo(userId: any, clientName?: string, db?: any): string {
  let usernameStr = "";
  let fullNameStr = "";
  let cleanId = userId ? String(userId).trim() : "";

  const dbData = db || readSqliteDb();

  // If cleanId is missing or "0", try to resolve user from subscription_keys using clientName
  if ((!cleanId || cleanId === "0") && clientName) {
    const key = (dbData.subscription_keys || []).find((k: any) =>
      String(k.clientName) === String(clientName) ||
      String(k.clientUuid) === String(clientName) ||
      String(k.id) === String(clientName)
    );
    if (key && key.userId) {
      cleanId = String(key.userId);
    }
  }

  if (cleanId) {
    try {
      const user = (dbData.users || []).find((u: any) =>
        String(u.userId) === cleanId ||
        String(u.id) === cleanId ||
        String(u.user_id) === cleanId ||
        String(u.tg_id) === cleanId
      );
      if (user) {
        if (user.username && String(user.username).trim() && user.username !== "N/A" && !String(user.username).startsWith("user_")) {
          usernameStr = `@${String(user.username).replace(/^@/, '')}`;
        }
        fullNameStr = user.fullName || user.firstName || "";
      }
    } catch (e) {}
  }

  const cleanClient = clientName && String(clientName).trim() ? String(clientName).trim() : "";
  let userPart = "";
  if (usernameStr && fullNameStr) {
    userPart = `${usernameStr} (${fullNameStr})`;
  } else if (usernameStr) {
    userPart = usernameStr;
  } else if (fullNameStr) {
    userPart = `<b>${fullNameStr}</b>`;
  } else {
    userPart = "بدون یوزرنیم";
  }

  const idStr = cleanId && cleanId !== "0" ? ` (شناسه: <code>${cleanId}</code>)` : "";
  let result = `👤 <b>کاربر:</b> ${userPart}${idStr}`;
  if (cleanClient) {
    result += `\n🏷 <b>نام کانفیگ:</b> <code>${cleanClient}</code>`;
  }
  return result;
}

function getServerDisplayForNotification(serverId: any, settings: any, db?: any, subLink?: string): string {
  const dbData = db || readSqliteDb();
  const activeServers = getActiveServers(settings);
  const srv = activeServers.find((s: any) => String(s.id) === String(serverId));
  const srvName = getServerRemark(serverId, settings, dbData, subLink);
  const srvFlag = srv?.flag || (srv?.isColleague ? "👥" : "🌐");
  return `${srvFlag} ${srvName}`;
}

function calculateCustomPlanPrice(trafficGb: number, durationDays: number, serverId: any, settings: any): { price: number; pricePerGb: number; pricePerDay: number } {
  let pricePerGb = 3000;
  let pricePerDay = 2000;

  try {
    const pc = typeof settings.panel_config === "string" ? JSON.parse(settings.panel_config) : (settings.panel_config || {});
    const boxes = pc.customPricingBoxes || settings.customPricingBoxes || [];
    if (Array.isArray(boxes)) {
      for (const box of boxes) {
        if (box && Array.isArray(box.serverIds) && box.serverIds.some((sid: any) => String(sid) === String(serverId))) {
          if (box.pricePerGb) pricePerGb = Number(box.pricePerGb);
          if (box.pricePerDay) pricePerDay = Number(box.pricePerDay);
          break;
        }
      }
    }
    if (pc.pricePerGb && pricePerGb === 3000) pricePerGb = Number(pc.pricePerGb);
    if (pc.pricePerDay && pricePerDay === 2000) pricePerDay = Number(pc.pricePerDay);
    if (settings.pricePerGb && pricePerGb === 3000) pricePerGb = Number(settings.pricePerGb);
    if (settings.pricePerDay && pricePerDay === 2000) pricePerDay = Number(settings.pricePerDay);
  } catch (e) {}

  const gbVal = Math.max(0, Number(trafficGb) || 0);
  const daysVal = Math.max(0, Number(durationDays) || 0);
  const total = Math.max(0, (gbVal * pricePerGb) + (daysVal * pricePerDay));
  return { price: total, pricePerGb, pricePerDay };
}

function buildCorrectSubLinkForClient(
  keyOrSubLink: any,
  serverId?: string,
  settings?: any,
  db?: any
): string {
  if (!settings && db) settings = getSystemSettings(db);
  if (!settings) {
    try {
      const d = readSqliteDb();
      settings = getSystemSettings(d);
    } catch {}
  }
  settings = settings || {};

  let subLink = typeof keyOrSubLink === "string" ? keyOrSubLink : (keyOrSubLink?.subLink || "");
  let sId = serverId || (typeof keyOrSubLink === "object" ? (keyOrSubLink?.serverId || keyOrSubLink?.server_id) : "");
  let clientUuid = typeof keyOrSubLink === "object" ? (keyOrSubLink?.clientUuid || keyOrSubLink?.uuid || keyOrSubLink?.clientName) : "";
  let subId = typeof keyOrSubLink === "object" ? (keyOrSubLink?.subId || keyOrSubLink?.xuiSubId || keyOrSubLink?.sub_id) : "";
  let serverName = typeof keyOrSubLink === "object" ? (keyOrSubLink?.serverName || keyOrSubLink?.planName) : "";

  // Extract subId token from existing subLink or fields
  let token = (subId || "").trim();
  if (!token && subLink) {
    const match = subLink.match(/\/sub\/([a-zA-Z0-9_\-\.\=\+]+)/i);
    if (match && match[1]) {
      token = match[1].trim();
    } else {
      const cleanSub = subLink.split("?")[0];
      const parts = cleanSub.split("/");
      const last = parts[parts.length - 1];
      if (last && !last.includes(":") && last.length >= 3) {
        token = last.trim();
      }
    }
  }
  if (!token) {
    token = (clientUuid || (typeof keyOrSubLink === "object" ? (keyOrSubLink?.clientEmail || keyOrSubLink?.clientName) : "") || "user").trim();
  }

  // Find server from active servers
  const rawServers = getActiveServers(settings);
  let server = sId ? rawServers.find((s: any) => String(s.id) === String(sId)) : null;
  if (!server && serverName) {
    server = rawServers.find((s: any) => 
      (s.name && (serverName.includes(s.name) || s.name.includes(serverName))) || 
      (s.remark && (serverName.includes(s.remark) || s.remark.includes(serverName)))
    );
  }
  if (!server && rawServers.length > 0) {
    server = rawServers.find((s: any) => s.status === "active") || rawServers[0];
  }

  // Server-specific or global subscription base URL
  let baseSub = (
    server?.subUrl ||
    server?.sub_url ||
    server?.subLink ||
    server?.subscriptionUrl ||
    server?.subscription_url ||
    settings.subUrl ||
    settings.sub_url ||
    ""
  ).trim();

  if (!baseSub && server?.panelUrl) {
    baseSub = normalizeXuiUrl(server.panelUrl);
  }

  if (baseSub) {
    return formatSubUrlWithToken(baseSub, token);
  }

  if (subLink && subLink.startsWith("http")) {
    return subLink;
  }

  return `https://vpn.daltoon.online/sub/${token}`;
}

function normalizeXuiUrl(url: string): string {
  if (!url) return "";
  let cleaned = `${url}`.trim().replace(/^['"\s]+|['"\s]+$/g, "");

  // If URL starts with http:// or https:// (or variant)
  if (/^https?:\/\//i.test(cleaned)) {
    const protoMatch = cleaned.match(/^(https?:\/\/)/i);
    const proto = protoMatch ? protoMatch[1].toLowerCase() : "http://";
    let rest = cleaned.substring(proto.length);
    cleaned = proto + rest;
  } else {
    // Remove leading whitespace and slashes
    cleaned = cleaned.replace(/^[\s\/]+/, "");
    
    // Check if protocol is missing. Detect if port 8443, 2096, 2083, 2087, 2053, 443 or contains ssl/https
    if (/:(8443|2096|2083|2087|2053|443)($|\/|\?)/.test(cleaned) || /ssl|https/i.test(cleaned)) {
      cleaned = "https://" + cleaned;
    } else {
      cleaned = "http://" + cleaned;
    }
  }

  // Remove duplicate slashes in the path portion after protocol
  cleaned = cleaned.replace(/(https?:\/\/)\/+/gi, "$1");
  cleaned = cleaned.replace(/([^:]\/)\/+/g, "$1");

  // Remove trailing slashes
  cleaned = cleaned.replace(/\/+$/, "");
  // Keep /portal/ intact for reseller logins, strip other markers
  const markers = ["/sub/", "/client/", "/share/"];
  for (const marker of markers) {
    if (cleaned.includes(marker)) {
      cleaned = cleaned.split(marker)[0];
    }
  }

  // Remove trailing /dashboard or /panel or /login if it ends with them
  cleaned = cleaned.replace(/\/(dashboard|panel|login)$/i, "");
  cleaned = cleaned.replace(/\/+$/, "");

  return cleaned;
}

function getCandidateBaseUrls(cleanedUrl: string): string[] {
  if (!cleanedUrl) return [];
  const normCleaned = cleanedUrl.replace(/\/+$/, "");
  let parsedUrl: URL;
  try {
    parsedUrl = new URL(normCleaned);
  } catch (e) {
    parsedUrl = new URL("http://" + normCleaned);
  }
  const origin = parsedUrl.origin;
  const pathname = parsedUrl.pathname !== "/" ? parsedUrl.pathname : "";
  const segments = pathname.split("/").filter(Boolean);

  const candidates: string[] = [];

  // 1. If /portal/ is present, portalReplaced MUST be candidate #1
  if (normCleaned.includes("/portal/")) {
    const portalReplaced = normCleaned.replace("/portal/", "/").replace(/\/+$/, "");
    if (portalReplaced && !candidates.includes(portalReplaced)) {
      candidates.push(portalReplaced);
    }
    const portalPrefix = normCleaned.split("/portal/")[0].replace(/\/+$/, "");
    if (portalPrefix && !candidates.includes(portalPrefix)) {
      candidates.push(portalPrefix);
    }
  }

  // 2. Exact cleanedUrl
  if (!candidates.includes(normCleaned)) {
    candidates.push(normCleaned);
  }

  // 3. Progressive parent path segments
  let curr = origin;
  if (!candidates.includes(curr)) {
    candidates.push(curr);
  }
  for (const seg of segments) {
    curr = `${curr}/${seg}`;
    if (!candidates.includes(curr)) {
      candidates.push(curr);
    }
  }

  // 4. Add dual scheme (http <-> https) candidates for domain/protocol resilience
  const dualCandidates: string[] = [];
  for (const c of candidates) {
    dualCandidates.push(c);
    if (c.startsWith("https://")) {
      dualCandidates.push(c.replace("https://", "http://"));
    } else if (c.startsWith("http://")) {
      dualCandidates.push(c.replace("http://", "https://"));
    }
  }

  return Array.from(new Set(dualCandidates));
}

const resolvedBaseCache = new Map<string, string>();

async function getResolvedBaseUrl(
  cleanedUrl: string,
  headers: Record<string, string> = {}
): Promise<string> {
  if (!cleanedUrl) return "";
  const normCleaned = cleanedUrl.replace(/\/+$/, "");
  if (resolvedBaseCache.has(normCleaned)) {
    return resolvedBaseCache.get(normCleaned)!;
  }

  const bases = getCandidateBaseUrls(normCleaned);
  const endpoints = [
    "/panel/api/inbounds/list",
    "/xui/API/inbounds/list",
    "/xui/api/inbounds/list",
    "/panel/inbound/list",
    "/panel/api/inbound/list",
    "/api/inbounds/list",
    "/api/inbounds",
    "/api/v1/inbounds/list"
  ];

  for (const base of bases) {
    for (const ep of endpoints) {
      const testUrl = `${base}${ep}`;
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 4000);
        const res = await fetch(testUrl, {
          method: "GET",
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            Accept: "application/json",
            ...headers
          },
          signal: controller.signal
        }).catch(() => null);
        clearTimeout(timer);

        if (res && res.ok) {
          const rj = await res.json().catch(() => null);
          if (rj && (rj.success || Array.isArray(rj.obj) || Array.isArray(rj.inbounds) || Array.isArray(rj.data))) {
            console.log(`[Base URL Resolver] Successfully resolved ${normCleaned} -> ${base} via ${testUrl}`);
            resolvedBaseCache.set(normCleaned, base);
            return base;
          }
        }
      } catch (e) {}
    }
  }

  resolvedBaseCache.set(normCleaned, normCleaned);
  return normCleaned;
}

// Highly robust helper to log into Reebeka/Pasarguard panels trying multiple candidates
async function loginReebekaPasarguard(baseUrl: string, username: string, password: string): Promise<string | null> {
  const cleanedUrl = normalizeXuiUrl(baseUrl);
  
  const candidates = [
    // 1. Standard admin token urlencoded
    { url: `${cleanedUrl}/api/admin/token`, asJson: false, body: () => {
        const p = new URLSearchParams();
        p.append("grant_type", "password");
        p.append("username", username);
        p.append("password", password);
        return p.toString();
      }
    },
    // 2. Standard admin token trailing slash urlencoded
    { url: `${cleanedUrl}/api/admin/token/`, asJson: false, body: () => {
        const p = new URLSearchParams();
        p.append("grant_type", "password");
        p.append("username", username);
        p.append("password", password);
        return p.toString();
      }
    },
    // 3. Alternative token urlencoded
    { url: `${cleanedUrl}/api/token`, asJson: false, body: () => {
        const p = new URLSearchParams();
        p.append("grant_type", "password");
        p.append("username", username);
        p.append("password", password);
        return p.toString();
      }
    },
    // 4. Alternative token trailing slash urlencoded
    { url: `${cleanedUrl}/api/token/`, asJson: false, body: () => {
        const p = new URLSearchParams();
        p.append("grant_type", "password");
        p.append("username", username);
        p.append("password", password);
        return p.toString();
      }
    },
    // 5. Admin token JSON
    { url: `${cleanedUrl}/api/admin/token`, asJson: true, body: () => JSON.stringify({ username, password }) },
    // 6. Admin token trailing slash JSON
    { url: `${cleanedUrl}/api/admin/token/`, asJson: true, body: () => JSON.stringify({ username, password }) },
    // 7. Alternative token JSON
    { url: `${cleanedUrl}/api/token`, asJson: true, body: () => JSON.stringify({ username, password }) },
    // 8. Alternative token trailing slash JSON
    { url: `${cleanedUrl}/api/token/`, asJson: true, body: () => JSON.stringify({ username, password }) },
  ];

  const allCandidates: typeof candidates = [];
  for (const c of candidates) {
    allCandidates.push(c);
    if (c.url.startsWith("https://")) {
      allCandidates.push({ ...c, url: c.url.replace("https://", "http://") });
    } else if (c.url.startsWith("http://")) {
      allCandidates.push({ ...c, url: c.url.replace("http://", "https://") });
    }
  }

  for (const cand of allCandidates) {
    try {
      console.log(`[Reebeka/Pasarguard Login] Trying candidate: ${cand.url} (JSON: ${cand.asJson})`);
      const headers: Record<string, string> = {
        "Accept": "application/json"
      };
      if (cand.asJson) {
        headers["Content-Type"] = "application/json";
      } else {
        headers["Content-Type"] = "application/x-www-form-urlencoded";
      }

      const res = await xuiFetch(
        cand.url,
        {
          method: "POST",
          headers,
          body: cand.body()
        },
        5000
      );

      if (res.ok) {
        const data = await res.json();
        const token = data?.access_token;
        if (token) {
          console.log(`[Reebeka/Pasarguard Login] Authenticated successfully with ${cand.url}`);
          return token;
        }
      }
    } catch (e: any) {
      console.log(`[Reebeka/Pasarguard Login] Candidate ${cand.url} failed: ${e.message}`);
    }
  }

  return null;
}

// Robust helper to authenticate with XUI panel supporting both classic panels and modern panels requiring GET + CSRF token
// Helper class to manage cookies
class CookieJar {
  private cookies = new Map<string, string>();

  public parseAndAdd(res: any) {
    try {
      if (!res) return;
      if (typeof res === "string") {
        const parts = res.split(/,(?=[^;]*=)/);
        for (const part of parts) {
          this.addSingle(part);
        }
      } else if (res && res.headers) {
        if (typeof res.headers.getSetCookie === "function") {
          const cookies = res.headers.getSetCookie();
          for (const cookie of cookies) {
            this.addSingle(cookie);
          }
        } else if (typeof res.headers.get === "function") {
          const cookieHeader = res.headers.get("set-cookie");
          if (cookieHeader) {
            const parts = cookieHeader.split(/,(?=[^;]*=)/);
            for (const part of parts) {
              this.addSingle(part);
            }
          }
        } else {
          // Plain object headers
          const rawSetCookie = res.headers["set-cookie"] || res.headers["Set-Cookie"];
          if (Array.isArray(rawSetCookie)) {
            for (const cookie of rawSetCookie) {
              this.addSingle(cookie);
            }
          } else if (typeof rawSetCookie === "string") {
            const parts = rawSetCookie.split(/,(?=[^;]*=)/);
            for (const part of parts) {
              this.addSingle(part);
            }
          }
        }
      }
    } catch (e) {
      console.error("[CookieJar] Error parsing cookies:", e);
    }
  }

  private addSingle(cookieStr: string) {
    const cookiePart = cookieStr.split(";")[0].trim();
    const eqIdx = cookiePart.indexOf("=");
    if (eqIdx > 0) {
      const name = cookiePart.substring(0, eqIdx).trim();
      const value = cookiePart.substring(eqIdx + 1).trim();
      if (name && value) {
        this.cookies.set(name, value);
      }
    }
  }

  public getCookieHeaderString(): string {
    return Array.from(this.cookies.entries())
      .map(([name, value]) => `${name}=${value}`)
      .join("; ");
  }

  public isEmpty(): boolean {
    return this.cookies.size === 0;
  }
}

interface XuiSession {
  cookie: string;
  csrfToken: string | null;
  timestamp: number;
}
const xuiSessionCache = new Map<string, XuiSession>();

function clearXuiPanelSession(cleanedUrl: string, username: string, password: string) {
  const cacheKey = `${cleanedUrl}||${username}||${password}`;
  xuiSessionCache.delete(cacheKey);
}

// Robust helper to authenticate with XUI panel supporting both classic panels and modern panels requiring GET + CSRF token
export async function loginXuiPanel(
  cleanedUrl: string,
  username: string,
  password: string,
  forceFresh = false,
): Promise<{
  success: boolean;
  cookie: string | null;
  csrfToken?: string | null;
  error?: string;
}> {
  const cacheKey = `${cleanedUrl}||${username}||${password}`;
  if (!forceFresh) {
    const cached = xuiSessionCache.get(cacheKey);
    if (cached && (Date.now() - cached.timestamp < 20 * 60 * 1000)) { // 20 minutes cache
      return {
        success: true,
        cookie: cached.cookie,
        csrfToken: cached.csrfToken,
      };
    }
  }

  try {
    let parsedUrl: URL;
    try {
      parsedUrl = new URL(cleanedUrl);
    } catch (e) {
      parsedUrl = new URL("http://" + cleanedUrl);
    }
    const origin = parsedUrl.origin;
    const pathname = parsedUrl.pathname !== "/" ? parsedUrl.pathname : "";

    const segments = pathname.split("/").filter(Boolean);
    const candidatePaths: string[] = [];
    let portalEntranceUrl: string | null = null;
    
    if (cleanedUrl.includes('/portal/')) {
        try {
            const urlObj = new URL(cleanedUrl);
            const portalMatch = urlObj.pathname.match(/(.*\/portal\/[^\/]+)/);
            if (portalMatch) {
                const portalPath = portalMatch[1];
                portalEntranceUrl = `${urlObj.origin}${portalPath}`;
                const base = portalPath.split('/portal/')[0];
                const resellerId = portalPath.split('/portal/')[1];
                const loginQueryUrl = `${urlObj.origin}${base}/login?portal=${resellerId}`;
                const resellerPath = `${urlObj.origin}${base}/${resellerId}`;
                
                // For resellers, we MUST visit the portal entrance first to get cookies
                // Then try the login URL with the portal query as the HIGH PRIORITY
                candidatePaths.push(`${resellerPath}/login`);
                candidatePaths.push(loginQueryUrl);
                candidatePaths.push(resellerPath);
                candidatePaths.push(portalEntranceUrl);
                candidatePaths.push(`${urlObj.origin}${portalPath}/login`);
            }
        } catch(e) {}
    }

    candidatePaths.push(cleanedUrl);
    candidatePaths.push(origin);
    
    let currentPath = "";
    for (const seg of segments) {
      currentPath += "/" + seg;
      candidatePaths.push(`${origin}${currentPath}`);
    }

    const rawLoginCandidates: string[] = [];
    for (const cp of candidatePaths) {
      rawLoginCandidates.push(cp);
      if (!cp.includes('?')) {
          rawLoginCandidates.push(`${cp}/login`);
          rawLoginCandidates.push(`${cp}/api/login`);
          rawLoginCandidates.push(`${cp}/panel/login`);
          rawLoginCandidates.push(`${cp}/xui/login`);
      }
    }
    rawLoginCandidates.push(`${origin}/login`);
    rawLoginCandidates.push(`${origin}/api/login`);
    rawLoginCandidates.push(`${origin}/panel/login`);
    rawLoginCandidates.push(`${origin}/xui/login`);

    // Add dual scheme (http <-> https) candidates for domain/protocol resilience
    const dualLoginCandidates: string[] = [];
    for (const cp of rawLoginCandidates) {
      dualLoginCandidates.push(cp);
      if (cp.startsWith("https://")) {
        dualLoginCandidates.push(cp.replace("https://", "http://"));
      } else if (cp.startsWith("http://")) {
        dualLoginCandidates.push(cp.replace("http://", "https://"));
      }
    }

    const loginCandidates = Array.from(new Set(dualLoginCandidates.filter(Boolean)));

    const jar = new CookieJar();
    let csrfToken = "";

    // Special Reseller Pre-initialization:
    // If we have a portalEntranceUrl, we MUST visit it once to get the session context
    if (portalEntranceUrl) {
      try {
        let initRes = await xuiFetch(portalEntranceUrl, { 
          method: "GET",
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
          }
        }, 10000).catch(() => null);
        if (initRes) {
          jar.parseAndAdd(initRes);
          const text = await initRes.text().catch(() => "");
          const match = text.match(/<meta\s+name="csrf-token"\s+content="([^"]+)"/i);
          if (match && match[1]) {
            csrfToken = match[1];
          }
        }
      } catch (e) {}
    }

    let loginRes: any = null;
    let bodyText = "";
    let bodyJson: any = {};
    let fallbackLoginRes: any = null;
    let fallbackBodyText = "";
    let fallbackBodyJson: any = {};

    for (const lUrl of loginCandidates) {
      try {
        // Skip posting to the portal entrance itself if we already initialized
        if (portalEntranceUrl && lUrl === portalEntranceUrl && !lUrl.includes("/login")) {
          continue;
        }

        console.log(`[Diagnostic] Trying XUI login at: ${lUrl}`);
        const cookieHeaderForGet = jar.getCookieHeaderString();
        let getRes = await xuiFetch(lUrl, { 
          method: "GET",
          headers: cookieHeaderForGet ? { "Cookie": cookieHeaderForGet } : {}
        }, 8000).catch(() => null);
        if (getRes) {
          jar.parseAndAdd(getRes);
          const text = await getRes.text().catch(() => "");
          const match = text.match(/<meta\s+name="csrf-token"\s+content="([^"]+)"/i);
          if (match && match[1]) {
            csrfToken = match[1];
          }
        }

        const cookieHeader = jar.getCookieHeaderString();

        // Try both application/json and application/x-www-form-urlencoded
        const payloadVariants = [
          {
            contentType: "application/json",
            body: JSON.stringify({ username, password })
          },
          {
            contentType: "application/x-www-form-urlencoded",
            body: (() => {
              const p = new URLSearchParams();
              p.append("username", username);
              p.append("password", password);
              return p.toString();
            })()
          }
        ];

        let successFound = false;
        for (const pv of payloadVariants) {
          // Special Referer logic for resellers:
          // If we are trying the login?portal=... URL, the Referer MUST be the portalEntranceUrl
          let referer = lUrl;
          if (portalEntranceUrl && lUrl.includes('?portal=')) {
            referer = portalEntranceUrl;
          }

          const headers: Record<string, string> = {
            "Content-Type": pv.contentType,
            "Referer": referer,
            "Origin": origin,
            "Accept": "application/json, text/plain, */*",
            "X-Requested-With": "XMLHttpRequest",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
          };
          const cookieHeader = jar.getCookieHeaderString();
          if (cookieHeader) headers["Cookie"] = cookieHeader;
          if (csrfToken) headers["X-Csrf-Token"] = csrfToken;

          const res = await xuiFetch(lUrl, {
            method: "POST",
            headers,
            body: pv.body,
          }, 10000);

          jar.parseAndAdd(res);
          const text = await res.text();
          let j: any = null;
          try {
            j = JSON.parse(text);
          } catch (e) {
            j = null;
          }

          const currentCookies = jar.getCookieHeaderString();
          const hasSecCookies = currentCookies && (
            currentCookies.includes("d-ui-sec") ||
            currentCookies.includes("session") ||
            currentCookies.includes("3x-ui") ||
            currentCookies.includes("x-ui") ||
            currentCookies.includes("token") ||
            currentCookies.includes("connect.sid") ||
            currentCookies.length > 0
          );
          const isHtml = text.trim().toLowerCase().startsWith("<!doctype") || text.trim().toLowerCase().startsWith("<html");
          const isSuccessJson = res.ok && !isHtml && j && (j.success === true || j.status === true || j.code === 200 || (typeof j.msg === "string" && j.msg.toLowerCase().includes("success")));
          const isOkWithCookies = res.ok && !isHtml && hasSecCookies && (!j || j.success !== false);

          if (isSuccessJson || isOkWithCookies) {
            loginRes = res;
            bodyText = text;
            bodyJson = j || { success: true };
            successFound = true;
            console.log(`[Diagnostic] XUI login successful at ${lUrl} using ${pv.contentType}`);
            break;
          } else if (res.ok && j && !j.success && j.msg) {
            if (!fallbackLoginRes) {
              fallbackLoginRes = res;
              fallbackBodyText = text;
              fallbackBodyJson = j;
            }
          }
        }

        if (successFound) break;
      } catch (err) {}
    }

    if (!loginRes && fallbackLoginRes) {
      loginRes = fallbackLoginRes;
      bodyText = fallbackBodyText;
      bodyJson = fallbackBodyJson;
    }

    console.log(
      `[Diagnostic] XUI response status: ${loginRes?.status}`,
    );

    const finalCookie = jar.getCookieHeaderString();
    const hasFinalCookies = finalCookie && (
      finalCookie.includes("d-ui-sec") ||
      finalCookie.includes("session") ||
      finalCookie.includes("3x-ui") ||
      finalCookie.includes("x-ui") ||
      finalCookie.includes("token") ||
      finalCookie.includes("connect.sid") ||
      finalCookie.length > 0
    );
    const isSuccessFinalJson = loginRes && loginRes.ok && bodyJson && (bodyJson.success === true || bodyJson.status === true || bodyJson.code === 200 || (typeof bodyJson.msg === "string" && bodyJson.msg.toLowerCase().includes("success")));
    const isOkWithFinalCookies = loginRes && loginRes.ok && hasFinalCookies && (!bodyJson || bodyJson.success !== false);

    if (isSuccessFinalJson || isOkWithFinalCookies) {
      if (loginRes) {
        jar.parseAndAdd(loginRes);
      }

      let postCsrfToken = loginRes.headers.get("X-Csrf-Token") || csrfToken;
      if (!postCsrfToken && bodyText) {
        const match = bodyText.match(/<meta\s+name="csrf-token"\s+content="([^"]+)"/i);
        if (match && match[1]) {
          postCsrfToken = match[1];
        }
      }

      const finalCsrf = postCsrfToken || null;

      xuiSessionCache.set(cacheKey, {
        cookie: jar.getCookieHeaderString(),
        csrfToken: finalCsrf,
        timestamp: Date.now(),
      });

      return {
        success: true,
        cookie: jar.getCookieHeaderString(),
        csrfToken: finalCsrf,
      };
    } else {
      const errMsg =
        bodyJson?.msg ||
        `کد خطا: ${loginRes?.status || 401}. نام کاربری یا رمز عبور پنل نادرست است.`;
      
      xuiSessionCache.delete(cacheKey);
      return { success: false, cookie: null, csrfToken: null, error: errMsg };
    }
  } catch (err: any) {
    console.error(`[Diagnostic] XUI login encountered error:`, err);
    xuiSessionCache.delete(cacheKey);
    return {
      success: false,
      cookie: null,
      csrfToken: null,
      error: err.message,
    };
  }
}

// Helper to generate precise direct VLESS links based on inbounds defined in Server Management
function generateVlessConfigsForClient(
  clientEmail: string,
  clientUuid?: string,
  serverId?: string,
  settings?: any,
  subLink?: string
): { vlessConfigs: string[]; vlessLinks: Array<{ name: string; url: string; port?: number; protocol?: string }> } {
  const result: { vlessConfigs: string[]; vlessLinks: Array<{ name: string; url: string; port?: number; protocol?: string }> } = {
    vlessConfigs: [],
    vlessLinks: []
  };

  const safeUuid = clientUuid || crypto.randomUUID();
  const safeName = (clientEmail || "user").trim();
  
  let db: any = null;
  try {
    db = readSqliteDb();
  } catch (e) {}

  if (!settings && db) {
    settings = getSystemSettings(db);
  }

  const activeServers = getActiveServers(settings || {});
  let server = serverId ? activeServers.find((s: any) => String(s.id) === String(serverId)) : null;
  if (!server && activeServers.length > 0) {
    server = activeServers.find((s: any) => s.status === "active") || activeServers[0];
  }

  // Determine domain/host from subLink, subUrl, panelUrl, or settings
  let host = "";
  if (subLink && typeof subLink === "string" && subLink.startsWith("http")) {
    try {
      const clean = subLink.replace(/^https?:\/\//i, "").split("/")[0];
      host = clean.split(":")[0];
    } catch (e) {}
  }

  if (!host && server?.subUrl && server.subUrl.trim() !== "") {
    try {
      const clean = server.subUrl.replace(/^https?:\/\//i, "").split("/")[0];
      host = clean.split(":")[0];
    } catch (e) {}
  } else if (!host && server?.panelUrl) {
    try {
      const clean = server.panelUrl.replace(/^https?:\/\//i, "").split("/")[0];
      host = clean.split(":")[0];
    } catch (e) {}
  } else if (!host && settings?.subUrl) {
    try {
      const clean = settings.subUrl.replace(/^https?:\/\//i, "").split("/")[0];
      host = clean.split(":")[0];
    } catch (e) {}
  } else if (!host && settings?.baseUrl) {
    try {
      const clean = settings.baseUrl.replace(/^https?:\/\//i, "").split("/")[0];
      host = clean.split(":")[0];
    } catch (e) {}
  }

  const serverName = server?.name || server?.remark || "Daltoon";

  // Gather inbounds defined on the server or in database
  const inboundsList: any[] = [];
  if (server && Array.isArray(server.inbounds) && server.inbounds.length > 0) {
    inboundsList.push(...server.inbounds);
  }
  if (db && Array.isArray(db.inbounds) && db.inbounds.length > 0) {
    for (const inb of db.inbounds) {
      if (!inboundsList.some((existing: any) => String(existing.id) === String(inb.id))) {
        inboundsList.push(inb);
      }
    }
  }
  if (settings && Array.isArray(settings.inbounds) && settings.inbounds.length > 0) {
    for (const inb of settings.inbounds) {
      if (!inboundsList.some((existing: any) => String(existing.id) === String(inb.id))) {
        inboundsList.push(inb);
      }
    }
  }

  // Filter active inbounds if activeInboundIds is present
  let activeInbounds = inboundsList;
  if (server && Array.isArray(server.activeInboundIds) && server.activeInboundIds.length > 0) {
    const activeSet = new Set(server.activeInboundIds.map((id: any) => Number(id)));
    const filtered = inboundsList.filter((ib: any) => activeSet.has(Number(ib.id)));
    if (filtered.length > 0) {
      activeInbounds = filtered;
    }
  }

  if (activeInbounds.length > 0 && host) {
    for (const ib of activeInbounds) {
      const port = Number(ib.port) || 443;
      const protocol = (ib.protocol || "vless").toLowerCase();
      const rawRemark = ib.remark || ib.name || ib.tag || `Inbound #${ib.id || port}`;
      const remark = `[${serverName}] ${rawRemark} - ${safeName}`;
      
      let streamSettings: any = {};
      if (typeof ib.streamSettings === "string") {
        try { streamSettings = JSON.parse(ib.streamSettings); } catch (e) {}
      } else if (typeof ib.streamSettings === "object" && ib.streamSettings !== null) {
        streamSettings = ib.streamSettings;
      }

      const network = streamSettings.network || ib.network || "tcp";
      const security = streamSettings.security || ib.security || (port === 443 ? "tls" : "none");
      
      const params = new URLSearchParams();
      params.set("type", network);
      params.set("security", security);

      if (security === "reality") {
        const realitySettings = streamSettings.realitySettings || {};
        const sni = (realitySettings.serverNames && realitySettings.serverNames[0]) || realitySettings.dest?.split(":")[0] || host;
        if (sni) params.set("sni", sni);
        if (realitySettings.publicKey || realitySettings.password) params.set("pbk", realitySettings.publicKey || realitySettings.password);
        if (realitySettings.shortIds && realitySettings.shortIds[0]) params.set("sid", realitySettings.shortIds[0]);
        if (realitySettings.spiderX) params.set("spx", realitySettings.spiderX);
        params.set("fp", realitySettings.fingerprint || realitySettings.settings?.fingerprint || "chrome");
      } else if (security === "tls") {
        const tlsSettings = streamSettings.tlsSettings || {};
        const sni = tlsSettings.serverName || host;
        if (sni) params.set("sni", sni);
        if (tlsSettings.alpn && tlsSettings.alpn.length > 0) params.set("alpn", Array.isArray(tlsSettings.alpn) ? tlsSettings.alpn.join(",") : tlsSettings.alpn);
        params.set("fp", tlsSettings.fingerprint || "chrome");
      }

      if (network === "ws") {
        const wsSettings = streamSettings.wsSettings || {};
        if (wsSettings.path) params.set("path", wsSettings.path);
        if (wsSettings.headers?.Host) params.set("host", wsSettings.headers.Host);
      } else if (network === "grpc") {
        const grpcSettings = streamSettings.grpcSettings || {};
        if (grpcSettings.serviceName) params.set("serviceName", grpcSettings.serviceName);
      } else if (network === "httpupgrade") {
        const httpupgradeSettings = streamSettings.httpupgradeSettings || {};
        if (httpupgradeSettings.path) params.set("path", httpupgradeSettings.path);
        if (httpupgradeSettings.host) params.set("host", httpupgradeSettings.host);
      }

      const link = `${protocol}://${safeUuid}@${host}:${port}?${params.toString()}#${encodeURIComponent(remark)}`;
      result.vlessConfigs.push(link);
      result.vlessLinks.push({
        name: remark,
        url: link,
        port: Number(port),
        protocol: protocol.toUpperCase()
      });
    }
  }

  return result;
}

// Cache for fast repeated lookups of subscription links (TTL: 60s)
const subLinkCache = new Map<string, { data: { vlessConfigs: string[]; vlessLinks: Array<{ name: string; url: string; port?: number; protocol?: string }> }; timestamp: number }>();

function parseProtocolLinks(rawLines: string[]): { vlessConfigs: string[]; vlessLinks: Array<{ name: string; url: string; port?: number; protocol?: string }> } {
  const uniqueUrls = Array.from(new Set(rawLines.map(l => l.trim()))).filter(l => 
    l.startsWith("vless://") ||
    l.startsWith("vmess://") ||
    l.startsWith("trojan://") ||
    l.startsWith("ss://") ||
    l.startsWith("hysteria2://") ||
    l.startsWith("hy2://") ||
    l.startsWith("tuic://") ||
    l.startsWith("wireguard://") ||
    l.includes("://")
  );

  const vlessLinks = uniqueUrls.map((url, idx) => {
    let name = `کانفیگ ${idx + 1}`;
    let protocol = "VLESS";
    let port: number | undefined = undefined;

    try {
      if (url.includes("#")) {
        const hash = url.split("#")[1];
        try {
          name = decodeURIComponent(hash);
        } catch {
          name = hash;
        }
      }
      if (url.includes("://")) {
        protocol = url.split("://")[0].toUpperCase();
      }
      const hostPortMatch = url.match(/@([^:?#/]+):(\d+)/);
      if (hostPortMatch && hostPortMatch[2]) {
        port = parseInt(hostPortMatch[2], 10);
      }
    } catch {}

    return { name, url, protocol, port };
  });

  return {
    vlessConfigs: uniqueUrls,
    vlessLinks
  };
}

// Helper to extract protocol links from any raw text, base64, JSON or HTML content
function extractAllProtocolLinks(content: string): string[] {
  if (!content || typeof content !== "string") return [];
  const results: string[] = [];
  const seen = new Set<string>();

  const addLink = (raw: string) => {
    if (!raw || typeof raw !== "string") return;
    const clean = raw.trim();
    if (!clean) return;
    if (/^(vless|vmess|trojan|ss|ssr|hy2|hysteria2|tuic|wireguard|socks5):\/\//i.test(clean)) {
      if (!seen.has(clean)) {
        seen.add(clean);
        results.push(clean);
      }
    }
  };

  let text = content.trim();
  if (text.charCodeAt(0) === 0xFEFF) {
    text = text.substring(1).trim();
  }

  // 1. Scan direct protocol regex matches
  const regex = /(?:vless|vmess|trojan|ss|ssr|hy2|hysteria2|tuic|wireguard|socks5):\/\/[^\s<>"'\r\n]+/gi;
  const matches = text.match(regex);
  if (matches) {
    matches.forEach(addLink);
  }

  // 2. Line by line parsing
  text.split(/\r?\n/).forEach(line => {
    const l = line.trim();
    if (l.includes("://")) addLink(l);
  });

  // 3. Base64 decoding (standard and URL-safe Base64)
  try {
    const cleanB64 = text.replace(/[\r\n\s\t]/g, "").replace(/-/g, "+").replace(/_/g, "/");
    let padded = cleanB64;
    while (padded.length % 4 !== 0) padded += "=";
    const decoded = Buffer.from(padded, "base64").toString("utf-8");
    if (decoded && decoded !== text) {
      const decMatches = decoded.match(regex);
      if (decMatches) {
        decMatches.forEach(addLink);
      }
      decoded.split(/\r?\n/).forEach(line => {
        const l = line.trim();
        if (l.includes("://")) addLink(l);
      });
      // Handle potential double base64
      try {
        const dCleanB64 = decoded.replace(/[\r\n\s\t]/g, "").replace(/-/g, "+").replace(/_/g, "/");
        let dPadded = dCleanB64;
        while (dPadded.length % 4 !== 0) dPadded += "=";
        const dDecoded = Buffer.from(dPadded, "base64").toString("utf-8");
        if (dDecoded && dDecoded.includes("://")) {
          const dMatches = dDecoded.match(regex);
          if (dMatches) dMatches.forEach(addLink);
          dDecoded.split(/\r?\n/).forEach(line => {
            if (line.trim().includes("://")) addLink(line.trim());
          });
        }
      } catch (_) {}
    }
  } catch (_) {}

  // 4. URL-decode
  try {
    const urlDecoded = decodeURIComponent(text);
    if (urlDecoded !== text) {
      const uMatches = urlDecoded.match(regex);
      if (uMatches) uMatches.forEach(addLink);
    }
  } catch (_) {}

  // 5. JSON parsing (Clash / Sing-box / X-UI obj)
  try {
    const json = JSON.parse(text);
    if (Array.isArray(json)) {
      json.forEach((item: any) => {
        if (typeof item === "string") addLink(item);
        else if (item?.url) addLink(item.url);
      });
    } else if (json && typeof json === "object") {
      const arr = json.obj || json.links || json.data || json.configs || json.proxies;
      if (Array.isArray(arr)) {
        arr.forEach((item: any) => {
          if (typeof item === "string") addLink(item);
          else if (item?.url) addLink(item.url);
        });
      }
    }
  } catch (_) {}

  return results;
}

// Extract real inbound protocol link for a client from an inbound configuration object
function buildProtocolLinkFromInbound(
  inbound: any,
  clientObj: any,
  defaultHost: string,
  serverName: string
): string | null {
  try {
    if (!inbound || !clientObj) return null;
    const port = Number(inbound.port) || 443;
    const protocol = (inbound.protocol || "vless").toLowerCase();
    const safeUuid = clientObj.id || clientObj.password || crypto.randomUUID();
    const safeEmail = clientObj.email || "user";
    const rawRemark = inbound.remark || inbound.name || inbound.tag || `Inbound #${inbound.id || port}`;
    const remark = `[${serverName}] ${rawRemark} - ${safeEmail}`;

    let streamSettings: any = {};
    if (typeof inbound.streamSettings === "string") {
      try { streamSettings = JSON.parse(inbound.streamSettings); } catch (_) {}
    } else if (typeof inbound.streamSettings === "object" && inbound.streamSettings !== null) {
      streamSettings = inbound.streamSettings;
    }

    const network = streamSettings.network || inbound.network || "tcp";
    const security = streamSettings.security || inbound.security || (port === 443 ? "tls" : "none");

    const host = defaultHost || "127.0.0.1";
    const params = new URLSearchParams();
    params.set("type", network);
    params.set("security", security);

    if (security === "reality") {
      const realitySettings = streamSettings.realitySettings || {};
      const sni = (realitySettings.serverNames && realitySettings.serverNames[0]) || realitySettings.dest?.split(":")[0] || host;
      if (sni) params.set("sni", sni);
      if (realitySettings.publicKey || realitySettings.password) params.set("pbk", realitySettings.publicKey || realitySettings.password);
      if (realitySettings.shortIds && realitySettings.shortIds[0]) params.set("sid", realitySettings.shortIds[0]);
      if (realitySettings.spiderX) params.set("spx", realitySettings.spiderX);
      params.set("fp", realitySettings.fingerprint || realitySettings.settings?.fingerprint || "chrome");
    } else if (security === "tls") {
      const tlsSettings = streamSettings.tlsSettings || {};
      const sni = tlsSettings.serverName || host;
      if (sni) params.set("sni", sni);
      if (tlsSettings.alpn && tlsSettings.alpn.length > 0) {
        params.set("alpn", Array.isArray(tlsSettings.alpn) ? tlsSettings.alpn.join(",") : tlsSettings.alpn);
      }
      params.set("fp", tlsSettings.fingerprint || "chrome");
    }

    if (network === "ws") {
      const wsSettings = streamSettings.wsSettings || {};
      if (wsSettings.path) params.set("path", wsSettings.path);
      if (wsSettings.headers?.Host) params.set("host", wsSettings.headers.Host);
    } else if (network === "grpc") {
      const grpcSettings = streamSettings.grpcSettings || {};
      if (grpcSettings.serviceName) params.set("serviceName", grpcSettings.serviceName);
    } else if (network === "httpupgrade") {
      const httpupgradeSettings = streamSettings.httpupgradeSettings || {};
      if (httpupgradeSettings.path) params.set("path", httpupgradeSettings.path);
      if (httpupgradeSettings.host) params.set("host", httpupgradeSettings.host);
    }

    if (protocol === "vmess") {
      const vmessJson = {
        v: "2",
        ps: remark,
        add: host,
        port: port,
        id: safeUuid,
        aid: clientObj.alterId || 0,
        net: network,
        type: "none",
        host: params.get("host") || "",
        path: params.get("path") || params.get("serviceName") || "",
        tls: security === "tls" ? "tls" : "none",
        sni: params.get("sni") || host,
        fp: params.get("fp") || "chrome"
      };
      return `vmess://${Buffer.from(JSON.stringify(vmessJson)).toString("base64")}`;
    }

    if (protocol === "trojan") {
      return `trojan://${safeUuid}@${host}:${port}?${params.toString()}#${encodeURIComponent(remark)}`;
    }

    return `vless://${safeUuid}@${host}:${port}?${params.toString()}#${encodeURIComponent(remark)}`;
  } catch (err) {
    return null;
  }
}

// Live real link fetcher from panel or subscription link
async function fetchRealClientLinks(
  clientEmail: string,
  clientUuid?: string,
  serverId?: string,
  subLink?: string,
  forceRefresh: boolean = false
): Promise<{ vlessConfigs: string[]; vlessLinks: Array<{ name: string; url: string; port?: number; protocol?: string }> }> {
  const cacheKey = (subLink || "") + "___" + (clientEmail || "") + "___" + (clientUuid || "");

  // Check cache first unless forceRefresh is set
  if (!forceRefresh && subLink && typeof subLink === "string" && subLink.startsWith("http")) {
    const cached = subLinkCache.get(subLink) || subLinkCache.get(cacheKey);
    if (cached && (Date.now() - cached.timestamp < 60000) && cached.data.vlessConfigs.length > 0) {
      return cached.data;
    }
  }

  const rawLinks: string[] = [];
  const db = readSqliteDb();
  const settings = getSystemSettings(db);
  const activeServers = getActiveServers(settings);

  // Extract subId if present
  let extractedSubId: string | null = null;
  if (subLink && typeof subLink === "string" && subLink.includes("/sub/")) {
    try {
      extractedSubId = subLink.split("/sub/")[1].split("?")[0].trim();
    } catch (_) {}
  }

  // 1. Build all candidate subscription URLs to fetch from
  const candidateUrls: string[] = [];
  if (subLink && typeof subLink === "string" && subLink.trim()) {
    const cleanSub = subLink.trim();
    if (cleanSub.startsWith("http://") || cleanSub.startsWith("https://")) {
      candidateUrls.push(cleanSub);
    } else {
      candidateUrls.push(`https://${cleanSub}`);
      candidateUrls.push(`http://${cleanSub}`);
    }
  }

  const subTokens = Array.from(new Set([extractedSubId, clientEmail, clientUuid])).filter(Boolean) as string[];

  for (const token of subTokens) {
    for (const srv of activeServers) {
      if (srv.subUrl) {
        candidateUrls.push(formatSubUrlWithToken(srv.subUrl, token));
      }
      if (srv.panelUrl) {
        candidateUrls.push(formatSubUrlWithToken(normalizeXuiUrl(srv.panelUrl), token));
      }
    }
    if (settings.subUrl) {
      candidateUrls.push(formatSubUrlWithToken(settings.subUrl, token));
    }
    if (settings.baseUrl) {
      candidateUrls.push(formatSubUrlWithToken(settings.baseUrl, token));
    }
  }

  const uniqueCandidateUrls = Array.from(new Set(candidateUrls)).filter(Boolean);

  // 2. Fetch directly from candidate subscription URLs with VPN User Agents
  const userAgents = [
    "v2rayNG/1.8.5",
    "v2rayN/6.23",
    "ClashMeta",
    "Sing-box",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
  ];

  for (const url of uniqueCandidateUrls) {
    if (rawLinks.length > 0) break;
    for (const ua of userAgents) {
      if (rawLinks.length > 0) break;
      try {
        const res = await xuiFetch(
          url,
          {
            method: "GET",
            headers: {
              "User-Agent": ua,
              "Accept": "*/*",
            },
            redirect: "follow",
          },
          8000
        ).catch(() => null);

        if (res && res.ok) {
          const bodyText = await res.text().catch(() => "");
          if (bodyText && bodyText.trim()) {
            const extracted = extractAllProtocolLinks(bodyText);
            if (extracted.length > 0) {
              rawLinks.push(...extracted);
              break;
            }
          }
        }
      } catch (_) {}
    }
  }

  // 3. If rawLinks still empty, connect directly to Panel APIs (Sanaei / 3x-ui / Marzban / Pasarguard)
  if (rawLinks.length === 0) {
    try {
      let targetServer = serverId ? activeServers.find((s: any) => String(s.id).trim() === String(serverId).trim()) : null;
      if (!targetServer && activeServers.length > 0) {
        targetServer = activeServers.find((s: any) => s.status === "active") || activeServers[0];
      }

      // Check all active servers if targetServer fails
      const serversToTry = targetServer ? [targetServer, ...activeServers.filter((s: any) => s.id !== targetServer.id)] : activeServers;

      for (const srv of serversToTry) {
        if (rawLinks.length > 0) break;
        const cleanedUrl = normalizeXuiUrl(srv.panelUrl);
        const panelType = (srv.panelType || "sanaei").toLowerCase();
        const serverHost = srv.subUrl ? srv.subUrl.replace(/^https?:\/\//i, "").split("/")[0].split(":")[0] : cleanedUrl.replace(/^https?:\/\//i, "").split("/")[0].split(":")[0];
        const srvName = srv.name || srv.remark || "Daltoon";

        if (["rebecca", "pasarguard", "marzban", "d-ui", "dui"].includes(panelType)) {
          const token = await loginReebekaPasarguard(cleanedUrl, srv.panelUsername, srv.panelPassword);
          if (token) {
            const headers = { "Authorization": `Bearer ${token}`, "Accept": "application/json" };
            const cleanName = (clientEmail || "").trim();
            if (cleanName) {
              const uRes = await xuiFetch(`${cleanedUrl}/api/user/${encodeURIComponent(cleanName)}`, { method: "GET", headers }, 6000).catch(() => null);
              if (uRes && uRes.ok) {
                const uData = await uRes.json().catch(() => ({}));
                const userObj = uData.data || uData;
                if (Array.isArray(userObj.links) && userObj.links.length > 0) {
                  userObj.links.forEach((l: string) => {
                    const ext = extractAllProtocolLinks(l);
                    rawLinks.push(...(ext.length > 0 ? ext : [l]));
                  });
                }
              }
            }
          }
        } else {
          // Sanaei / 3x-ui / X-UI
          const loginResult = await loginXuiPanel(cleanedUrl, srv.panelUsername, srv.panelPassword);
          if (loginResult.success && loginResult.cookie) {
            const headers: Record<string, string> = {
              Cookie: loginResult.cookie,
              Accept: "application/json",
            };
            if (loginResult.csrfToken) headers["X-Csrf-Token"] = loginResult.csrfToken!;

            const baseUrl = await getResolvedBaseUrl(cleanedUrl, headers);

            // A) Direct SubLinks endpoint by SubId
            if (extractedSubId) {
              try {
                const subLinksRes = await xuiFetch(`${baseUrl}/panel/api/clients/subLinks/${encodeURIComponent(extractedSubId)}`, { method: "GET", headers }, 5000).catch(() => null);
                if (subLinksRes && subLinksRes.ok) {
                  const sData = await subLinksRes.json().catch(() => ({}));
                  if (sData && sData.success && Array.isArray(sData.obj)) {
                    for (const item of sData.obj) {
                      if (typeof item === "string") {
                        const ext = extractAllProtocolLinks(item);
                        rawLinks.push(...(ext.length > 0 ? ext : [item]));
                      }
                    }
                  }
                }
              } catch (_) {}
            }

            // B) Direct Links endpoint by Email
            const cleanEmail = (clientEmail || "").trim();
            if (rawLinks.length === 0 && cleanEmail) {
              try {
                const emailLinksRes = await xuiFetch(`${baseUrl}/panel/api/clients/links/${encodeURIComponent(cleanEmail)}`, { method: "GET", headers }, 5000).catch(() => null);
                if (emailLinksRes && emailLinksRes.ok) {
                  const eData = await emailLinksRes.json().catch(() => ({}));
                  if (eData && eData.success && Array.isArray(eData.obj)) {
                    for (const item of eData.obj) {
                      if (typeof item === "string") {
                        const ext = extractAllProtocolLinks(item);
                        rawLinks.push(...(ext.length > 0 ? ext : [item]));
                      }
                    }
                  }
                }
              } catch (_) {}
            }

            // C) Inspect ALL Inbounds in Panel to extract live links for this client
            if (rawLinks.length === 0) {
              try {
                const inbRes = await xuiFetch(`${baseUrl}/panel/api/inbounds/list`, { method: "GET", headers }, 8000).catch(() => null);
                if (inbRes && inbRes.ok) {
                  const inbJson = await inbRes.json().catch(() => ({}));
                  if (inbJson && inbJson.success && Array.isArray(inbJson.obj)) {
                    const cleanEmailLower = (cleanEmail || "").toLowerCase();
                    const cleanUuidLower = (clientUuid || "").toLowerCase();
                    const subIdLower = (extractedSubId || "").toLowerCase();

                    for (const inbound of inbJson.obj) {
                      let clients: any[] = [];
                      try {
                        const inbSettings = typeof inbound.settings === "string" ? JSON.parse(inbound.settings) : inbound.settings;
                        clients = inbSettings?.clients || [];
                      } catch (_) {}

                      const matchedClient = clients.find((c: any) => {
                        if (!c) return false;
                        const cEmail = String(c.email || "").trim().toLowerCase();
                        const cId = String(c.id || "").trim().toLowerCase();
                        const cSubId = String(c.subId || "").trim().toLowerCase();

                        if (cleanUuidLower && cId === cleanUuidLower) return true;
                        if (cleanEmailLower && cEmail === cleanEmailLower) return true;
                        if (subIdLower && (cSubId === subIdLower || cEmail === subIdLower)) return true;
                        return false;
                      });

                      if (matchedClient) {
                        const configLink = buildProtocolLinkFromInbound(inbound, matchedClient, serverHost, srvName);
                        if (configLink) {
                          rawLinks.push(configLink);
                        }
                      }
                    }
                  }
                }
              } catch (_) {}
            }
          }
        }
      }
    } catch (_) {}
  }

  // 4. Format and parse into structured links
  let parsed = parseProtocolLinks(rawLinks);

  // 5. Fallback synthesis ONLY if totally empty and clientUuid is available
  if (parsed.vlessConfigs.length === 0 && clientUuid) {
    try {
      parsed = generateVlessConfigsForClient(clientEmail, clientUuid, serverId, settings, subLink);
    } catch (_) {}
  }

  // Cache result for fast 0ms future lookups
  if (parsed.vlessConfigs.length > 0) {
    if (subLink) subLinkCache.set(subLink, { data: parsed, timestamp: Date.now() });
    subLinkCache.set(cacheKey, { data: parsed, timestamp: Date.now() });
  }

  return parsed;
}

// Node.js implementation of Python bot's add_vpn_client_api helper
async function addVpnClientApi(
  clientEmail: string,
  trafficGb: number,
  durationDays: number,
  settings: any,
  clientUuid?: string,
  serverId?: string,
  bypassDuplicateCheck: boolean = false,
  allowFallback: boolean = false,
): Promise<{
  success: boolean;
  clientUuid?: string;
  subLink?: string;
  vlessConfigs?: string[];
  vlessLinks?: Array<{ name: string; url: string; port?: number; protocol?: string }>;
  error?: string;
}> {
  try {
    // Check locally first
    if (!bypassDuplicateCheck) {
      const db = readSqliteDb();
      const subs = db.subscription_keys || [];
      const _lMail = clientEmail.toLowerCase();
      for (let s of subs) {
        if (
          (s.clientName || "").toLowerCase() === _lMail ||
          (s.planId || "").toLowerCase() === _lMail
        ) {
          return {
            success: false,
            error:
              "این نام کاربری از قبل در لیست کاربران سرور موجود است. لطفاً نام دیگری انتخاب کنید.",
          };
        }
      }
    }

    const activeServers = getActiveServers(settings);
    if (activeServers.length === 0) {
      if (allowFallback) {
        const clientUuidVal = clientUuid || crypto.randomUUID();
        return {
          success: true,
          clientUuid: clientUuidVal,
          subLink: `https://vpn.daltoon.online/sub/${clientEmail || "user"}`
        };
      }
      return {
        success: false,
        error: "تنظیمات اتصال به پنل کامل نیست یا سرور فعالی وجود ندارد.",
      };
    }

    // Pick a random server for load balancing, or use specific serverId if provided
    let server =
      activeServers[Math.floor(Math.random() * activeServers.length)];
    if (serverId) {
      const matchingServer = activeServers.find((s: any) => String(s.id) === String(serverId));
      if (matchingServer) {
        server = matchingServer;
      }
    }

    const cleanedUrl = normalizeXuiUrl(server.panelUrl);
    const xuiSubId =
      Math.random().toString(36).substring(2, 10) +
      Math.random().toString(36).substring(2, 10);
    const clientUuidVal = clientUuid || crypto.randomUUID();
    
    let safeEmail = (clientEmail || "user")
      .replace(/ /g, "_")
      .replace(/\n/g, "")
      .replace(/\//g, "")
      .replace(/[^A-Za-z0-9_-]/g, "");
    if (!safeEmail) {
      safeEmail = "usr_" + Math.random().toString(36).substring(2, 7);
    }
    
    const panelType = (server.panelType || "sanaei").toLowerCase();
    if (["rebecca", "pasarguard", "marzban", "d-ui", "dui"].includes(panelType)) {
      try {
        const token = await loginReebekaPasarguard(cleanedUrl, server.panelUsername, server.panelPassword);
        if (token) {
          const totalBytes = trafficGb < 1.0
            ? Math.floor(trafficGb * 1000 * 1024 * 1024)
            : Math.floor(trafficGb * 1024 * 1024 * 1024);
          const expiryTimestampSec = Math.floor((Date.now() + durationDays * 24 * 60 * 60 * 1000) / 1000);

          const payload: any = {
            username: safeEmail,
            expire: expiryTimestampSec,
            data_limit: totalBytes,
            data_limit_reset_strategy: "no_reset",
            status: "active",
            proxies: {
              vless: { id: clientUuidVal, flow: "" },
              vmess: { id: clientUuidVal },
              trojan: { password: clientUuidVal },
              shadowsocks: { password: clientUuidVal }
            },
            inbounds: {}
          };

          if (panelType === "rebecca") {
            payload.service_ids = server.activeInboundIds || [1];
            payload.service_id = (server.activeInboundIds && server.activeInboundIds[0]) || 1;
          } else if (panelType === "pasarguard") {
            payload.group_ids = server.activeInboundIds || [1];
          } else {
            payload.service_ids = server.activeInboundIds || [1];
            payload.group_ids = server.activeInboundIds || [1];
          }

          console.log(`[${panelType} API] Creating user '${safeEmail}' on ${cleanedUrl}...`);
          const createRes = await xuiFetch(`${cleanedUrl}/api/user`, {
            method: "POST",
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
              Accept: "application/json"
            },
            body: JSON.stringify(payload)
          }, 10000);

          if (createRes.ok) {
            const rj = await createRes.json();
            const serverSub = server.subUrl && server.subUrl.trim() !== "" ? normalizeXuiUrl(server.subUrl) : cleanedUrl;
            let subLink = rj.subscription_url || rj.subLink || (rj.links && rj.links[0]) || "";
            if (!subLink) {
              subLink = `${serverSub}/sub/${safeEmail}`;
            } else if (subLink.startsWith("/")) {
              subLink = `${serverSub}${subLink}`;
            }
            console.log(`[${panelType} API] Successfully created client with subLink: ${subLink}`);
            const realLinks = await fetchRealClientLinks(safeEmail, clientUuidVal, server.id, subLink);
            return {
              success: true,
              clientUuid: clientUuidVal,
              subLink,
              vlessConfigs: realLinks.vlessConfigs,
              vlessLinks: realLinks.vlessLinks
            };
          } else {
            const errText = await createRes.text().catch(() => "");
            console.warn(`[${panelType} API Warning] Create user response status ${createRes.status}: ${errText}`);
          }
        }
      } catch (e: any) {
        console.error(`[${panelType} API Error] Exception during add client:`, e);
      }
    }

    const loginResult = await loginXuiPanel(
      cleanedUrl,
      server.panelUsername,
      server.panelPassword,
    );
    if (!loginResult.success || !loginResult.cookie) {
      if (allowFallback) {
        const serverHost = server?.panelUrl ? (server.panelUrl.replace(/^https?:\/\//i, '').split(':')[0].split('/')[0]) : "vpn.daltoon.online";
        const serverSub = server?.subUrl && server.subUrl.trim() !== "" ? normalizeXuiUrl(server.subUrl) : `https://${serverHost}`;
        return {
          success: true,
          clientUuid: clientUuidVal,
          subLink: `${serverSub}/sub/${xuiSubId}`
        };
      }
      return {
        success: false,
        error:
          "ورود به پنل با خطا مواجه شد: " +
          (loginResult.error || "خطای نامشخص"),
      };
    }

    const totalBytes = trafficGb < 1.0
      ? Math.floor(trafficGb * 1000 * 1024 * 1024)
      : Math.floor(trafficGb * 1024 * 1024 * 1024);
    const expiryTimeMs = Date.now() + durationDays * 24 * 60 * 60 * 1000;

    // Determine inbound_ids
    let inboundIds: number[] = [];
    if (
      Array.isArray(server.activeInboundIds) &&
      server.activeInboundIds.length > 0
    ) {
      inboundIds = server.activeInboundIds
        .map((id: any) => Number(id))
        .filter((id: number) => !isNaN(id));
    }

    // Fallback: fetch dynamically if none specified
    if (inboundIds.length === 0) {
      const listHeaders: Record<string, string> = { Cookie: loginResult.cookie! };
      if (loginResult.csrfToken) {
        listHeaders["X-Csrf-Token"] = loginResult.csrfToken!;
      }
      const listRes = await xuiFetch(
        `${cleanedUrl}/panel/api/inbounds/list`,
        {
          method: "GET",
          headers: listHeaders,
        },
        5000,
      );
      if (listRes.ok) {
        const listText = await listRes.text();
        try {
          const listJson = JSON.parse(listText);
          if (listJson && listJson.success && Array.isArray(listJson.obj)) {
            inboundIds = listJson.obj
              .map((item: any) => Number(item.id))
              .filter((id: number) => !isNaN(id));
            console.log(
              `[Sanaei API] Dynamically retrieved ${inboundIds.length} inbound IDs for user ${clientEmail}`,
            );
          }
        } catch (e) {}
      }
    }

    // Check if client already exists on panel
    try {
      const checkRes = await xuiFetch(
        `${cleanedUrl}/panel/api/inbounds/getClientTraffics/${clientEmail}`,
        {
          method: "GET",
          headers: {
            Cookie: loginResult.cookie,
            Accept: "application/json",
          },
        },
        5000,
      );
      if (checkRes.ok) {
        const checkJson = await checkRes.json();
        if (checkJson && checkJson.success && checkJson.obj) {
          return {
            success: false,
            error:
              "این نام کاربری از قبل در لیست کاربران سرور موجود است. لطفاً نام دیگری انتخاب کنید.",
          };
        }
      }
    } catch (err) {
      console.warn("[Sanaei API Sync] Could not check client existence:", err);
    }

    // Fetch all inbounds from panel to ensure valid IDs
    try {
      const listHeaders: Record<string, string> = {
        Cookie: loginResult.cookie,
        Accept: "application/json",
      };
      if (loginResult.csrfToken) {
        listHeaders["X-Csrf-Token"] = loginResult.csrfToken!;
      }
      const listRes = await xuiFetch(
        `${cleanedUrl}/panel/api/inbounds/list`,
        {
          method: "GET",
          headers: listHeaders,
        },
        5000,
      );
      if (listRes.ok) {
        const listJson = await listRes.json();
        if (listJson && listJson.success && Array.isArray(listJson.obj)) {
          const validIds = listJson.obj.map((inb: any) => inb.id);
          if (inboundIds.length > 0) {
            inboundIds = inboundIds.filter((id) => validIds.includes(id));
          }
          if (inboundIds.length === 0) {
            inboundIds = validIds;
          }
        }
      }
    } catch (err) {
      console.warn("[Sanaei API Sync] Could not fetch valid inbounds:", err);
    }

    if (inboundIds.length === 0) {
      inboundIds = [1];
    }

    // Advanced Candidates System for Sanaei/X-UI
    let candidateBases: string[] = [cleanedUrl];
    try {
      const parsedBase = new URL(cleanedUrl.startsWith("http") ? cleanedUrl : `http://${cleanedUrl}`);
      const origin = `${parsedBase.protocol}//${parsedBase.host}`;
      candidateBases.push(origin);
    } catch (e) {}

    if (cleanedUrl.includes('/portal/')) {
      const base = cleanedUrl.split('/portal/')[0];
      candidateBases.push(base);
    }
    if (server.subUrl && !candidateBases.includes(server.subUrl)) {
      candidateBases.push(server.subUrl);
      try {
        const subParsed = new URL(server.subUrl.startsWith("http") ? server.subUrl : `http://${server.subUrl}`);
        candidateBases.push(`${subParsed.protocol}//${subParsed.host}`);
      } catch(e) {}
    }
    
    // De-duplicate bases
    const uniqueBases = Array.from(new Set(candidateBases.filter(b => b))).map(b => b.replace(/\/$/, ""));
    
    const headers: Record<string, string> = {
      "Cookie": loginResult.cookie || "",
      "Content-Type": "application/json",
      "Accept": "application/json"
    };
    if (loginResult.csrfToken) {
      headers["X-Csrf-Token"] = loginResult.csrfToken!;
    }

    const payload = {
      client: {
        id: clientUuidVal,
        email: clientEmail,
        totalGB: totalBytes,
        expiryTime: expiryTimeMs,
        enable: true,
        subId: xuiSubId,
        limitIp: 0
      }
    };

    const unifiedEndpoints = [
      "/panel/api/clients/add",
      "/panel/api/client/add",
      "/panel/api/inbound/client/add",
      "/panel/api/inbounds/addClient",
      "/api/inbound/client/add",
      "/api/client/add",
      "/client/add",
      "/panel/api/reseller/client/add",
      "/api/reseller/client/add",
      "/xui/API/inbounds/addClient",
      "/xui/api/inbounds/addClient"
    ];
    
    const classicEndpoints = [
      "/panel/api/inbounds/addClient",
      "/panel/api/inbound/addClient",
      "/panel/api/client/add",
      "/panel/api/reseller/client/add",
      "/api/reseller/client/add",
      "/api/inbound/addClient",
      "/xui/API/inbounds/addClient",
      "/xui/api/inbounds/addClient"
    ];
    
    let unifiedSuccess = false;
    let extractedLink = null;
    let fallbackSuccess = false;
    let lastError = "";
    const subBase = server.subUrl && server.subUrl.trim() !== "" ? normalizeXuiUrl(server.subUrl) : cleanedUrl;
    
    for (const cb of uniqueBases) {
      if (unifiedSuccess) break;
      for (const ep of unifiedEndpoints) {
        const unifiedUrl = `${cb}${ep}`;
        try {
          const uRes = await xuiFetch(unifiedUrl, {
            method: "POST",
            headers: headers,
            body: JSON.stringify({
              client: payload.client,
              inboundIds: inboundIds,
              inboundId: inboundIds[0] || 1
            })
          }, 5000).catch(() => null);
          
          if (uRes && uRes.ok) {
            const rj = await uRes.json().catch(() => ({}));
            if (rj.success) {
              console.log(`[Unified API] Successfully added user via ${unifiedUrl}`);
              unifiedSuccess = true;
              
              const obj = rj.obj;
              if (typeof obj === 'string' && obj.startsWith('http')) extractedLink = obj;
              else if (obj && obj.link) extractedLink = obj.link;
              else if (rj.link) extractedLink = rj.link;
              else if (rj.subLink) extractedLink = rj.subLink;
              
              break;
            }
          }
        } catch(e) {}
      }
    }
    
    if (unifiedSuccess) {
      const finalSub = extractedLink || `${subBase}/sub/${xuiSubId}`;
      const realLinks = await fetchRealClientLinks(clientEmail, clientUuidVal, serverId, finalSub);
      return {
        success: true,
        clientUuid: clientUuidVal,
        subLink: finalSub,
        vlessConfigs: realLinks.vlessConfigs,
        vlessLinks: realLinks.vlessLinks
      };
    }
    
    // Classic Loop Fallback
    for (const inbId of inboundIds) {
      let inbAdded = false;
      for (const cb of uniqueBases) {
        if (inbAdded) break;
        for (const ep of classicEndpoints) {
          const classicUrl = `${cb}${ep}`;
          try {
            const cRes = await xuiFetch(classicUrl, {
              method: "POST",
              headers: headers,
              body: JSON.stringify({
                id: inbId,
                settings: JSON.stringify({ clients: [payload.client] })
              })
            }, 3000).catch(() => null);
            
            if (cRes && cRes.ok) {
              const rj = await cRes.json().catch(() => ({}));
              if (rj.success) {
                console.log(`[Classic API] Added user to inbound ${inbId} via ${classicUrl}`);
                inbAdded = true;
                fallbackSuccess = true;
                break;
              }
            }
          } catch(e) {}
        }
      }
    }
    
    if (fallbackSuccess) {
      const finalSub = extractedLink || `${subBase}/sub/${xuiSubId}`;
      const realLinks = await fetchRealClientLinks(clientEmail, clientUuidVal, serverId, finalSub);
      return {
        success: true,
        clientUuid: clientUuidVal,
        subLink: finalSub,
        vlessConfigs: realLinks.vlessConfigs,
        vlessLinks: realLinks.vlessLinks
      };
    }
    
    if (allowFallback) {
      const finalSub = extractedLink || `${subBase}/sub/${xuiSubId}` || `https://vpn.daltoon.online/sub/${safeEmail}`;
      const realLinks = await fetchRealClientLinks(clientEmail, clientUuidVal, serverId, finalSub);
      return {
        success: true,
        clientUuid: clientUuidVal,
        subLink: finalSub,
        vlessConfigs: realLinks.vlessConfigs,
        vlessLinks: realLinks.vlessLinks
      };
    }

    return { success: false, error: lastError || "خطا در ثبت کاربر روی سرور." };
  } catch (err: any) {
    console.error(`[Sanaei API Error] Exception during add client:`, err);
    if (allowFallback) {
      const finalSub = `https://vpn.daltoon.online/sub/${clientEmail || "user"}`;
      const safeUid = clientUuid || crypto.randomUUID();
      const realLinks = await fetchRealClientLinks(clientEmail, safeUid, serverId, finalSub);
      return {
        success: true,
        clientUuid: safeUid,
        subLink: finalSub,
        vlessConfigs: realLinks.vlessConfigs,
        vlessLinks: realLinks.vlessLinks
      };
    }
    return { success: false, error: err.message || String(err) };
  }
}

// 2.3 Delete a VPN client from XUI Panel globally

async function extendVpnClientApi(
  clientEmail: string,
  addGb: number,
  addDays: number,
  clientUuid?: string,
  serverId?: string,
  subLink?: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const db = readSqliteDb();
    const settings = getSystemSettings(db);
    const activeServers = getActiveServers(settings);

    // Collect candidate servers: specified server first, then all active servers
    const targetServers: any[] = [];
    if (serverId) {
      const srv = activeServers.find((s: any) => String(s.id) === String(serverId));
      if (srv) targetServers.push(srv);
    }
    for (const s of activeServers) {
      if (!targetServers.some((ts: any) => String(ts.id) === String(s.id)) && s.status !== "inactive") {
        targetServers.push(s);
      }
    }

    if (targetServers.length === 0) {
      return { success: false, error: "هیچ سرور فعالی یافت نشد" };
    }

    // Candidate tokens for matching
    const candidateUuids = new Set<string>();
    const candidateEmails = new Set<string>();
    const candidateSubs = new Set<string>();

    if (clientUuid && String(clientUuid).trim()) {
      candidateUuids.add(String(clientUuid).trim().toLowerCase());
    }
    if (clientEmail && String(clientEmail).trim()) {
      const e = String(clientEmail).trim().toLowerCase();
      candidateEmails.add(e);
      candidateEmails.add(e.replace(/[\s/]+/g, "_"));
      candidateEmails.add(e.replace(/[^A-Za-z0-9_-]/g, ""));
      const uuMatches = e.match(/[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}/g);
      if (uuMatches) {
        uuMatches.forEach((m) => candidateUuids.add(m.toLowerCase()));
      }
    }
    if (subLink && String(subLink).trim()) {
      const s = String(subLink).trim().toLowerCase();
      candidateSubs.add(s);
      const uuMatches = s.match(/[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}/g);
      if (uuMatches) {
        uuMatches.forEach((m) => candidateUuids.add(m.toLowerCase()));
      }
      const subMatches = s.match(/\/sub\/([a-zA-Z0-9_-]+)/g);
      if (subMatches) {
        subMatches.forEach((tok) => {
          const cleanTok = tok.replace("/sub/", "");
          candidateSubs.add(cleanTok);
          candidateEmails.add(cleanTok);
        });
      }
    }

    for (const server of targetServers) {
      const cleanedUrl = normalizeXuiUrl(server.panelUrl);
      if (!cleanedUrl) continue;

      const panelType = (server.panelType || "sanaei").toLowerCase();

      // Rebecca / Pasarguard / Marzban Panels
      if (["rebecca", "pasarguard", "marzban"].includes(panelType)) {
        try {
          const token = await loginReebekaPasarguard(cleanedUrl, server.panelUsername, server.panelPassword);
          if (!token) continue;

          const possibleUsernames = [...candidateEmails, ...candidateUuids, ...candidateSubs];
          let userFound = false;

          for (const username of possibleUsernames) {
            if (!username || username.length < 2) continue;

            const userRes = await xuiFetch(`${cleanedUrl}/api/user/${username}`, {
              method: "GET",
              headers: { "Authorization": `Bearer ${token}`, "Accept": "application/json" }
            }, 10000).catch(() => null);

            if (userRes && userRes.ok) {
              const uData = await userRes.json().catch(() => ({}));
              const userObj = uData?.data || uData;
              const currentTotal = Number(userObj?.data_limit || 0);
              const currentExpiry = Number(userObj?.expire || 0);

              const addBytes = Math.floor(addGb * 1024 * 1024 * 1024);
              const addSec = Math.floor(addDays * 24 * 60 * 60);
              const newTotal = currentTotal + addBytes;
              const nowSec = Math.floor(Date.now() / 1000);
              const newExpiry = (currentExpiry <= 0 || currentExpiry < nowSec) ? (nowSec + addSec) : (currentExpiry + addSec);

              const payload = {
                data_limit: newTotal,
                expire: newExpiry,
                status: "active"
              };

              for (const method of ["PUT", "PATCH", "POST"]) {
                const updRes = await xuiFetch(`${cleanedUrl}/api/user/${username}`, {
                  method,
                  headers: {
                    "Authorization": `Bearer ${token}`,
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                  },
                  body: JSON.stringify(payload)
                }, 10000).catch(() => null);

                if (updRes && updRes.ok) {
                  console.log(`[${panelType} Extend API] Extended user '${username}' via ${method}`);
                  userFound = true;
                  break;
                }
              }
            }
            if (userFound) return { success: true };
          }
        } catch (e: any) {
          console.error(`[${panelType} Extend Error]`, e);
        }
        continue;
      }

      // Sanaei / 3x-ui / Alireza / XUI Panels
      const loginResult = await loginXuiPanel(cleanedUrl, server.panelUsername, server.panelPassword);
      if (!loginResult.success || !loginResult.cookie) {
        continue;
      }

      const headers: Record<string, string> = {
        Cookie: loginResult.cookie,
        Accept: "application/json",
      };
      if (loginResult.csrfToken) headers["X-Csrf-Token"] = loginResult.csrfToken!;

      const baseUrl = await getResolvedBaseUrl(cleanedUrl, headers);

      let inboundsList: any[] = [];
      const listUrls = [
        `${baseUrl}/panel/api/inbounds/list`,
        `${baseUrl}/panel/api/inbounds/`,
        `${baseUrl}/api/inbounds/list`,
      ];

      for (const lUrl of listUrls) {
        try {
          const listRes = await xuiFetch(lUrl, { method: "GET", headers }, 10000);
          if (listRes.ok) {
            const resJson = await listRes.json().catch(() => ({}));
            if (resJson && resJson.success && Array.isArray(resJson.obj)) {
              inboundsList = resJson.obj;
              break;
            } else if (Array.isArray(resJson.data)) {
              inboundsList = resJson.data;
              break;
            } else if (Array.isArray(resJson)) {
              inboundsList = resJson;
              break;
            }
          }
        } catch (e) {}
      }

      let clientData: any = null;
      let inboundId: any = null;
      let inboundObj: any = null;

      if (inboundsList.length > 0) {
        const allClients: Array<{ c: any; inbId: any; inb: any }> = [];
        for (const inbound of inboundsList) {
          if (!inbound || typeof inbound !== "object") continue;
          let clients: any[] = [];
          try {
            const parsed = typeof inbound.settings === "string" ? JSON.parse(inbound.settings || "{}") : (inbound.settings || {});
            if (Array.isArray(parsed.clients)) {
              clients = parsed.clients;
            }
          } catch (e) {}

          for (const c of clients) {
            if (c && typeof c === "object") {
              allClients.push({ c, inbId: inbound.id, inb: inbound });
            }
          }
        }

        // Pass 1: UUID match
        for (const item of allClients) {
          const cId = String(item.c.id || "").trim().toLowerCase();
          if (cId && (candidateUuids.has(cId) || Array.from(candidateUuids).some((cand) => cId.includes(cand)))) {
            clientData = item.c;
            inboundId = item.inbId;
            inboundObj = item.inb;
            break;
          }
        }

        // Pass 2: Email / Username match
        if (!clientData) {
          for (const item of allClients) {
            const cEmail = String(item.c.email || "").trim().toLowerCase();
            if (cEmail && (candidateEmails.has(cEmail) || Array.from(candidateEmails).some((cand) => cand.length >= 2 && cEmail.includes(cand)))) {
              clientData = item.c;
              inboundId = item.inbId;
              inboundObj = item.inb;
              break;
            }
          }
        }

        // Pass 3: SubId match
        if (!clientData) {
          for (const item of allClients) {
            const cSub = String(item.c.subId || "").trim().toLowerCase();
            const cEmail = String(item.c.email || "").trim().toLowerCase();
            const cId = String(item.c.id || "").trim().toLowerCase();
            if ((cSub && Array.from(candidateSubs).some((s) => s.length >= 3 && cSub.includes(s))) ||
                (cEmail && Array.from(candidateSubs).some((s) => s.length >= 3 && cEmail.includes(s))) ||
                (cId && Array.from(candidateSubs).some((s) => s.length >= 3 && cId.includes(s)))) {
              clientData = item.c;
              inboundId = item.inbId;
              inboundObj = item.inb;
              break;
            }
          }
        }
      }

      if (!clientData) {
        continue;
      }

      const currentTotal = Number(clientData.totalGB) || Number(clientData.total) || 0;
      const rawExpiry = Number(clientData.expiryTime) || 0;
      const currentExpiryMs = (rawExpiry > 0 && rawExpiry < 10000000000) ? rawExpiry * 1000 : rawExpiry;

      const addBytes = Math.floor(addGb * 1024 * 1024 * 1024);
      const addMs = Math.floor(addDays * 24 * 60 * 60 * 1000);

      const newTotal = currentTotal + addBytes;
      const nowMs = Date.now();
      const newExpiryMs = (currentExpiryMs <= 0 || currentExpiryMs < nowMs) ? (nowMs + addMs) : (currentExpiryMs + addMs);

      const mergedC = { ...clientData };
      mergedC.total = newTotal;
      mergedC.totalGB = newTotal;
      mergedC.expiryTime = newExpiryMs;
      mergedC.enable = true;

      const uid = mergedC.id || mergedC.email;
      const safeEmail = mergedC.email || String(uid);
      const inbIdStr = String(inboundId || "1");
      const inbIdInt = Number(inboundId) || 1;

      const payloadIntStr = JSON.stringify({ clients: [mergedC] });
      const formBodyInt = `id=${inbIdInt}&settings=${encodeURIComponent(payloadIntStr)}`;
      const formBodyStr = `id=${inbIdStr}&settings=${encodeURIComponent(payloadIntStr)}`;

      const testConfigs = [
        // 1. Standard /panel/api/inbounds/updateClient/{uid}
        { url: `${baseUrl}/panel/api/inbounds/updateClient/${uid}`, isForm: true, body: formBodyInt },
        { url: `${baseUrl}/panel/api/inbounds/updateClient/${uid}`, isForm: true, body: formBodyStr },
        { url: `${baseUrl}/panel/api/inbounds/updateClient/${uid}`, isForm: false, body: JSON.stringify({ id: inbIdInt, settings: payloadIntStr }) },
        // 2. Inbound ID in URL
        { url: `${baseUrl}/panel/api/inbounds/${inbIdStr}/updateClient/${uid}`, isForm: true, body: formBodyInt },
        { url: `${baseUrl}/panel/api/inbounds/${inbIdStr}/updateClient/${uid}`, isForm: false, body: JSON.stringify({ id: inbIdInt, settings: payloadIntStr }) },
        // 3. Email in URL
        { url: `${baseUrl}/panel/api/inbounds/updateClient/${safeEmail}`, isForm: true, body: formBodyInt },
        { url: `${baseUrl}/panel/api/inbounds/updateClient/${safeEmail}`, isForm: false, body: JSON.stringify({ id: inbIdInt, settings: payloadIntStr }) },
        // 4. Unified API
        { url: `${baseUrl}/panel/api/clients/update/${uid}`, isForm: false, body: JSON.stringify(mergedC) },
        { url: `${baseUrl}/panel/api/clients/update/${safeEmail}`, isForm: false, body: JSON.stringify(mergedC) },
        // 5. Fallback endpoint
        { url: `${baseUrl}/panel/api/inbounds/updateClient`, isForm: true, body: formBodyInt },
        { url: `${baseUrl}/panel/api/inbounds/updateClient`, isForm: false, body: JSON.stringify({ id: inbIdInt, settings: payloadIntStr }) },
      ];

      for (const tc of testConfigs) {
        try {
          const reqHeaders = {
            ...headers,
            "Content-Type": tc.isForm ? "application/x-www-form-urlencoded; charset=UTF-8" : "application/json"
          };
          const updRes = await xuiFetch(tc.url, {
            method: "POST",
            headers: reqHeaders,
            body: tc.body
          }, 10000);

          if (updRes.ok) {
            const updJson = await updRes.json().catch(() => ({}));
            if (updJson && (updJson.success || updJson.obj || String(updJson.msg || "").toLowerCase() === "success")) {
              console.log(`[XUI Extend API] Extended client '${safeEmail || uid}' on server '${server.name || server.id}' via ${tc.url}`);
              return { success: true };
            }
          }
        } catch (e) {}
      }

      // Fallback: Full Inbound Update
      if (inboundObj && inboundObj.settings) {
        try {
          const inbSettings = typeof inboundObj.settings === "string" ? JSON.parse(inboundObj.settings) : inboundObj.settings;
          if (Array.isArray(inbSettings.clients)) {
            let foundInInb = false;
            for (let i = 0; i < inbSettings.clients.length; i++) {
              const cl = inbSettings.clients[i];
              if (cl && (cl.id === uid || cl.email === safeEmail)) {
                inbSettings.clients[i] = mergedC;
                foundInInb = true;
                break;
              }
            }
            if (foundInInb) {
              const inbPayload = {
                ...inboundObj,
                settings: JSON.stringify(inbSettings)
              };
              const inbUpdRes = await xuiFetch(`${baseUrl}/panel/api/inbounds/update/${inbIdStr}`, {
                method: "POST",
                headers: { ...headers, "Content-Type": "application/json" },
                body: JSON.stringify(inbPayload)
              }, 10000);
              if (inbUpdRes.ok) {
                console.log(`[XUI Extend API] Extended client '${safeEmail || uid}' via full inbound update`);
                return { success: true };
              }
            }
          }
        } catch (e) {}
      }

      return { success: true };
    }

    return { success: false, error: "کانفیگ مورد نظر روی هیچ یک از سرورها پیدا نشد." };
  } catch (e: any) {
    return { success: false, error: e.message || String(e) };
  }
}

async function deleteVpnClientApi(clientEmail: string, clientUuid?: string, serverId?: string) {
  try {
    const db = readSqliteDb();
    const settings = getSystemSettings(db);
    const activeServers = getActiveServers(settings);

    // If serverId is given, prioritize it, then fallback to other active servers
    let targetServers = serverId
      ? activeServers.filter((s: any) => String(s.id).trim() === String(serverId).trim())
      : activeServers;

    if (targetServers.length === 0) {
      targetServers = activeServers;
    }

    if (targetServers.length === 0)
      return { success: false, error: "No active VPN servers configured" };

    let deletedAtLeastOnce = false;
    let detectedUsedGb = 0;

    const cleanEmail = (clientEmail || "").trim();
    const cleanUuid = (clientUuid || "").trim();
    const safeEmail = cleanEmail.replace(/ /g, "_").replace(/\n/g, "").replace(/\//g, "").replace(/[^A-Za-z0-9_-]/g, "");

    for (const server of targetServers) {
      try {
        const cleanedUrl = normalizeXuiUrl(server.panelUrl);
        const panelType = (server.panelType || "sanaei").toLowerCase();

        // 1. Marzban / Rebecca / Pasarguard / D-UI
        if (["rebecca", "pasarguard", "marzban", "d-ui", "dui"].includes(panelType)) {
          try {
            const token = await loginReebekaPasarguard(cleanedUrl, server.panelUsername, server.panelPassword);
            if (token) {
              const headers = { "Authorization": `Bearer ${token}`, "Accept": "application/json" };
              if (safeEmail) {
                const delRes = await xuiFetch(`${cleanedUrl}/api/user/${safeEmail}`, { method: "DELETE", headers }, 8000).catch(() => null);
                if (delRes && delRes.ok) deletedAtLeastOnce = true;
              }
              if (cleanUuid && cleanUuid !== safeEmail) {
                const delResUuid = await xuiFetch(`${cleanedUrl}/api/user/${cleanUuid}`, { method: "DELETE", headers }, 8000).catch(() => null);
                if (delResUuid && delResUuid.ok) deletedAtLeastOnce = true;
              }
              if (deletedAtLeastOnce) continue;
            }
          } catch(e) {}
        }

        // 2. X-UI / 3X-UI / Sanaei / Alireza / FranzKafkaYu
        const loginResult = await loginXuiPanel(
          cleanedUrl,
          server.panelUsername,
          server.panelPassword,
        );
        if (!loginResult.success || !loginResult.cookie) continue;

        const headers: Record<string, string> = {
          Cookie: loginResult.cookie,
          Accept: "application/json",
        };
        if (loginResult.csrfToken) {
          headers["X-Csrf-Token"] = loginResult.csrfToken!;
        }

        const baseUrl = await getResolvedBaseUrl(cleanedUrl, headers);

        // Try global client delete endpoint by email
        if (safeEmail) {
          try {
            const delUrl = `${baseUrl}/panel/api/clients/del/${encodeURIComponent(safeEmail)}`;
            const res = await xuiFetch(delUrl, { method: "POST", headers }, 5000);
            if (res && res.ok) {
              const data = await res.json().catch(() => ({}));
              if (data && data.success) {
                deletedAtLeastOnce = true;
              }
            }
          } catch (e) {}
        }

        // Try global client delete endpoint by UUID
        if (cleanUuid) {
          try {
            const delUuidUrl = `${baseUrl}/panel/api/inbounds/delClient/${encodeURIComponent(cleanUuid)}`;
            const res = await xuiFetch(delUuidUrl, { method: "POST", headers }, 5000);
            if (res && res.ok) {
              const data = await res.json().catch(() => ({}));
              if (data && data.success) {
                deletedAtLeastOnce = true;
              }
            }
          } catch (e) {}
        }

        // Search across all inbounds for client and delete
        try {
          const listUrl = `${baseUrl}/panel/api/inbounds/list`;
          const listRes = await xuiFetch(listUrl, { method: "GET", headers }, 6000);
          if (listRes && listRes.ok) {
            const data = await listRes.json().catch(() => ({}));
            if (data && data.success && Array.isArray(data.obj)) {
              for (const inbound of data.obj) {
                let clients = [];
                try {
                  const inSettings = JSON.parse(inbound.settings || "{}");
                  clients = inSettings.clients || [];
                } catch (e) {}

                const targetEmailLower = (cleanEmail || "").toLowerCase();
                const targetUuidLower = (cleanUuid || "").toLowerCase();
                const targetSafeLower = (safeEmail || "").toLowerCase();

                const clientMatch = clients.find((c: any) => {
                  if (!c) return false;
                  const cEmail = String(c.email || "").trim().toLowerCase();
                  const cId = String(c.id || "").trim().toLowerCase();
                  const cSubId = String(c.subId || "").trim().toLowerCase();

                  if (targetUuidLower && cId === targetUuidLower) return true;
                  if (targetEmailLower && (cEmail === targetEmailLower || cSubId === targetEmailLower)) return true;
                  if (targetSafeLower && cEmail === targetSafeLower) return true;
                  if (targetEmailLower && cEmail && (cEmail.includes(targetEmailLower) || targetEmailLower.includes(cEmail))) return true;
                  return false;
                });

                if (clientMatch) {
                  const uBytes = (Number(clientMatch.up) || 0) + (Number(clientMatch.down) || 0);
                  if (uBytes > 0) {
                    const gb = uBytes / (1024 * 1024 * 1024);
                    if (gb > detectedUsedGb) detectedUsedGb = gb;
                  }

                  const clientTargetId = clientMatch.id || cleanUuid || clientMatch.email || safeEmail;
                  if (clientTargetId) {
                    // Try inbound-specific delClient
                    const inboundDelUrl = `${baseUrl}/panel/api/inbounds/${inbound.id}/delClient/${encodeURIComponent(clientTargetId)}`;
                    const fRes = await xuiFetch(inboundDelUrl, { method: "POST", headers }, 5000);
                    if (fRes && fRes.ok) {
                      const fData = await fRes.json().catch(() => ({}));
                      if (fData && fData.success) {
                        deletedAtLeastOnce = true;
                      }
                    }

                    // Also try alternate URL patterns
                    const altDelUrl = `${baseUrl}/panel/api/inbounds/delClient/${encodeURIComponent(clientTargetId)}`;
                    await xuiFetch(altDelUrl, { method: "POST", headers }, 4000).then(async (r) => {
                      if (r && r.ok) {
                        const d = await r.json().catch(() => ({}));
                        if (d && d.success) deletedAtLeastOnce = true;
                      }
                    }).catch(() => null);

                    const legacyDelUrl = `${baseUrl}/panel/inbound/delClient/${encodeURIComponent(clientTargetId)}`;
                    await xuiFetch(legacyDelUrl, { method: "POST", headers }, 4000).then(async (r) => {
                      if (r && r.ok) {
                        const d = await r.json().catch(() => ({}));
                        if (d && d.success) deletedAtLeastOnce = true;
                      }
                    }).catch(() => null);
                  }
                }
              }
            }
          }
        } catch (e) {}
      } catch (e) {
        // Continue trying remaining servers
      }
    }

    return {
      success: deletedAtLeastOnce,
      usedGb: detectedUsedGb,
      error: deletedAtLeastOnce ? undefined : "Panel deletion completed or client was not found on active panel",
    };
  } catch (e) {
    return { success: false, error: "Exception during deletion" };
  }
}

// 2.4 Toggle (Enable/Disable) a VPN client on XUI Panel / Marzban / D-UI
async function toggleVpnClientApi(
  clientEmail: string,
  enabled: boolean,
  clientUuid?: string,
  serverId?: string,
  subLink?: string
) {
  try {
    const db = readSqliteDb();
    const settings = getSystemSettings(db);
    const activeServers = getActiveServers(settings);
    if (activeServers.length === 0)
      return { success: false, error: "XUI disconnected" };

    // Build exhaustive set of candidate keys
    const candidateEmails = new Set<string>();
    const candidateUuids = new Set<string>();
    const candidateSubs = new Set<string>();

    const addCand = (val?: string) => {
      if (!val) return;
      const s = String(val).trim();
      if (!s) return;
      const sLower = s.toLowerCase();

      // Check if it's a UUID
      if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s)) {
        candidateUuids.add(sLower);
      } else {
        candidateEmails.add(sLower);
        const safe = s.replace(/ /g, "_").replace(/\n/g, "").replace(/\//g, "").replace(/[^A-Za-z0-9_-]/g, "").toLowerCase();
        if (safe) candidateEmails.add(safe);
      }
    };

    addCand(clientEmail);
    addCand(clientUuid);

    // Extract candidates from subLink
    if (subLink) {
      const subStr = String(subLink);
      const uuidMatch = subStr.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
      if (uuidMatch) candidateUuids.add(uuidMatch[0].toLowerCase());

      const subMatch = subStr.match(/\/sub\/([^/?#]+)/i);
      if (subMatch && subMatch[1]) candidateSubs.add(subMatch[1].trim().toLowerCase());

      const vlessMatch = subStr.match(/vless:\/\/([^@]+)@/i);
      if (vlessMatch && vlessMatch[1]) candidateUuids.add(vlessMatch[1].trim().toLowerCase());
    }

    // Prioritize target server if serverId is provided
    let targetServers = activeServers;
    if (serverId) {
      const matched = activeServers.filter((s: any) => String(s.id).trim() === String(serverId).trim());
      const others = activeServers.filter((s: any) => String(s.id).trim() !== String(serverId).trim());
      targetServers = [...matched, ...others];
    }

    let toggledAtLeastOnce = false;

    for (const server of targetServers) {
      try {
        const cleanedUrl = normalizeXuiUrl(server.panelUrl);
        const panelType = (server.panelType || "sanaei").toLowerCase();

        // 1. Marzban / Rebecca / Pasarguard / D-UI
        if (["rebecca", "pasarguard", "marzban", "d-ui", "dui"].includes(panelType)) {
          try {
            const token = await loginReebekaPasarguard(cleanedUrl, server.panelUsername, server.panelPassword);
            if (token) {
              const statusStr = enabled ? "active" : "disabled";
              const headers = {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json",
                Accept: "application/json"
              };

              const allUsernames = new Set<string>([...candidateEmails, ...candidateUuids]);
              for (const u of allUsernames) {
                const safeU = encodeURIComponent(u);

                // Attempt 1: PUT /api/user/{username}
                const res1 = await xuiFetch(`${cleanedUrl}/api/user/${safeU}`, {
                  method: "PUT",
                  headers,
                  body: JSON.stringify({ status: statusStr, is_active: enabled })
                }, 5000).catch(() => null);
                if (res1 && res1.ok) {
                  toggledAtLeastOnce = true;
                  break;
                }

                // Attempt 2: PATCH /api/user/{username}
                const res2 = await xuiFetch(`${cleanedUrl}/api/user/${safeU}`, {
                  method: "PATCH",
                  headers,
                  body: JSON.stringify({ status: statusStr, is_active: enabled })
                }, 5000).catch(() => null);
                if (res2 && res2.ok) {
                  toggledAtLeastOnce = true;
                  break;
                }

                // Attempt 3: PUT /api/user/{username}/disabled
                const res3 = await xuiFetch(`${cleanedUrl}/api/user/${safeU}/disabled`, {
                  method: "PUT",
                  headers,
                  body: JSON.stringify({ status: statusStr })
                }, 5000).catch(() => null);
                if (res3 && res3.ok) {
                  toggledAtLeastOnce = true;
                  break;
                }

                // Attempt 4: PUT /api/user/{username}/status
                const res4 = await xuiFetch(`${cleanedUrl}/api/user/${safeU}/status`, {
                  method: "PUT",
                  headers,
                  body: JSON.stringify({ status: statusStr })
                }, 5000).catch(() => null);
                if (res4 && res4.ok) {
                  toggledAtLeastOnce = true;
                  break;
                }
              }

              if (toggledAtLeastOnce) continue;
            }
          } catch (e) {}
        }

        // 2. X-UI / 3X-UI / Sanaei / Alireza / FranzKafkaYu
        const loginResult = await loginXuiPanel(
          cleanedUrl,
          server.panelUsername,
          server.panelPassword,
        );
        if (!loginResult.success || !loginResult.cookie) continue;

        const headers: Record<string, string> = {
          Cookie: loginResult.cookie,
          "Content-Type": "application/json",
          Accept: "application/json",
        };
        const formHeaders: Record<string, string> = {
          Cookie: loginResult.cookie,
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          Accept: "application/json",
        };
        if (loginResult.csrfToken) {
          headers["X-Csrf-Token"] = loginResult.csrfToken!;
          formHeaders["X-Csrf-Token"] = loginResult.csrfToken;
        }

        const baseUrl = await getResolvedBaseUrl(cleanedUrl, headers);

        // Fetch all inbounds
        const listUrl = `${baseUrl}/panel/api/inbounds/list`;
        const listRes = await xuiFetch(listUrl, { method: "GET", headers }, 8000).catch(() => null);
        if (!listRes || !listRes.ok) continue;

        const listJson = await listRes.json().catch(() => ({}));
        const inboundsList = Array.isArray(listJson.obj) ? listJson.obj : [];

        // Flatten all clients
        const allClients: Array<{ c: any; inbId: any; inb: any }> = [];
        for (const inb of inboundsList) {
          try {
            let settingsObj = inb.settings;
            if (typeof settingsObj === "string") settingsObj = JSON.parse(settingsObj);
            const clients = settingsObj?.clients || [];
            for (const c of clients) {
              allClients.push({ c, inbId: inb.id, inb });
            }
          } catch (e) {}
        }

        let clientData: any = null;
        let inboundId: any = null;
        let inboundObj: any = null;

        // Pass 1: Match by UUID
        for (const item of allClients) {
          const cId = String(item.c.id || "").trim().toLowerCase();
          if (cId && (candidateUuids.has(cId) || Array.from(candidateUuids).some((cand) => cId.includes(cand)))) {
            clientData = item.c;
            inboundId = item.inbId;
            inboundObj = item.inb;
            break;
          }
        }

        // Pass 2: Match by Email / Username
        if (!clientData) {
          for (const item of allClients) {
            const cEmail = String(item.c.email || "").trim().toLowerCase();
            if (cEmail && (candidateEmails.has(cEmail) || Array.from(candidateEmails).some((cand) => cand.length >= 2 && cEmail.includes(cand)))) {
              clientData = item.c;
              inboundId = item.inbId;
              inboundObj = item.inb;
              break;
            }
          }
        }

        // Pass 3: Match by SubId
        if (!clientData) {
          for (const item of allClients) {
            const cSub = String(item.c.subId || "").trim().toLowerCase();
            const cEmail = String(item.c.email || "").trim().toLowerCase();
            const cId = String(item.c.id || "").trim().toLowerCase();
            if ((cSub && Array.from(candidateSubs).some((s) => s.length >= 3 && cSub.includes(s))) ||
                (cEmail && Array.from(candidateSubs).some((s) => s.length >= 3 && cEmail.includes(s))) ||
                (cId && Array.from(candidateSubs).some((s) => s.length >= 3 && cId.includes(s)))) {
              clientData = item.c;
              inboundId = item.inbId;
              inboundObj = item.inb;
              break;
            }
          }
        }

        if (!clientData) continue;

        // Create updated client object
        const mergedC = { ...clientData };
        mergedC.enable = enabled;
        if (mergedC.status !== undefined) {
          mergedC.status = enabled ? "active" : "disabled";
        }

        const uid = mergedC.id || mergedC.email;
        const safeEmail = mergedC.email || String(uid);
        const inbIdStr = String(inboundId || "1");
        const inbIdInt = Number(inboundId) || 1;

        const payloadIntStr = JSON.stringify({ clients: [mergedC] });
        const formBodyInt = `id=${inbIdInt}&settings=${encodeURIComponent(payloadIntStr)}`;
        const formBodyStr = `id=${inbIdStr}&settings=${encodeURIComponent(payloadIntStr)}`;

        const testEndpoints = [
          // 1. /panel/api/inbounds/updateClient/{uid}
          { url: `${baseUrl}/panel/api/inbounds/updateClient/${uid}`, isForm: true, body: formBodyInt },
          { url: `${baseUrl}/panel/api/inbounds/updateClient/${uid}`, isForm: true, body: formBodyStr },
          { url: `${baseUrl}/panel/api/inbounds/updateClient/${uid}`, isForm: false, body: JSON.stringify({ id: inbIdInt, settings: payloadIntStr }) },
          // 2. /panel/api/inbounds/{inbId}/updateClient/{uid}
          { url: `${baseUrl}/panel/api/inbounds/${inbIdStr}/updateClient/${uid}`, isForm: true, body: formBodyInt },
          { url: `${baseUrl}/panel/api/inbounds/${inbIdStr}/updateClient/${uid}`, isForm: false, body: JSON.stringify({ id: inbIdInt, settings: payloadIntStr }) },
          // 3. /panel/api/inbounds/updateClient/{safeEmail}
          { url: `${baseUrl}/panel/api/inbounds/updateClient/${encodeURIComponent(safeEmail)}`, isForm: true, body: formBodyInt },
          { url: `${baseUrl}/panel/api/inbounds/updateClient/${encodeURIComponent(safeEmail)}`, isForm: false, body: JSON.stringify({ id: inbIdInt, settings: payloadIntStr }) },
          // 4. Unified /panel/api/clients/update/{uid}
          { url: `${baseUrl}/panel/api/clients/update/${uid}`, isForm: false, body: JSON.stringify(mergedC) },
          { url: `${baseUrl}/panel/api/clients/update/${encodeURIComponent(safeEmail)}`, isForm: false, body: JSON.stringify(mergedC) },
          { url: `${baseUrl}/panel/api/clients/update/${encodeURIComponent(safeEmail)}`, isForm: true, body: formBodyInt },
          // 5. Fallback endpoint
          { url: `${baseUrl}/panel/api/inbounds/updateClient`, isForm: true, body: formBodyInt },
          { url: `${baseUrl}/panel/api/inbounds/updateClient`, isForm: false, body: JSON.stringify({ id: inbIdInt, settings: payloadIntStr }) },
        ];

        let updatedClientOk = false;
        for (const ep of testEndpoints) {
          try {
            const reqHeaders = {
              ...headers,
              "Content-Type": ep.isForm ? "application/x-www-form-urlencoded; charset=UTF-8" : "application/json"
            };
            const updRes = await xuiFetch(ep.url, {
              method: "POST",
              headers: reqHeaders,
              body: ep.body
            }, 8000);

            if (updRes.ok) {
              const updJson = await updRes.json().catch(() => ({}));
              if (updJson && (updJson.success || updJson.obj || String(updJson.msg || "").toLowerCase() === "success")) {
                console.log(`[XUI Toggle API] Set client enable=${enabled} for '${safeEmail || uid}' on server '${server.name || server.id}' via ${ep.url}`);
                toggledAtLeastOnce = true;
                updatedClientOk = true;
                break;
              }
            }
          } catch (e) {}
        }

        // Fallback: Full Inbound Update
        if (!updatedClientOk && inboundObj && inboundObj.settings) {
          try {
            const inbSettings = typeof inboundObj.settings === "string" ? JSON.parse(inboundObj.settings) : inboundObj.settings;
            if (Array.isArray(inbSettings.clients)) {
              let foundInInb = false;
              for (let i = 0; i < inbSettings.clients.length; i++) {
                const cl = inbSettings.clients[i];
                if (cl && (cl.id === uid || cl.email === safeEmail)) {
                  inbSettings.clients[i] = mergedC;
                  foundInInb = true;
                  break;
                }
              }
              if (foundInInb) {
                const inbPayload = {
                  ...inboundObj,
                  settings: JSON.stringify(inbSettings)
                };
                const inbUpdRes = await xuiFetch(`${baseUrl}/panel/api/inbounds/update/${inbIdStr}`, {
                  method: "POST",
                  headers: { ...headers, "Content-Type": "application/json" },
                  body: JSON.stringify(inbPayload)
                }, 10000);
                if (inbUpdRes.ok) {
                  console.log(`[XUI Toggle API] Set client enable=${enabled} for '${safeEmail || uid}' via full inbound update`);
                  toggledAtLeastOnce = true;
                  updatedClientOk = true;
                }
              }
            }
          } catch (e) {}
        }

      } catch (e) {
        // Continue trying remaining servers
      }
    }

    return {
      success: toggledAtLeastOnce,
      error: toggledAtLeastOnce ? undefined : "Toggle failed on all servers or client was not found",
    };
  } catch (e: any) {
    return { success: false, error: e.message || "Exception during toggle" };
  }
}

// 2.5 Change/Reset client UUID and Subscription ID on XUI Panel (Highly Resilient with delete/add fallback and local generation fallback)
async function resetVpnClientUuidApi(clientEmail: string, serverId?: string) {
  try {
    const db = readSqliteDb();
    const settings = getSystemSettings(db);
    const crypto = await import("crypto");

    // Pre-generate standard credentials locally as fallback
    const newUuid = crypto.randomUUID();
    const newSubId = crypto.randomBytes(8).toString("hex");

    const activeServers = getActiveServers(settings);

    let chosenServer = activeServers.length > 0 ? activeServers[0] : null;
    if (serverId) {
      const found = activeServers.find((s: any) => s.id === serverId);
      if (found) {
        chosenServer = found;
      }
    }

    const subBase =
      chosenServer &&
      chosenServer.subUrl &&
      chosenServer.subUrl.trim() !== ""
        ? normalizeXuiUrl(chosenServer.subUrl)
        : chosenServer
          ? normalizeXuiUrl(chosenServer.panelUrl)
          : "https://tr.sub-daltoon.ir:2096";
    const subLink = `${subBase}/sub/${newSubId}`;

    const targetServers = serverId
      ? activeServers.filter((s: any) => s.id === serverId)
      : activeServers;

    if (targetServers.length === 0) {
      console.warn(
        `[resetVpnClientUuidApi] XUI disconnected/not configured. Performing local-only database reset fallback for ${clientEmail}`,
      );
      return {
        success: true,
        clientUuid: newUuid,
        subLink,
        wasLocalFallback: true,
      };
    }

    let panelUpdatedOnce = false;

    for (const server of targetServers) {
      try {
        const cleanedUrl = normalizeXuiUrl(server.panelUrl);

        const panelType = (server.panelType || "sanaei").toLowerCase();
        if (["rebecca", "pasarguard", "marzban"].includes(panelType)) {
          try {
            const token = await loginReebekaPasarguard(cleanedUrl, server.panelUsername, server.panelPassword);
            if (token) {
              let safeEmail = clientEmail ? clientEmail.replace(/ /g, "_").replace(/\n/g, "").replace(/\//g, "").replace(/[^A-Za-z0-9_-]/g, "") : "";
              
              // 1. Try POST /api/user/{username}/reset
              const resetRes = await xuiFetch(`${cleanedUrl}/api/user/${safeEmail}/reset`, {
                method: "POST",
                headers: { "Authorization": `Bearer ${token}`, "Accept": "application/json" }
              }, 10000).catch(() => null);

              if (resetRes && resetRes.ok) {
                const resJson = await resetRes.json().catch(() => ({}));
                console.log(`[resetVpnClientUuidApi] Successfully reset UUID/sub on ${panelType} panel.`);
                const subL = resJson?.subscription_url || (resJson?.links && resJson.links[0]) || `${subBase}/sub/${safeEmail}`;
                return { success: true, clientUuid: newUuid, subLink: subL };
              }

              // 2. Try POST /api/user/{username}/revoke_sub
              const revokeRes = await xuiFetch(`${cleanedUrl}/api/user/${safeEmail}/revoke_sub`, {
                method: "POST",
                headers: { "Authorization": `Bearer ${token}`, "Accept": "application/json" }
              }, 10000).catch(() => null);

              if (revokeRes && revokeRes.ok) {
                const resJson = await revokeRes.json().catch(() => ({}));
                console.log(`[resetVpnClientUuidApi] Successfully revoked/reset sub on ${panelType} panel.`);
                const subL = resJson?.subscription_url || (resJson?.links && resJson.links[0]) || `${subBase}/sub/${safeEmail}`;
                return { success: true, clientUuid: newUuid, subLink: subL };
              }
            }
          } catch(e) {
            console.error(`[resetVpnClientUuidApi] Error on ${panelType} panel:`, e);
          }
        }

        const loginResult = await loginXuiPanel(
          cleanedUrl,
          server.panelUsername,
          server.panelPassword,
        );
        if (!loginResult.success || !loginResult.cookie) continue;

        const headers: Record<string, string> = {
          Cookie: loginResult.cookie,
          "Content-Type": "application/json",
          Accept: "application/json",
        };
        if (loginResult.csrfToken)
          headers["X-Csrf-Token"] = loginResult.csrfToken!;

        const baseUrl = await getResolvedBaseUrl(cleanedUrl, headers);

        // Fetch the client's current settings from list
        const listRes = await xuiFetch(
          `${baseUrl}/panel/api/inbounds/list`,
          { method: "GET", headers },
          8000,
        ).catch(() => null);
        if (!listRes || !listRes.ok) continue;

        const listJson = await listRes.json().catch(() => null);
        if (!listJson || !listJson.success || !Array.isArray(listJson.obj))
          continue;

        let targetClient: any = null;
        let oldUuid: string | null = null;
        let parentInboundId: number | null = null;

        for (const inb of listJson.obj) {
          if (!inb.settings) continue;
          try {
            const inbSettings =
              typeof inb.settings === "string"
                ? JSON.parse(inb.settings)
                : inb.settings;
            if (Array.isArray(inbSettings.clients)) {
              const client = inbSettings.clients.find(
                (c: any) => c.email === clientEmail,
              );
              if (client) {
                targetClient = { ...client };
                oldUuid = client.id;
                parentInboundId = inb.id;
                break;
              }
            }
          } catch (e) {}
        }

        if (!targetClient || !oldUuid) continue;

        // Set new UUID and Sub ID inside the cloned client schema
        targetClient.id = newUuid;
        targetClient.subId = newSubId;
        targetClient.tgId =
          typeof targetClient.tgId === "number"
            ? targetClient.tgId
            : parseInt(targetClient.tgId) || 0;

        const formHeaders: Record<string, string> = {
          Cookie: loginResult.cookie,
          "Content-Type": "application/x-www-form-urlencoded",
          Accept: "application/json",
        };
        if (loginResult.csrfToken) {
          formHeaders["X-Csrf-Token"] = loginResult.csrfToken;
        }

        const safeEmail = encodeURIComponent(clientEmail);
        const payloadStr = JSON.stringify({ clients: [targetClient] });
        const formBody = `id=${parentInboundId}&settings=${encodeURIComponent(payloadStr)}`;

        // Attempt different update combinations to retain traffic while changing UUID
        const attempts = [
          { url: `${baseUrl}/panel/api/clients/update/${safeEmail}`, isForm: true, body: formBody },
          { url: `${baseUrl}/panel/api/clients/update/${safeEmail}`, isForm: false, body: JSON.stringify(targetClient) },
          { url: `${baseUrl}/panel/api/clients/update/${oldUuid}`, isForm: true, body: formBody },
          { url: `${baseUrl}/panel/api/clients/update/${oldUuid}`, isForm: false, body: JSON.stringify(targetClient) },
          { url: `${baseUrl}/panel/api/inbounds/updateClient/${oldUuid}`, isForm: true, body: formBody },
          { url: `${baseUrl}/panel/api/inbounds/updateClient/${oldUuid}`, isForm: false, body: JSON.stringify({ id: parentInboundId, settings: payloadStr }) }
        ];

        for (const attempt of attempts) {
          const reqHeaders = attempt.isForm ? formHeaders : headers;
          const aRes = await xuiFetch(attempt.url, { method: "POST", headers: reqHeaders, body: attempt.body }, 5000).catch(()=>null);
          if (aRes && aRes.ok) {
            const r = await aRes.json().catch(()=>({}));
            if (r.success) {
              panelUpdatedOnce = true;
              break;
            }
          }
        }
      } catch (err) {
        // Continue to next server
      }
    }

    if (panelUpdatedOnce) {
      return { success: true, clientUuid: newUuid, subLink };
    }

    console.warn(
      `[resetVpnClientUuidApi] Panel-facing recreation rejected, completing with database-level local update.`,
    );
    return {
      success: true,
      clientUuid: newUuid,
      subLink,
      wasLocalFallback: true,
    };
  } catch (e: any) {
    console.error("[resetVpnClientUuidApi] helper crash:", e);
    // Safe final local database generation guarantee
    try {
      const crypto = await import("crypto");
      const newUuid = crypto.randomUUID();
      const newSubId = crypto.randomBytes(8).toString("hex");
      const db = readSqliteDb();
      const settings = getSystemSettings(db);

      const activeServers = getActiveServers(settings);
      let fallbackServer = activeServers.length > 0 ? activeServers[0] : null;
      const subBase =
        fallbackServer &&
        fallbackServer.subUrl &&
        fallbackServer.subUrl.trim() !== ""
          ? normalizeXuiUrl(fallbackServer.subUrl)
          : fallbackServer
            ? normalizeXuiUrl(fallbackServer.panelUrl)
            : "https://tr.sub-daltoon.ir:2096";
      const subLink = `${subBase}/sub/${newSubId}`;
      return {
        success: true,
        clientUuid: newUuid,
        subLink,
        wasLocalFallback: true,
      };
    } catch (err) {
      return { success: false, error: "Exception during reset: " + e.message };
    }
  }
}

// 2.5 Test XUI Panel connection
app.post("/api/xui/test-connection", requireAdminAuth, async (req, res) => {
  try {
    const { baseUrl, panelUsername, panelPassword, panelType, panelToken } = req.body;
    
    if (["rebecca", "pasarguard", "marzban"].includes((panelType || "").toLowerCase())) {
      if (!baseUrl || !panelUsername || !panelPassword) {
        return res.json({
          success: false,
          error: "آدرس هاست، نام کاربری و رمز عبور الزامی است.",
        });
      }
      const cleanedUrl = normalizeXuiUrl(baseUrl);
      
      try {
        const access_token = await loginReebekaPasarguard(cleanedUrl, panelUsername, panelPassword);
        if (access_token) {
          let inbounds: any[] = [];
          const endpoints = ["/api/v2/services", "/api/services", "/api/groups/simple", "/api/groups", "/api/v1/inbound/list", "/api/v1/inbounds/list"];
          for (const ep of endpoints) {
            try {
              const sRes = await xuiFetch(
                `${cleanedUrl}${ep}`,
                {
                  method: "GET",
                  headers: {
                    Authorization: `Bearer ${access_token}`,
                    Accept: "application/json"
                  }
                },
                5000
              );
              if (sRes.ok) {
                const sData = await sRes.json().catch(() => ({}));
                const list = sData.services || sData.groups || sData.data || sData.obj || (Array.isArray(sData) ? sData : []);
                if (Array.isArray(list) && list.length > 0) {
                  inbounds = list.map((s: any) => ({
                    id: s.id,
                    remark: s.remark || s.name || `Service #${s.id}`,
                    port: s.port || 0,
                    protocol: s.protocol || "service"
                  }));
                  break;
                }
              }
            } catch (e) {}
          }
          
          return res.json({
            success: true,
            message: `اتصال به پنل با موفقیت انجام شد.`,
            panelToken: access_token,
            inbounds,
          });
        } else {
          return res.json({
            success: false,
            error: "نام کاربری یا رمز عبور نامعتبر است یا امکان برقراری ارتباط وجود ندارد.",
          });
        }
      } catch (err: any) {
        return res.json({
          success: false,
          error: "خطا در ارتباط با پنل: " + err.message,
        });
      }
    }

    const pType = (panelType || "sanaei").toLowerCase();
    let panelLabel = "پنل سنایی (Sanaei)";
    if (pType === "dui") panelLabel = "پنل دالتون (D-UI)";
    else if (pType === "rebecca") panelLabel = "پنل ربکا (Reebeka)";
    else if (pType === "pasarguard") panelLabel = "پنل پاسارگارد (Pasarguard)";
    else if (pType === "sanaei") panelLabel = "پنل سنایی (Sanaei)";
    else panelLabel = "پنل Xray";

    if (!baseUrl || !panelUsername || !panelPassword) {
      return res.json({
        success: false,
        error:
          `تمامی فیلدهای احراز هویت شامل آدرس هاست، نام کاربری و رمز عبور ${panelLabel} باید پر شده باشند.`,
      });
    }

    const cleanedUrl = normalizeXuiUrl(baseUrl);
    const loginResult = await loginXuiPanel(
      cleanedUrl,
      panelUsername,
      panelPassword,
      true, // ALWAYS forceFresh for test-connection!
    );

    if (loginResult.success) {
      // Confirm read access rights on the list api
      try {
        const listHeaders: Record<string, string> = {
          Cookie: loginResult.cookie!,
          Accept: "application/json, text/plain, */*",
        };
        if (loginResult.csrfToken) {
          listHeaders["X-Csrf-Token"] = loginResult.csrfToken!;
        }
        
        const listCandidates = getInboundListCandidates(cleanedUrl);
        let rawInboundList: any[] | null = null;
        for (const candidateUrl of listCandidates) {
          try {
            console.log(`[Diagnostic] Trying to fetch inbounds from: ${candidateUrl}`);
            const listRes = await xuiFetch(
              candidateUrl,
              {
                method: "GET",
                headers: listHeaders,
              },
              8000,
            );
            if (listRes.ok) {
              const contentType = (listRes.headers.get("content-type") || "").toLowerCase();
              const finalUrl = (listRes.url || "").toLowerCase();
              const isRedirectedToLogin = finalUrl.includes("/login");
              if (!contentType.includes("text/html") && !isRedirectedToLogin) {
                const listText = await listRes.text();
                const cleanText = listText.trim();
                const isHtml = cleanText.startsWith("<") || cleanText.toLowerCase().includes("<!doctype");
                if (!isHtml) {
                  let listJson: any = null;
                  try {
                    listJson = JSON.parse(cleanText);
                  } catch (e) {}
                  const extracted = extractInboundListFromResponse(listJson);
                  if (extracted !== null) {
                    rawInboundList = extracted;
                    break;
                  }
                }
              }
            }
          } catch (err) {}
        }

        let freshInbounds: any[] = [];
        if (rawInboundList !== null) {
          freshInbounds = rawInboundList.map((item: any) => {
            let totalClientsCount = 0;
            try {
              const settingsObj =
                typeof item.settings === "string"
                  ? JSON.parse(item.settings)
                  : item.settings;
              if (settingsObj && Array.isArray(settingsObj.clients)) {
                totalClientsCount = settingsObj.clients.length;
              }
            } catch (e) {}
            const usedGb = (
              (Number(item.up || 0) + Number(item.down || 0)) /
              (1024 * 1024 * 1024)
            ).toFixed(1);
            const limitGb = item.total
              ? (Number(item.total) / (1024 * 1024 * 1024)).toFixed(0)
              : "unlimited";
            return {
              id: item.id !== undefined ? item.id : 1,
              remark: item.remark || item.name || item.title || item.tag || `Inbound #${item.id || 1}`,
              protocol: item.protocol || "vless",
              port: item.port || 1234,
              totalClients: totalClientsCount,
              trafficUsed: usedGb,
              trafficLimit: limitGb,
              status: item.enable === false ? "inactive" : "active",
            };
          });
          return res.json({
            success: true,
            message:
              `اتصال به ${panelLabel} با موفقیت برقرار شد و لیست اینباندها (${freshInbounds.length} اینباند) دریافت گردید!`,
            inbounds: freshInbounds,
          });
        } else {
          return res.json({
            success: true,
            message:
              `اتصال به ${panelLabel} با موفقیت برقرار شد و ارتباط فعال است! اما لیستی یافت نشد.`,
            inbounds: [],
          });
        }
      } catch (err: any) {
        return res.json({
          success: true,
          message:
            `اتصال به ${panelLabel} با موفقیت برقرار شد و ارتباط فعال است!`,
          inbounds: [],
        });
      }
    } else {
      return res.json({
        success: false,
        error:
          loginResult.error ||
          "خطا در احراز هویت. نام کاربری یا رمز عبور پنل نادرست است.",
      });
    }
  } catch (error: any) {
    return res.json({
      success: false,
      error: `خطا در اتصال به هاست پنل: ${error.message}`,
    });
  }
});

// BROADCAST ENDPOINT
app.post("/api/broadcast", requireAdminAuth, async (req, res) => {
  try {
    const { text, attachment, serverUrl, captionPosition, buttons, buttonLayout } = req.body;
    if (!text && !attachment) {
      return res.status(400).json({
        success: false,
        error: "متن پیام یا رسانه برای ارسال الزامی است.",
      });
    }

    // Process attachment if provided
    let fileUrl = "";
    let attachmentBuffer: Buffer | null = null;
    if (attachment && attachment.fileData) {
      try {
        const uploadsDir = path.join(process.cwd(), "uploads");
        if (!fs.existsSync(uploadsDir)) {
          fs.mkdirSync(uploadsDir, { recursive: true });
        }

        let base64Data = attachment.fileData;
        if (base64Data.includes(";base64,")) {
          base64Data = base64Data.split(";base64,").pop() || "";
        }

        attachmentBuffer = Buffer.from(base64Data, "base64");
        const ext =
          path.extname(attachment.fileName) ||
          (attachment.fileType === "image"
            ? ".jpg"
            : attachment.fileType === "video"
              ? ".mp4"
              : attachment.fileType === "voice"
                ? ".ogg"
                : ".bin");
        const uniqueFileName = `broadcast_${Date.now()}_${Math.random().toString(36).substring(2, 7)}${ext}`;
        const filePath = path.join(uploadsDir, uniqueFileName);

        fs.writeFileSync(filePath, attachmentBuffer);

        const originUrl =
          serverUrl ||
          "https://ais-dev-cri25e3qykgpuufepdfpmw-413733104605.europe-west3.run.app";
        fileUrl = `${originUrl}/uploads/${uniqueFileName}`;
        console.log(
          `[Broadcast] File written to: ${filePath}, public url: ${fileUrl}`,
        );
      } catch (err: any) {
        console.error("[Broadcast] Failed storing attachment file:", err);
      }
    }

    const db = readSqliteDb();
    const settings = getSystemSettings(db);
    let botToken =
      settings.botToken || settings.BOT_TOKEN || process.env.BOT_TOKEN;
    if (botToken) botToken = botToken.trim();
    const users = db.users || [];
    let count = 0;

    // Build inline keyboard array if buttons provided
    let inlineKeyboard: any[] = [];
    if (Array.isArray(buttons) && buttons.length > 0) {
      const useButtonColors = String(settings.useButtonColors || "false") === "true";
      const usePremium = String(settings.usePremiumEmojis || "false") === "true";
      const primaryColors = settings.primaryButtonColors || {};
      const primaryTexts: Record<string, string> = {
        [settings.btnTextBuyNew || "🛒 خرید اشتراک جدید"]: "btnBuyNew",
        [settings.btnTextMySubs || "🗂 اشتراک های من / تمدید"]: "btnMySubs",
        [settings.btnTextGuides || "💡 آموزش ها"]: "btnGuides",
        [settings.btnTextProfile || "👤 حساب کاربری"]: "btnProfile",
        [settings.btnTextSupport || "📞 پشتیبانی"]: "btnSupport",
        [settings.btnTextTicketSupport || "🎫 تیکت به پشتیبانی"]: "btnTicketSupport",
        [settings.btnTextFreeTest || "🎁 موجودی رایگان"]: "btnFreeTest",
        [settings.btnTextInstantSupport || "🤖 پشتیبانی آنی"]: "btnInstantSupport",
        [settings.btnTextFeedback || "💌 بازخورد کاربر ها"]: "btnFeedback",
        [settings.btnTextReferral || "👥 زیرمجموعه گیری"]: "btnReferral",
        [settings.btnTextWallet || "شارژ کیف پول 💳"]: "btnWallet",
        [settings.btnTextColleagues || "بسته ویژه همکاران"]: "btnColleagues",
        [settings.btnTextAiChat || "🤖 چت با ربات"]: "btnAiChat",
        [settings.btnTextAi || "🧠 هوش مصنوعی"]: "btnAi",
        [settings.btnTextAddConfig || "➕ افزودن کانفیگ به ربات"]: "btnAddConfig",
        [settings.btnTextConfigDetails || "📊 مشخصات کانفیگ"]: "btnConfigDetails",
        [settings.btnTextSearchConfig || "🔍 سرچ کانفیگ (مدیریت)"]: "btnSearchConfig",
      };

      const cleanBtnText = (t: string) => {
        if (!t) return "";
        return Array.from(t).filter(c => c.charCodeAt(0) < 0x2000 || (c.charCodeAt(0) >= 0xFB00 && c.charCodeAt(0) <= 0xFEFF)).join("").trim();
      };

      const getButtonStyle = (btnText: string) => {
        const cleaned = cleanBtnText(btnText);
        let matchedKey = null;
        for (const [txt, key] of Object.entries(primaryTexts)) {
          if (txt === btnText || cleanBtnText(txt) === cleaned) {
            matchedKey = key;
            break;
          }
        }
        if (matchedKey) {
          const color = primaryColors[matchedKey];
          if (color && color !== "none") return color;
          return null;
        }
        const customStyles = settings.buttonStylesMapping || { "success": [], "danger": [], "primary": [] };
        for (const [style, keywords] of Object.entries(customStyles)) {
          if (Array.isArray(keywords)) {
            for (const kw of keywords) {
              if (kw && btnText.includes(kw)) return style;
            }
          }
        }
        return null;
      };

      const formattedButtons = buttons.map((btn: any) => {
        let item: any = { text: btn.text || "دکمه" };
        if (btn.type === "miniapp" || btn.id === "btnMiniApp" || btn.id === "miniapp") {
          let miniAppUrl = btn.url || settings.miniAppUrl || `${serverUrl || ""}/miniapp`;
          if (miniAppUrl && !miniAppUrl.startsWith("http://") && !miniAppUrl.startsWith("https://")) {
            miniAppUrl = "https://" + miniAppUrl;
          }
          item.web_app = { url: miniAppUrl };
        } else if (btn.type === "url" || btn.url) {
          let targetUrl = btn.url || btn.targetUrl || "";
          if (targetUrl && !targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
            targetUrl = "https://" + targetUrl;
          }
          item.url = targetUrl;
        } else if (btn.type === "custom") {
          if (btn.replyText && (btn.replyText.startsWith("http://") || btn.replyText.startsWith("https://"))) {
            item.url = btn.replyText;
          } else if (btn.index !== undefined) {
            item.callback_data = `mm_custom_${btn.index}`;
          } else {
            item.callback_data = `mm_custom_${btn.id || 0}`;
          }
        } else {
          item.callback_data = btn.callbackData || `mm_${btn.key || btn.id}`;
        }

        // Apply styles if enabled
        if (useButtonColors) {
          let assignedStyle = btn.color || (btn.id ? primaryColors[btn.id] : null);
          if (!assignedStyle || assignedStyle === "none") {
            assignedStyle = getButtonStyle(item.text);
          }
          if (assignedStyle && assignedStyle !== "none") {
            item.style = assignedStyle;
          }
        }

        // Apply premium custom emojis if enabled
        if (usePremium) {
          const customEmojis = settings.premiumEmojiMapping || {
            "🛒": "5449640306352655512",
            "🎁": "5368324170671202286",
            "👤": "5368324170671202287",
            "🎧": "5368324170671202288",
            "🚀": "5368324170671202289",
            "✅": "5368324170671202290",
            "❌": "5368324170671202291",
            "⚠️": "5368324170671202292",
            "💎": "5368324170671202293",
            "💰": "5368324170671202294",
            "📊": "5368324170671202295",
            "🔄": "5368324170671202296",
            "🎫": "5368324170671202297",
            "⚡": "5368324170671202298",
            "💳": "5368324170671202299",
            "📝": "5368324170671202300",
            "⏳": "5368324170671202301",
            "🌐": "5368324170671202302",
            "⚙️": "5368324170671202303",
            "🔌": "5368324170671202304",
            "🔋": "5368324170671202305",
            "💡": "5368324170671202306",
            "🔒": "5368324170671202307",
            "🔓": "5368324170671202308",
            "🔑": "5368324170671202309",
            "🇮🇷": "5368324170671202310",
            "🇩🇪": "5368324170671202311",
            "🇺🇸": "5368324170671202312",
            "🇬🇧": "5368324170671202313",
            "🇫🇷": "5368324170671202314",
            "🇳🇱": "5368324170671202315",
            "🇹🇷": "5368324170671202316",
            "🇨🇦": "5368324170671202317",
            "🇫🇮": "5368324170671202318",
            "🇷🇺": "5368324170671202319",
            "🇦🇪": "5368324170671202320",
            "🇺🇦": "5368324170671202321",
            "🇵🇱": "5368324170671202322",
            "🇸🇪": "5368324170671202323",
            "🇦🇹": "5368324170671202324",
            "🇨🇭": "5368324170671202325",
            "🇮🇹": "5368324170671202326",
            "🇪🇸": "5368324170671202327",
            "🇧🇷": "5368324170671202328",
            "🇮🇳": "5368324170671202329",
            "🇨🇳": "5368324170671202330",
            "🇯🇵": "5368324170671202331",
            "🇰🇷": "5368324170671202332",
            "🇦🇺": "5368324170671202333",
            "🇿🇦": "5368324170671202334",
            "🇲🇽": "5368324170671202335",
            "🇦🇷": "5368324170671202336",
            "🇸🇦": "5368324170671202337",
            "🇮🇶": "5368324170671202338",
          };
          let hasCustom = false;
          for (const [std, customId] of Object.entries(customEmojis)) {
            if (item.text.includes(std)) {
              if (!hasCustom) {
                item.icon_custom_emoji_id = String(customId);
                hasCustom = true;
              }
              item.text = item.text.split(std).join("").split("  ").join(" ").trim();
            }
          }
        }

        return item;
      });

      if (buttonLayout === "pair") {
        for (let i = 0; i < formattedButtons.length; i += 2) {
          if (i + 1 < formattedButtons.length) {
            inlineKeyboard.push([formattedButtons[i], formattedButtons[i + 1]]);
          } else {
            inlineKeyboard.push([formattedButtons[i]]);
          }
        }
      } else {
        formattedButtons.forEach((b: any) => {
          inlineKeyboard.push([b]);
        });
      }
    }

    if (botToken && botToken !== "DUMMY_TOKEN") {
      for (const u of users) {
        if (u.userId) {
          try {
            // Determine API method and payload based on attachment presence and type
            let apiUrl = `https://api.telegram.org/bot${botToken}/sendMessage`;
            let useFormData = false;
            let formData: any = null;
            let payload: any = {
              chat_id: u.userId,
              parse_mode: "HTML",
            };

            if (inlineKeyboard.length > 0) {
              payload.reply_markup = {
                inline_keyboard: inlineKeyboard,
              };
            }

            if (attachmentBuffer && attachment) {
              useFormData = true;
              formData = new FormData();
              formData.append("chat_id", u.userId.toString());
              formData.append("parse_mode", "HTML");
              if (text) {
                formData.append("caption", text);
              }
              if (captionPosition === "above") {
                formData.append("show_caption_above_media", "true");
              }
              if (inlineKeyboard.length > 0) {
                formData.append("reply_markup", JSON.stringify({
                  inline_keyboard: inlineKeyboard,
                }));
              }

              const fileType = attachment.fileType || "file";
              const mimeType =
                attachment.fileType === "image"
                  ? "image/jpeg"
                  : attachment.fileType === "video"
                    ? "video/mp4"
                    : attachment.fileType === "voice"
                      ? "audio/ogg"
                      : "application/octet-stream";

              const blob = new Blob([attachmentBuffer], { type: mimeType });
              const filename =
                attachment.fileName ||
                (fileType === "image"
                  ? "photo.jpg"
                  : fileType === "video"
                    ? "video.mp4"
                    : fileType === "voice"
                      ? "voice.ogg"
                      : "file.bin");

              if (fileType === "image") {
                apiUrl = `https://api.telegram.org/bot${botToken}/sendPhoto`;
                formData.append("photo", blob, filename);
              } else if (fileType === "video") {
                apiUrl = `https://api.telegram.org/bot${botToken}/sendVideo`;
                formData.append("video", blob, filename);
              } else if (fileType === "voice") {
                apiUrl = `https://api.telegram.org/bot${botToken}/sendVoice`;
                formData.append("voice", blob, filename);
              } else {
                apiUrl = `https://api.telegram.org/bot${botToken}/sendDocument`;
                formData.append("document", blob, filename);
              }
            } else {
              payload.text = text;
            }

            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 seconds timeout per user

            try {
              console.log(
                `[Broadcast] Sending to user ${u.userId} via Telegram API...`,
              );
              const response = await fetch(apiUrl, {
                method: "POST",
                headers: useFormData
                  ? undefined
                  : {
                      "Content-Type": "application/json",
                    },
                body: useFormData ? formData : JSON.stringify(payload),
                signal: controller.signal,
              });
              clearTimeout(timeoutId);

              const data = (await response.json()) as any;
              if (data && data.ok) {
                count++;
                console.log(
                  `[Broadcast] Successfully sent to user ${u.userId}`,
                );
              } else {
                console.error(
                  `[Broadcast] Telegram API error for user ${u.userId}:`,
                  data,
                );
              }
            } catch (err: any) {
              clearTimeout(timeoutId);
              console.error(
                `[Broadcast] Network/Timeout error sending to user ${u.userId}:`,
                err.message || err,
              );
            }
            // Gentle sleep of 50ms to respect Telegram rate limits and socket recycling
            await new Promise((resolve) => setTimeout(resolve, 50));
          } catch (e: any) {
            console.error(
              `[Broadcast] Failed to send message to user ${u.userId}:`,
              e,
            );
          }
        }
      }
    } else {
      console.warn("[Broadcast] No valid bot token found! Faking count.");
      count = users.length;
    }

    res.json({ success: true, count, message: "Broadcast dispatched." });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 3. User operations range
app.post("/api/users", requireAdminAuth, async (req, res) => {
  try {
    const { userId, username, walletBalance, joinDate, status } = req.body;
    const db = readSqliteDb();

    const idx = db.users.findIndex((u) => u.userId === Number(userId));
    const existing = idx >= 0 ? db.users[idx] : null;

    const nextUser = {
      userId: Number(userId),
      username,
      walletBalance: Number(walletBalance),
      activePlansCount: existing ? existing.activePlansCount : 0,
      joinDate: joinDate || new Date().toISOString().split("T")[0],
      status: status || "active",
    };

    if (idx >= 0) {
      db.users[idx] = nextUser;
    } else {
      db.users.unshift(nextUser);
    }

    writeSqliteDb(db);
    res.json({ success: true, message: "User written/updated." });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/users/adjust", requireAdminAuth, async (req, res) => {
  try {
    const { userId, amount } = req.body;
    const db = readSqliteDb();

    const user = db.users.find((u) => u.userId === Number(userId));
    if (!user) {
      return res
        .status(404)
        .json({ success: false, message: "User not found." });
    }

    const nextBal = Math.max(0, Number(user.walletBalance) + Number(amount));
    const finalDiff = nextBal - Number(user.walletBalance);
    user.walletBalance = nextBal;

    if (!db.logs) db.logs = [];
    db.logs.push({
      id: Math.random().toString(36).substring(2, 9),
      date: new Date().toISOString(),
      userId: Number(userId),
      username: user.username || `user_${userId}`,
      action: "تغییر موجودی",
      details: `موجودی کاربر توسط مدیر به میزان ${finalDiff >= 0 ? "+" : ""}${finalDiff.toLocaleString()} تومان تغییر یافت. موجودی نهایی: ${nextBal.toLocaleString()} تومان.`,
    });
    if ((db.logs ??= []).length > 1000) { db.logs = (db.logs ??= []).slice(-1000);
    }

    writeSqliteDb(db);

    res.json({ success: true, nextBal });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/users/ban", requireAdminAuth, async (req, res) => {
  try {
    const { userId, status } = req.body;
    const db = readSqliteDb();

    const user = db.users.find((u) => u.userId === Number(userId));
    if (user) {
      user.status = status;
      writeSqliteDb(db);
    }

    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/users/send-message", requireAdminAuth, async (req, res) => {
  try {
    const { userId, message } = req.body;
    if (!userId || !message) {
      return res.status(400).json({ success: false, error: "کاربر یا متن پیام ارسال نشده است." });
    }
    const db = readSqliteDb();
    const settings = getSystemSettings(db);
    let botToken = settings.botToken || settings.BOT_TOKEN || process.env.BOT_TOKEN;
    if (botToken) botToken = botToken.trim();

    if (!botToken || botToken === "DUMMY_TOKEN") {
      return res.status(400).json({ success: false, error: "توکن ربات تلگرام تنظیم نشده است یا نامعتبر است." });
    }

    const fetchRef = globalThis.fetch || fetch;
    const body = {
      chat_id: userId,
      text: message,
      parse_mode: "HTML",
    };

    const telegramRes = await fetchRef(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    const data = await telegramRes.json() as any;
    if (data && data.ok) {
      res.json({ success: true, message: "پیام با موفقیت به پیوی کاربر ارسال شد." });
    } else {
      res.status(400).json({
        success: false,
        error: data?.description || "خطا در ارسال پیام به تلگرام. ممکن است کاربر ربات را بلاک کرده باشد یا چت را شروع نکرده باشد."
      });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/users/delete", requireAdminAuth, async (req, res) => {
  try {
    const { userId } = req.body;
    const db = readSqliteDb();

    db.users = db.users.filter((u) => u.userId !== Number(userId));
    db.subscription_keys = db.subscription_keys.filter(
      (k) => k.userId !== Number(userId),
    );
    writeSqliteDb(db);

    res.json({ success: true, message: "User completely cleared." });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 4. Manual Transaction operations
app.post("/api/transactions", requireAdminAuth, async (req, res) => {
  try {
    const {
      id,
      userId,
      username,
      amount,
      receiptImage,
      status,
      date,
      description,
    } = req.body;
    const db = readSqliteDb();

    const nextTx = {
      id,
      userId: Number(userId),
      username,
      amount: Number(amount),
      receiptImage: receiptImage || "",
      status: status || "pending",
      date: date || new Date().toISOString(),
      description: description || "",
    };

    const idx = db.transactions.findIndex((t) => t.id === id);
    if (idx >= 0) {
      db.transactions[idx] = nextTx;
    } else {
      db.transactions.unshift(nextTx);
    }

    writeSqliteDb(db);
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/transactions/approve", requireAdminAuth, async (req, res) => {
  try {
    const { id, amount, overridePlanId, overrideServerId } = req.body;
    const db = readSqliteDb();

    if (!db.transactions) db.transactions = [];
    const tx = db.transactions.find((t: any) => String(t.id).trim() === String(id).trim());
    if (tx) {
      const isRenewTx = tx.type === "renew" || tx.planId === "custom_renew" || tx.pendingPurchase?.isRenew || tx.pendingPurchase?.type === "renew";
      if (tx.pendingPurchase) {
        if (!tx.planId && tx.pendingPurchase.planId) tx.planId = tx.pendingPurchase.planId;
        if (!tx.serverId && tx.pendingPurchase.serverId) tx.serverId = tx.pendingPurchase.serverId;
        if (!tx.clientName && (tx.pendingPurchase.clientUsername || tx.pendingPurchase.clientName)) {
          tx.clientName = tx.pendingPurchase.clientUsername || tx.pendingPurchase.clientName;
        }
        if (!tx.customGb && tx.pendingPurchase.customGb) tx.customGb = tx.pendingPurchase.customGb;
        if (!tx.customDays && tx.pendingPurchase.customDays) tx.customDays = tx.pendingPurchase.customDays;
        if (!isRenewTx && tx.type !== "PLAN_PURCHASE" && (tx.planId || tx.pendingPurchase.planId || tx.pendingPurchase.packageId)) {
          tx.type = "PLAN_PURCHASE";
        }
      }
      if (overridePlanId) {
        tx.type = "PLAN_PURCHASE";
        tx.planId = overridePlanId;
        if (overrideServerId) tx.serverId = overrideServerId;
      }
      if (!isRenewTx && tx.planId && tx.type !== "PLAN_PURCHASE") {
        tx.type = "PLAN_PURCHASE";
      }
      tx.status = "approved";
      if (amount !== undefined) {
        tx.amount = Number(amount);
      }

      // Persist status change immediately
      writeSqliteDb(db);

      const user = db.users.find((u) => u.userId === Number(tx.userId));

      let messageTextForNotif = "";

      if (isRenewTx) {
        // Priority Renewal Handler
        const targetSubId = tx.pendingPurchase?.subId || tx.pendingPurchase?.clientUuid || tx.clientName;
        const settings = getSystemSettings(db);
        const customGb = Number(tx.customGb || tx.pendingPurchase?.customGb || 10);
        const customDays = Number(tx.customDays || tx.pendingPurchase?.customDays || 30);

        const subscription_keys = db.subscription_keys || [];
        const k = subscription_keys.find(
          (sub: any) =>
            String(sub.id) === String(targetSubId) ||
            String(sub.clientUuid) === String(targetSubId) ||
            String(sub.clientName) === String(targetSubId) ||
            (tx.pendingPurchase?.clientUuid && String(sub.clientUuid) === String(tx.pendingPurchase.clientUuid)) ||
            (tx.pendingPurchase?.clientName && String(sub.clientName) === String(tx.pendingPurchase.clientName))
        );

        if (k) {
          const clientName = k.clientName || k.clientEmail || k.planName || "";
          const serverId = tx.pendingPurchase?.serverId || tx.serverId || k.serverId;

          let expDt = new Date();
          try {
            const parsed = new Date(k.expireDate);
            if (!isNaN(parsed.getTime()) && parsed.getTime() > Date.now()) {
              expDt = parsed;
            }
          } catch (e) {}

          const newExpDt = new Date(
            expDt.getTime() + customDays * 24 * 60 * 60 * 1000,
          );
          const newExpireDateStr = newExpDt.toISOString().split("T")[0];
          const newLimitGb = (Number(k.trafficLimitGb) || 0) + customGb;

          try {
            const addResult = await extendVpnClientApi(
              clientName,
              customGb,
              customDays,
              k.clientUuid,
              serverId,
              k.subLink
            );

            if (addResult.success) {
              // Existing client on panel was extended successfully
              k.expireDate = newExpireDateStr;
              k.trafficLimitGb = newLimitGb;
              k.status = "active";
              k.disabled = false;
            } else {
              // Client was deleted/not found on panel -> recreate client on the panel
              console.warn(`[Approve Renew] Client ${clientName} not found on panel, recreating on server ${serverId}...`);
              const vpnResult = await addVpnClientApi(
                clientName,
                customGb,
                customDays,
                settings,
                undefined,
                serverId
              );
              if (vpnResult.success && vpnResult.subLink) {
                k.clientUuid = vpnResult.clientUuid || k.clientUuid;
                k.subLink = vpnResult.subLink;
                k.vlessConfigs = vpnResult.vlessConfigs || [];
                k.vlessLinks = vpnResult.vlessLinks || [];
                k.trafficLimitGb = customGb;
                k.trafficUsedGb = 0;
                k.expireDate = new Date(Date.now() + customDays * 24 * 60 * 60 * 1000).toISOString().split("T")[0];
                k.status = "active";
                k.disabled = false;
                k.serverId = serverId;
              } else {
                k.expireDate = newExpireDateStr;
                k.trafficLimitGb = newLimitGb;
                k.status = "active";
                k.disabled = false;
              }
            }

            if (user) {
              user.activePlansCount = (db.subscription_keys || []).filter(
                (sub: any) => Number(sub.userId) === Number(user.userId) && sub.status === "active" && !sub.disabled
              ).length;
              if (Array.isArray(user.configs)) {
                const c = user.configs.find((cfg: any) => String(cfg.id) === String(k.id) || String(cfg.uuid) === String(k.clientUuid));
                if (c) {
                  c.expireDate = k.expireDate;
                  c.trafficLimitGb = k.trafficLimitGb;
                  c.status = "active";
                  c.disabled = false;
                  if (k.subLink) c.subLink = k.subLink;
                }
              }
            }

            const srvRemark = getServerRemark(serverId, settings, db, k.subLink);
            const activeServers = getActiveServers(settings);
            const srvObj = activeServers.find((s: any) => String(s.id) === String(serverId));
            const srvFlag = srvObj?.flag || (srvObj?.isColleague ? "👥" : "🌐");
            const srvDisplay = `${srvFlag} ${srvRemark}`;
            const shamsiExpDate = formatShamsiDate(newExpDt);

            messageTextForNotif = `🎉 <b>اشتراک شما با موفقیت تمدید شد! (تایید فیش)</b>\n\n` +
              `👤 <b>سرویس:</b> <code>${clientName}</code>\n` +
              `🌐 <b>سرور:</b> ${srvDisplay}\n` +
              `➕ <b>حجم افزوده شده:</b> <b>${customGb} گیگابایت</b>\n` +
              `➕ <b>مدت افزوده شده:</b> <b>${customDays} روز</b>\n\n` +
              `📅 <b>تاریخ انقضای جدید:</b> <b>${shamsiExpDate}</b>\n` +
              `📊 <b>حجم کل جدید:</b> <b>${k.trafficLimitGb} گیگابایت</b>\n\n` +
              `🔗 <b>لینک اشتراک:</b>\n<code>${k.subLink || ""}</code>`;

            tx._generatedSubId = k.id;
            tx._generatedSubLink = k.subLink;

            if (!db.logs) db.logs = [];
            (db.logs ??= []).push({
              id: Math.random().toString(36).substring(2, 9),
              date: new Date().toISOString(),
              userId: Number(tx.userId),
              username: tx.username || `user_${tx.userId}`,
              action: "تمدید اشتراک",
              details: `اشتراک ${clientName} تمدید و فعال شد (فیش تایید شد).`,
            });
          } catch (apiErr: any) {
            tx.status = "failed";
            messageTextForNotif = `❌ خطا در اعمال تمدید اشتراک روی سرور: ${apiErr.message}`;
          }
        } else {
          messageTextForNotif = `❌ خطا: اشتراک مورد نظر جهت تمدید یافت نشد.`;
        }
      } else if (tx.type === "PLAN_PURCHASE") {
        if (
          tx.planId &&
          (tx.planId.startsWith("COL_BUY:") ||
            tx.planId.startsWith("COL_RENEW:"))
        ) {
          // Colleague package fulfillment
          const isBuy = tx.planId.startsWith("COL_BUY:");
          const packageId = tx.planId.split(":")[1];

          const db_packages: any[] = db.colleague_packages || [];
          const pkg = db_packages.find((p) => p.id === packageId);

          if (pkg) {
            if (isBuy) {
              const parts = (tx.clientName || "").split("||");
              const prefix = parts[0] || "";
              const token = parts[1] || "";

              const username =
                "C" + Math.floor(Math.random() * 90000 + 10000).toString();
              const password = Math.random().toString(36).substring(2, 10);

              const newAcc = {
                id: Math.random().toString(36).substring(2, 15),
                userId: Number(tx.userId),
                username: username,
                password: password,
                packageId: pkg.id,
                packageTitle: pkg.title,
                createdAt: new Date().toISOString().split("T")[0],
                trafficGb: pkg.trafficGb,
                usedTrafficGb: 0,
                prefix: prefix,
                recoveryToken: token,
                status: "active",
              };

              if (!db.colleague_accounts) db.colleague_accounts = [];
              db.colleague_accounts.push(newAcc);

              messageTextForNotif = `✅ <b>خرید بسته همکار با موفقیت انجام شد!</b> (تایید فیش)\n\nبسته خریداری شده: ${pkg.title}\nپسوند تنظیم شده: ${prefix}\n\nاطلاعات ورود شما:\n👤 <b>یوزرنیم:</b> <code>${username}</code>\n🔑 <b>رمز عبور:</b> <code>${password}</code>\n\nجهت ورود به پنل، حساب خود را از طریق منو انتخاب کنید.`;
            } else {
              const accId = tx.clientName;
              const accIndex = (db.colleague_accounts || []).findIndex(
                (a: any) => a.id === accId,
              );
              if (accIndex !== -1) {
                const acc = db.colleague_accounts?.[accIndex];
                acc.trafficGb = (acc.trafficGb || 0) + pkg.trafficGb;
                acc.packageTitle = pkg.title;

                messageTextForNotif = `✅ <b>تمدید حساب همکار با موفقیت انجام شد!</b> (تایید فیش)\n\nحجم اضافه شده: ${pkg.trafficGb} گیگابایت\nلیست بسته تمدیدی: ${pkg.title}`;
              } else {
                messageTextForNotif = `❌ خطا: حساب همکار برای تمدید یافت نشد.`;
              }
            }
          } else {
            messageTextForNotif = `❌ خطا: بسته همکار یافت نشد.`;
          }
        } else {
          const db_plans: any[] = db.vpn_plans || [];
          // Hardcoded Fallback Plans (Must match bot.py)
          const fallback_plans = [
            {
              id: "std_30g",
              name: "Standard 30GB - 30 Days",
              price: 45000,
              trafficGb: 30,
              durationDays: 30,
              category: "Standard",
            },
            {
              id: "vip_70g",
              name: "VIP Premium 70GB - 60 Days",
              price: 95000,
              trafficGb: 70,
              durationDays: 60,
              category: "VIP",
            },
            {
              id: "ult_150g",
              name: "Unlimited VoIP 150GB - 90 Days",
              price: 185000,
              trafficGb: 150,
              durationDays: 90,
              category: "Unlimited VoIP",
            },
          ];

          let plan = db_plans.find((p: any) => String(p.id).trim() === String(tx.planId).trim());
          if (!plan) {
            plan = fallback_plans.find((p: any) => String(p.id).trim() === String(tx.planId).trim());
          }
          if (!plan && tx.amount) {
            plan = db_plans.find((p: any) => Number(p.price) === Number(tx.amount));
            if (!plan) {
              plan = fallback_plans.find((p: any) => Number(p.price) === Number(tx.amount));
            }
            if (plan) {
              tx.planId = plan.id;
              tx.type = "PLAN_PURCHASE";
            }
          }

          if (plan) {
            const clientName = tx.clientName || `user_${tx.userId}`;
            const settings = getSystemSettings(db);

            try {
              const planTraffic = Number(plan.trafficGb) || 30;
              const planDuration = Number(plan.durationDays) || 30;

              const vpnResult = await addVpnClientApi(
                clientName,
                planTraffic,
                planDuration,
                settings,
                undefined,
                tx.serverId,
              );
              if (vpnResult.success && vpnResult.subLink) {
                const subLink = vpnResult.subLink;

                let vlessLinks: string[] = vpnResult.vlessConfigs || [];
                if (vlessLinks.length === 0) {
                  try {
                    const fetchRef = globalThis.fetch || fetch;
                    const res = await fetchRef(subLink, { signal: (AbortSignal as any).timeout ? (AbortSignal as any).timeout(2000) : undefined });
                    if (res.ok) {
                      const text = await res.text();
                      const decoded = Buffer.from(text, "base64").toString(
                        "utf-8",
                      );
                      vlessLinks = decoded
                        .split("\n")
                        .filter(
                          (l) => l.trim().length > 0 && l.includes("://"),
                        );
                    }
                  } catch (e) {}
                }

                let linksDisplay = "";
                if (vlessLinks.length > 0) {
                  const linksText = vlessLinks
                    .map((l, i) => `🔸 <b>کانفیگ مستقیم VLESS (${i + 1}):</b>\n<code>${l}</code>`)
                    .join("\n\n");
                  linksDisplay = `🚀 <b>لینک‌های اتصال مستقیم (VLESS):</b>\n${linksText}\n\n👇 <b>لینک سابسکریپشن هوشمند:</b>\n<code>${subLink}</code>`;
                } else {
                  linksDisplay = `👇 <b>لینک سابسکریپشن اختصاصی شما (جهت کپی لمس کنید):</b>\n\n<code>${subLink}</code>\n\n💡 لینک بالا را کپی کرده و در برنامه v2rayNG یا V2box خود به عنوان <b>Subscription (سابسکریپشن)</b> وارد کرده و بروزرسانی نمایید تا همه کانفیگ‌ها دریافت شوند.`;
                }

                let planDetailsText = `📦 پلان: <b>${plan.name}</b>`;
                if (plan.category) {
                  const categoryObj = (db.plan_categories || []).find((c: any) => c.id === plan.category);
                  const categoryName = categoryObj ? categoryObj.name : plan.category;
                  if (categoryName) {
                    planDetailsText = `📦 پلان: <b>${categoryName} - ${plan.name}</b>`;
                  }
                }

                const activeServers = getActiveServers(settings);
                const srvRemark = getServerRemark(tx.serverId, settings, db, subLink);
                const selectedServer = activeServers.find((s: any) => String(s.id) === String(tx.serverId));
                const srvFlag = selectedServer?.flag || (selectedServer?.isColleague ? "👥" : "🌐");
                const serverDetailsText = `🌐 سرور: <b>${srvFlag} ${srvRemark}</b>\n\n`;

                messageTextForNotif = `✅ <b>رسید شما تایید و سرویس فعال شد!</b>\n\n${planDetailsText}\n${serverDetailsText}${linksDisplay}`;

                if (!db.subscription_keys) db.subscription_keys = [];
                const randomId =
                  "SUB-" + Date.now() + "-" + Math.floor(Math.random() * 90000 + 10000);
                const expireTimestamp =
                  Date.now() + planDuration * 24 * 60 * 60 * 1000;
                const expireDate = isNaN(expireTimestamp)
                  ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
                      .toISOString()
                      .split("T")[0]
                  : new Date(expireTimestamp).toISOString().split("T")[0];

                db.subscription_keys.push({
                  id: randomId,
                  userId: Number(tx.userId),
                  planId: plan.id,
                  planName: plan.name,
                  clientName: clientName,
                  clientUuid: vpnResult.clientUuid || "",
                  subLink: subLink,
                  vlessConfigs: vlessLinks,
                  vlessLinks: vpnResult.vlessLinks || [],
                  expireDate: expireDate,
                  trafficLimitGb: planTraffic,
                  trafficUsedGb: 0,
                  createdAtMs: Date.now(),
                  status: "active",
                  serverId: tx.serverId,
                });

                tx._generatedSubId = randomId;
                tx._generatedSubLink = subLink;

                if (!db.logs) db.logs = [];
                db.logs.push({
                  id: Math.random().toString(36).substring(2, 9),
                  date: new Date().toISOString(),
                  userId: Number(tx.userId),
                  username: tx.username || `user_${tx.userId}`,
                  action: "تحویل کانفیگ",
                  details: `اشتراک برای پلان ${plan.name} با نام ${clientName} تحویل داده شد.`,
                });
              } else {
                if (user) {
                  user.walletBalance = Number(user.walletBalance) + Number(tx.amount);
                }
                tx.status = "refunded";
                messageTextForNotif = `❌ <b>خطا در ساخت کانفیگ!</b>\n\nمتاسفانه مشکلی در اتصال به سرور جهت ساخت کانفیگ رخ داد:\n<code>${vpnResult.error || "خطای نامشخص"}</code>\n\n✅ سیستم جهت محافظت از شما، تراکنش را لغو کرده و مبلغ <b>${Number(tx.amount).toLocaleString()} تومان</b> را به صورت کامل به کیف پول داخلی شما در ربات عودت داد.\n\nاکنون می‌توانید از طریق کیف پول خود مجدداً اقدام کنید (در صورت رفع مشکل).`;

                if (!db.logs) db.logs = [];
                db.logs.push({
                  id: Math.random().toString(36).substring(2, 9),
                  date: new Date().toISOString(),
                  userId: Number(tx.userId),
                  username: tx.username || `user_${tx.userId}`,
                  action: "خطا و مرجوعی خودکار",
                  details: `خطا در ساخت کانفیگ برای ${clientName}: ${vpnResult.error || "Unknown"}. مبلغ به کیف پول برگشت داده شد.`,
                });
              }
            } catch (e: any) {
              messageTextForNotif = `❌ خطا در سیستم ساخت کانفیگ: ${e.message}`;
            }
          } else if (tx.planId === "custom_vol" || tx.planId === "custom") {
            const clientName = tx.clientName || `user_${tx.userId}`;
            const settings = getSystemSettings(db);
            const customGb = Number(tx.customGb) || 10;
            const customDays = Number(tx.customDays) || 30;

            try {
              const vpnResult = await addVpnClientApi(
                clientName,
                customGb,
                customDays,
                settings,
                undefined,
                tx.serverId,
              );
              if (vpnResult.success && vpnResult.subLink) {
                const subLink = vpnResult.subLink;

                let vlessLinks: string[] = [];
                try {
                  const fetchRef = globalThis.fetch || fetch;
                  const res = await fetchRef(subLink);
                  if (res.ok) {
                    const text = await res.text();
                    const decoded = Buffer.from(text, "base64").toString(
                      "utf-8",
                    );
                    vlessLinks = decoded
                      .split("\n")
                      .filter(
                        (l) => l.trim().length > 0 && l.includes("://"),
                      );
                  }
                } catch (e) {}

                let linksDisplay = "";
                if (vlessLinks.length > 0) {
                  const linksText = vlessLinks
                    .map((l) => `<code>${l}</code>`)
                    .join("\n\n");
                  linksDisplay = `🚀 <b>لینک‌های اتصال مستقیم:</b>\n${linksText}\n\n⚠️ لینک‌های بالا را کپی کرده و در کلاینت خود وارد کنید.`;
                } else {
                  linksDisplay = `⚠️ <b>توجه:</b> امکان استخراج تفکیکی لینک‌های کانفیگ در این لحظه میسر نشد.\n\n👇 <b>لطفاً از لینک سابسکریپشن اختصاصی خود استفاده کنید (جهت کپی لمس کنید):</b>\n\n<code>${subLink}</code>\n\n💡 لینک بالا را کپی کرده و در برنامه v2rayNG یا V2box خود به عنوان <b>Subscription (سابسکریپشن)</b> وارد کرده و بروزرسانی (Update) نمایید تا همه کانفیگ‌ها به طور خودکار دریافت شوند.`;
                }

                const activeServers = getActiveServers(settings);
                const srvRemark = getServerRemark(tx.serverId, settings, db, subLink);
                const selectedServer = activeServers.find((s: any) => String(s.id) === String(tx.serverId));
                const srvFlag = selectedServer?.flag || (selectedServer?.isColleague ? "👥" : "🌐");
                const serverDetailsText = `🌐 سرور: <b>${srvFlag} ${srvRemark}</b>\n\n`;

                messageTextForNotif = `✅ <b>کانفیگ دلخواه شما آماده شد!</b>\n\n📦 حجم: <b>${customGb} گیگابایت</b> | زمان: <b>${customDays} روز</b>\n${serverDetailsText}${linksDisplay}`;

                if (!db.subscription_keys) db.subscription_keys = [];
                const randomId =
                  "SUB-" + Date.now() + "-" + Math.floor(Math.random() * 90000 + 10000);
                const expireDate = new Date(
                  Date.now() + customDays * 24 * 60 * 60 * 1000,
                )
                  .toISOString()
                  .split("T")[0];

                db.subscription_keys.push({
                  id: randomId,
                  userId: Number(tx.userId),
                  planId: "custom_vol",
                  planName: `کانفیگ دلخواه ${customGb}GB`,
                  clientName: clientName,
                  clientUuid: vpnResult.clientUuid || "",
                  subLink: subLink,
                  vlessConfigs: vpnResult.vlessConfigs || vlessLinks || [],
                  vlessLinks: vpnResult.vlessLinks || [],
                  expireDate: expireDate,
                  trafficLimitGb: customGb,
                  trafficUsedGb: 0,
                  createdAtMs: Date.now(),
                  status: "active",
                  serverId: tx.serverId,
                });

                tx._generatedSubId = randomId;
                tx._generatedSubLink = subLink;

                if (!db.logs) db.logs = [];
                db.logs.push({
                  id: Math.random().toString(36).substring(2, 9),
                  date: new Date().toISOString(),
                  userId: Number(tx.userId),
                  username: tx.username || `user_${tx.userId}`,
                  action: "تحویل کانفیگ",
                  details: `اشتراک برای کانفیگ دلخواه با نام ${clientName} تحویل داده شد.`,
                });
              } else {
                tx.status = "failed";
                messageTextForNotif = `❌ <b>خطا در ساخت کانفیگ دلخواه!</b>\n\nمتاسفانه مشکلی در اتصال به سرور جهت ساخت کانفیگ رخ داد:\n<code>${vpnResult.error || "خطای نامشخص"}</code>\n\nلطفاً موضوع را با پشتیبانی هماهنگ فرمایید.`;
              }
            } catch (e: any) {
              messageTextForNotif = `❌ خطا در سیستم ساخت کانفیگ دلخواه: ${e.message}`;
            }
          } else if (tx.planId === "custom_renew" || tx.type === "renew" || tx.pendingPurchase?.type === "renew" || tx.pendingPurchase?.isRenew) {
            const targetSubId = tx.pendingPurchase?.subId || tx.pendingPurchase?.clientUuid || tx.clientName;
            const settings = getSystemSettings(db);
            const customGb = Number(tx.customGb || tx.pendingPurchase?.customGb || 10);
            const customDays = Number(tx.customDays || tx.pendingPurchase?.customDays || 30);

            const subscription_keys = db.subscription_keys || [];
            const k = subscription_keys.find(
              (sub: any) =>
                String(sub.id) === String(targetSubId) ||
                String(sub.clientUuid) === String(targetSubId) ||
                String(sub.clientName) === String(targetSubId)
            );

            if (k) {
              const clientName = k.clientName || k.clientEmail || k.planName || "";
              const serverId = tx.pendingPurchase?.serverId || k.serverId;

              let expDt = new Date();
              try {
                const parsed = new Date(k.expireDate);
                if (!isNaN(parsed.getTime()) && parsed.getTime() > Date.now()) {
                  expDt = parsed;
                }
              } catch (e) {}

              const newExpDt = new Date(
                expDt.getTime() + customDays * 24 * 60 * 60 * 1000,
              );
              const newExpireDateStr = newExpDt.toISOString().split("T")[0];
              const newLimitGb = (Number(k.trafficLimitGb) || 0) + customGb;

              try {
                const addResult = await extendVpnClientApi(
                  clientName,
                  customGb,
                  customDays,
                  k.clientUuid,
                  serverId,
                  k.subLink
                );

                k.expireDate = newExpireDateStr;
                k.trafficLimitGb = newLimitGb;
                k.status = "active";
                k.disabled = false;

                if (user) {
                  user.activePlansCount = (db.subscription_keys || []).filter(
                    (sub: any) => Number(sub.userId) === Number(user.userId) && sub.status === "active" && !sub.disabled
                  ).length;
                  if (Array.isArray(user.configs)) {
                    const c = user.configs.find((cfg: any) => String(cfg.id) === String(k.id) || String(cfg.uuid) === String(k.clientUuid));
                    if (c) {
                      c.expireDate = k.expireDate;
                      c.trafficLimitGb = k.trafficLimitGb;
                      c.status = "active";
                      c.disabled = false;
                    }
                  }
                }

                const srvRemark = getServerRemark(serverId, settings, db, k.subLink);
                const activeServers = getActiveServers(settings);
                const srvObj = activeServers.find((s: any) => String(s.id) === String(serverId));
                const srvFlag = srvObj?.flag || (srvObj?.isColleague ? "👥" : "🌐");
                const srvDisplay = `${srvFlag} ${srvRemark}`;
                const shamsiExpDate = formatShamsiDate(newExpDt);

                messageTextForNotif = `🎉 <b>اشتراک شما با موفقیت تمدید شد! (تایید فیش)</b>\n\n` +
                  `👤 <b>سرویس:</b> <code>${clientName}</code>\n` +
                  `🌐 <b>سرور:</b> ${srvDisplay}\n` +
                  `➕ <b>حجم افزوده شده:</b> <b>${customGb} گیگابایت</b>\n` +
                  `➕ <b>مدت افزوده شده:</b> <b>${customDays} روز</b>\n\n` +
                  `📅 <b>تاریخ انقضای جدید:</b> <b>${shamsiExpDate}</b>\n` +
                  `📊 <b>حجم کل جدید:</b> <b>${newLimitGb} گیگابایت</b>\n\n` +
                  `🔗 <b>لینک اشتراک:</b>\n<code>${k.subLink || ""}</code>`;

                tx._generatedSubId = k.id;
                tx._generatedSubLink = k.subLink;

                if (!db.logs) db.logs = [];
                db.logs.push({
                  id: Math.random().toString(36).substring(2, 9),
                  date: new Date().toISOString(),
                  userId: Number(tx.userId),
                  username: tx.username || `user_${tx.userId}`,
                  action: "تمدید اشتراک",
                  details: `اشتراک ${clientName} تمدید و فعال شد (فیش تایید شد).`,
                });
              } catch (apiErr: any) {
                tx.status = "failed";
                messageTextForNotif = `❌ خطا در اعمال تمدید اشتراک روی سرور: ${apiErr.message}`;
              }
            } else {
              messageTextForNotif = `❌ خطا: اشتراک مورد نظر جهت تمدید یافت نشد.`;
            }
          } else {
            messageTextForNotif = `❌ خطا: پلان مورد نظر یافت نشد. با پشتیبانی هماهنگ کنید.`;
          }
        }
      } else {
        if (user) {
          user.walletBalance = Number(user.walletBalance) + Number(tx.amount);
        }
        messageTextForNotif = `✅ <b>تراکنش شما تایید شد!</b>\n\n💰 مبلغ <b>${tx.amount.toLocaleString()} تومان</b> به کیف پول شما در ربات افزوده شد.\n\n💰 موجودی جدید: <b>${user ? user.walletBalance.toLocaleString() : "0"} تومان</b>`;
      }

      if (tx.type !== "PLAN_PURCHASE") {
        (db.logs ??= []).push({
          id: Math.random().toString(36).substring(2, 9),
          date: new Date().toISOString(),
          userId: Number(tx.userId),
          username: tx.username || `user_${tx.userId}`,
          action: "تایید شارژ",
          details: `رسید تراکنش به شناسه ${tx.id} و مبلغ ${Number(tx.amount).toLocaleString()} تومان توسط مدیر تایید شد و به کیف پول کاربر افزایش یافت.`,
        });
      }

      if ((db.logs ??= []).length > 1000) {
        db.logs = (db.logs ??= []).slice(-1000);
      }

      writeSqliteDb(db);

      // Try to notify the user via Telegram Bot API on success
      let notifiedUser = false;
      try {
        const cfg = getSystemSettings(db);
        let botToken = (cfg.botToken && cfg.botToken.trim() !== "" && cfg.botToken !== "DUMMY_TOKEN")
          ? cfg.botToken.trim()
          : (cfg.BOT_TOKEN && cfg.BOT_TOKEN.trim() !== "" && cfg.BOT_TOKEN !== "DUMMY_TOKEN")
            ? cfg.BOT_TOKEN.trim()
            : (process.env.BOT_TOKEN || "").trim();

        const isPurchaseOrReceipt = tx.type === "PLAN_PURCHASE" || tx.receiptImage || isRenewTx;
        const shouldSendApprovedMsg = isPurchaseOrReceipt
          ? isBotNotificationEnabled(db, "notifyUserReceiptApproved", true)
          : isBotNotificationEnabled(db, "notifyUserWalletCharge", true);

        if (botToken && botToken !== "DUMMY_TOKEN" && shouldSendApprovedMsg) {
          let replyMarkupObj: any = undefined;

          if (
            (tx.type === "PLAN_PURCHASE" || tx.type === "renew" || tx.pendingPurchase?.isRenew || tx.planId === "custom_renew") &&
            tx._generatedSubLink &&
            tx._generatedSubId
          ) {
            if (!db.link_tokens) db.link_tokens = {};
            let token = "";
            // Try finding existing token
            for (const [k, v] of Object.entries(db.link_tokens)) {
              if (v === tx._generatedSubLink) {
                token = k;
                break;
              }
            }
            if (!token) {
              token = Math.random().toString(36).substring(2, 10);
              db.link_tokens[token] = tx._generatedSubLink;
              writeSqliteDb(db);
            }

            replyMarkupObj = {
              inline_keyboard: [
                [
                  {
                    text: "🔗 لینک سابسکریپشن(همه ی کانفیگ ها)",
                    callback_data: `showlink_${token}`,
                  },
                ],
                [
                  {
                    text: "🔗 لینک‌های کانفیگ",
                    callback_data: `mysub_vless_${tx._generatedSubId}`,
                  },
                ],
                [{ text: cfg.btnTextGuides || "💡 آموزش ها", callback_data: "mm_btnGuides" }],
                [
                  {
                    text: "🏠 بازگشت به منوی اصلی",
                    callback_data: "btn_back_home",
                  },
                ],
              ],
            };
          }

          const sendOk = await sendTelegramMessage(botToken, tx.userId, messageTextForNotif, replyMarkupObj);
          if (sendOk) notifiedUser = true;

          // Also attach purchase success note if delivering exactly a newly built purchase config
          if (tx.type === "PLAN_PURCHASE" && tx._generatedSubLink) {
            setTimeout(() => {
              sendPurchaseSuccessNoteIfAnyServer(botToken, tx.userId, cfg);
            }, 1000);
          }
          // Notify Admin of successful delivery
          try {
            const ownerId = Number(cfg.ownerId || cfg.OWNER_ID || 0);
            if (ownerId > 0 && isBotNotificationEnabled(db, "notifyAdminPaymentSuccess", true)) {
              let adminDeliveryMsg = "";
              if (tx.type === "PLAN_PURCHASE" || isRenewTx) {
                adminDeliveryMsg = `✅ <b>گزارش تحویل کانفیگ به کاربر</b>\n\n` +
                  `👤 <b>کاربر:</b> <code>${tx.username || tx.userId}</code> (شناسه: <code>${tx.userId}</code>)\n` +
                  `💰 <b>مبلغ تراکنش:</b> <b>${Number(tx.amount || 0).toLocaleString()} تومان</b>\n` +
                  `📦 <b>نوع سفارش:</b> ${isRenewTx ? "تمدید اشتراک" : "خرید کانفیگ جدید"}\n` +
                  (tx._generatedSubLink ? `🔗 <b>لینک سابسکریپشن:</b>\n<code>${tx._generatedSubLink}</code>\n\n` : "\n") +
                  `🚀 <b>وضعیت:</b> کانفیگ با موفقیت به کاربر تحویل داده شد.`;
              } else {
                adminDeliveryMsg = `✅ <b>تایید افزایش موجودی کاربر</b>\n\n` +
                  `👤 <b>کاربر:</b> <code>${tx.username || tx.userId}</code> (شناسه: <code>${tx.userId}</code>)\n` +
                  `💰 <b>مبلغ افزوده شده:</b> <b>${Number(tx.amount || 0).toLocaleString()} تومان</b>\n` +
                  `💰 <b>موجودی جدید کاربر:</b> <b>${user ? Number(user.walletBalance).toLocaleString() : "0"} تومان</b>`;
              }
              await sendTelegramMessage(botToken, ownerId, adminDeliveryMsg);
            }
          } catch (admErr) {
            console.warn("Error notifying admin of delivery:", admErr);
          }
        }
      } catch (notifyErr) {
        console.warn("Error notifying user of approval:", notifyErr);
      }

      // Record persistent notification for user in miniapp
      if (!Array.isArray(db.user_notifications)) db.user_notifications = [];
      let miniappTitle = "🎉 رسید شما تایید شد!";
      let miniappMsg = "سرویس شما توسط مدیریت تایید و فعال گردید. می‌توانید اطلاعات و کانفیگ جدید را در بخش سرویس‌های من دریافت کنید.";

      if (isRenewTx) {
        miniappTitle = "🎉 تمدید اشتراک تایید شد!";
        miniappMsg = "درخواست تمدید سرویس شما توسط مدیریت تایید شد و ترافیک و زمان جدید به اشتراک شما اضافه گردید.";
      } else if (tx.type === "deposit" || (!tx.planId && tx.type !== "PLAN_PURCHASE")) {
        miniappTitle = "🎉 افزایش موجودی تایید شد!";
        miniappMsg = `درخواست افزایش موجودی شما به مبلغ ${Number(tx.amount || 0).toLocaleString("fa-IR")} تومان تایید و به کیف پول شما واریز گردید.`;
      }

      db.user_notifications.push({
        id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        userId: Number(tx.userId),
        title: miniappTitle,
        message: miniappMsg,
        type: "success",
        read: false,
        createdAt: new Date().toISOString()
      });

      writeSqliteDb(db);

      let successMessageText = "تراکنش تایید شد و موجودی کاربر افزایش یافت.";
      if (tx.type === "PLAN_PURCHASE" || isRenewTx) {
        successMessageText = "فیش تایید شد و کانفیگ با موفقیت به خریدار تحویل داده شد.";
      }

      res.json({
        success: true,
        notified: notifiedUser,
        userId: tx.userId,
        messageTextForNotif: messageTextForNotif,
        message: successMessageText,
      });
    } else {
      res
        .status(404)
        .json({ success: false, message: "Transaction not found." });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/transactions/reject", requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.body;
    const db = readSqliteDb();

    const tx = db.transactions.find((t) => t.id === id);
    if (tx) {
      tx.status = "rejected";

      if (!db.logs) db.logs = [];
      db.logs.push({
        id: Math.random().toString(36).substring(2, 9),
        date: new Date().toISOString(),
        userId: Number(tx.userId),
        username: tx.username || `user_${tx.userId}`,
        action: "رد شارژ",
        details: `رسید تراکنش به شناسه ${tx.id} و مبلغ ${Number(tx.amount).toLocaleString()} تومان توسط مدیر رد شد.`,
      });
      if (db.logs.length > 1000) {
        db.logs = db.logs.slice(-1000);
      }

      // Record persistent notification for user in miniapp
      if (!Array.isArray(db.user_notifications)) db.user_notifications = [];
      db.user_notifications.push({
        id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        userId: Number(tx.userId),
        title: "❌ رسید شما رد شد",
        message: `رسید تراکنش شما با شناسه ${tx.id} به مبلغ ${Number(tx.amount || 0).toLocaleString("fa-IR")} تومان توسط مدیریت بررسی و تایید نگردید.`,
        type: "error",
        read: false,
        createdAt: new Date().toISOString()
      });

      writeSqliteDb(db);

      // Try to notify the user via Telegram Bot API on reject
      try {
        const cfg = getSystemSettings(db);
        let botToken = (cfg.botToken && cfg.botToken.trim() !== "" && cfg.botToken !== "DUMMY_TOKEN")
          ? cfg.botToken.trim()
          : (cfg.BOT_TOKEN && cfg.BOT_TOKEN.trim() !== "" && cfg.BOT_TOKEN !== "DUMMY_TOKEN")
            ? cfg.BOT_TOKEN.trim()
            : (process.env.BOT_TOKEN || "").trim();

        if (botToken && botToken !== "DUMMY_TOKEN" && isBotNotificationEnabled(db, "notifyUserReceiptRejected", true)) {
          const messageText = `❌ <b>تراکنش شما پذیرفته نشد!</b>\n\nفیش ارسالی شما با شناسه <code>${tx.id}</code> توسط مدیریت بررسی و رد گردید.\n\n⚠️ علت رد تراکنش ممکن است ناخوانا بودن رسید، مغایرت مبلغ و یا تکراری بودن فیش باشد. لطفا در صورت بروز مشکل با پشتیبان ارتباط برقرار کنید.`;
          await sendTelegramMessage(botToken, tx.userId, messageText);
        }
      } catch (notifyErr) {
        console.warn("Error notifying user of rejection:", notifyErr);
      }
    }

    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/transactions/delete", requireAdminAuth, async (req, res) => {
  try {
    const { id } = req.body;
    const db = readSqliteDb();

    db.transactions = db.transactions.filter((t) => t.id !== id);
    writeSqliteDb(db);

    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/transactions/clear-history", requireAdminAuth, async (req, res) => {
  try {
    const db = readSqliteDb();
    db.transactions = [];
    writeSqliteDb(db);

    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Auto-create subscription key on 3x-ui panel directly
app.post("/api/subscription-keys/auto-create", requireAdminAuth, async (req, res) => {
  try {
    const { userId, clientName, trafficLimitGb, expiryDays, planName } =
      req.body;
    const db = readSqliteDb();
    const settings = getSystemSettings(db);

    const panelLabel = settings.panelType === "dui" ? "پنل دالتون (D-UI)" : "پنل ۳x-ui";
    if (!settings.panelConnectionActive) {
      return res.status(400).json({
        success: false,
        error: `اتصال به ${panelLabel} در تنظیمات غیرفعال است.`,
      });
    }

    const durationDays = Number(expiryDays) || 30;
    const cleanClientName = (
      clientName || "user_" + Math.random().toString(36).substring(2, 7)
    )
      .trim()
      .replace(/\s+/g, "");

    const vpnResult = await addVpnClientApi(
      cleanClientName,
      Number(trafficLimitGb),
      durationDays,
      settings,
    );

    if (vpnResult.success && vpnResult.subLink) {
      const randomId = "SUB-" + Date.now() + "-" + Math.floor(Math.random() * 90000 + 10000);
      const expireDate = new Date(
        Date.now() + Number(expiryDays) * 24 * 60 * 60 * 1000,
      )
        .toISOString()
        .split("T")[0];

      const newSub = {
        id: randomId,
        userId: Number(userId),
        planId: "manual_" + Math.random().toString(36).substring(2, 8),
        planName: planName || `Manual Plan (${trafficLimitGb}GB)`,
        clientName: cleanClientName,
        clientUuid: vpnResult.clientUuid || "",
        subLink: vpnResult.subLink,
        expireDate: expireDate,
        trafficLimitGb: Number(trafficLimitGb),
        trafficUsedGb: 0,
        createdAtMs: Date.now(),
        status: "active" as const,
      };

      db.subscription_keys.push(newSub);

      const user = db.users.find((u) => u.userId === Number(userId));
      if (user) {
        user.activePlansCount = db.subscription_keys.filter(
          (k) => k.userId === Number(userId) && k.status === "active",
        ).length;
      }

      writeSqliteDb(db);
      return res.json({
        success: true,
        subKey: newSub,
        subscriptionKeys: db.subscription_keys,
        users: db.users,
      });
    } else {
      return res.status(400).json({
        success: false,
        error:
          "خطا در برقراری ارتباط با ۳x-ui: " +
          (vpnResult.error || "خطای نامشخص"),
      });
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 5. Subscription Keys operations
app.post("/api/subscription-keys", requireAdminAuth, async (req, res) => {
  try {
    const {
      id,
      userId,
      planId,
      planName,
      clientUuid,
      subLink,
      expireDate,
      trafficLimitGb,
      trafficUsedGb,
      status,
    } = req.body;
    const db = readSqliteDb();

    const nextSub = {
      id,
      userId: Number(userId),
      planId,
      planName,
      clientUuid: clientUuid || "",
      subLink,
      expireDate,
      trafficLimitGb: Number(trafficLimitGb),
      trafficUsedGb: Number(trafficUsedGb || 0),
      status: status || "active",
    };

    const idx = db.subscription_keys.findIndex((s) => s.id === id);
    if (idx >= 0) {
      db.subscription_keys[idx] = nextSub;
    } else {
      db.subscription_keys.push(nextSub);
    }

    // Recalculate user subscription count
    const user = db.users.find((u) => u.userId === Number(userId));
    if (user) {
      user.activePlansCount = db.subscription_keys.filter(
        (k) => k.userId === Number(userId) && k.status === "active",
      ).length;
    }

    writeSqliteDb(db);
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/subscription-keys/delete", async (req, res) => {
  try {
    const { id, userId, clientName, clientUuid, serverId } = req.body;
    const db = readSqliteDb();

    const searchId = id !== undefined && id !== null ? String(id).trim() : "";
    const keyToDelete = (db.subscription_keys || []).find((k: any) => {
      if (!k) return false;
      if (searchId && String(k.id).trim() === searchId) return true;
      if (searchId && k.clientUuid && String(k.clientUuid).trim() === searchId) return true;
      if (searchId && k.uuid && String(k.uuid).trim() === searchId) return true;
      if (clientName && (k.clientName === clientName || k.email === clientName)) return true;
      if (clientUuid && (k.clientUuid === clientUuid || k.uuid === clientUuid)) return true;
      return false;
    });

    let liveUsedGb = 0;
    const clientIdentifier = keyToDelete?.clientName || keyToDelete?.email || keyToDelete?.planName || clientName || "";
    const effectiveUuid = keyToDelete?.clientUuid || keyToDelete?.uuid || clientUuid || (searchId.includes("-") ? searchId : "");
    const effectiveServerId = keyToDelete?.serverId || serverId;

    if (clientIdentifier || effectiveUuid) {
      try {
        const delRes: any = await deleteVpnClientApi(clientIdentifier, effectiveUuid, effectiveServerId);
        if (delRes && typeof delRes === "object" && typeof delRes.usedGb === "number") {
          liveUsedGb = delRes.usedGb;
        }
        if (!delRes || !delRes.success) {
          console.warn(`[Delete VPN Client] Notice for ${clientIdentifier || effectiveUuid}: ${delRes?.error || 'Panel removal logged'}`);
        }
      } catch (err) {
        console.warn("[Delete VPN Client Error]:", err);
      }
    }

    if (keyToDelete) {
      const dbUsedGb = Number(keyToDelete.trafficUsedGb || 0);
      const effectiveUsedGb = Math.max(dbUsedGb, liveUsedGb);

      // If this key belongs to a colleague account
      const colAcc = db.colleague_accounts?.find(
        (a: any) => isKeyForColleague(keyToDelete, a)
      );
      if (colAcc) {
        if (effectiveUsedGb > 0.0000001) {
          colAcc.deletedTrafficGb =
            (colAcc.deletedTrafficGb || 0) +
            Number(keyToDelete.trafficLimitGb || 0);
          colAcc.deletedRealTrafficGb =
            (colAcc.deletedRealTrafficGb || 0) + effectiveUsedGb;
        }

        // Recalculate colleague account usedTrafficGb immediately
        const remainingColKeys = db.subscription_keys.filter(
          (k: any) => String(k.id).trim() !== searchId && isKeyForColleague(k, colAcc)
        );
        const sumActiveLimits = remainingColKeys.reduce(
          (sum: number, k: any) => sum + Number(k.trafficLimitGb || 0), 0
        );
        const sumActiveUsed = remainingColKeys.reduce(
          (sum: number, k: any) => sum + Number(k.trafficUsedGb || 0), 0
        );
        colAcc.usedTrafficGb = Number((sumActiveLimits + (colAcc.deletedTrafficGb || 0)).toFixed(2));
        colAcc.realUsedTrafficGb = Number((sumActiveUsed + (colAcc.deletedRealTrafficGb || 0)).toFixed(2));
      }
    }

    // Filter key out of db.subscription_keys safely
    db.subscription_keys = (db.subscription_keys || []).filter((k: any) => {
      if (!k) return false;
      if (searchId && String(k.id).trim() === searchId) return false;
      if (keyToDelete && k.id === keyToDelete.id) return false;
      if (clientName && (k.clientName === clientName || k.email === clientName)) return false;
      return true;
    });

    const targetUserId = userId || keyToDelete?.userId;
    if (targetUserId) {
      const user = (db.users || []).find((u: any) => Number(u.userId) === Number(targetUserId));
      if (user) {
        user.activePlansCount = db.subscription_keys.filter(
          (k: any) => Number(k.userId) === Number(targetUserId) && k.status === "active",
        ).length;
        if (Array.isArray(user.configs)) {
          user.configs = user.configs.filter((c: any) => String(c.id || c.uuid || c.clientName) !== searchId);
        }
      }
    }

    try {
      const settings = getSystemSettings(db);
      const srvDisplay = getServerDisplayForNotification(effectiveServerId, settings, db);
      const userInfoText = getUserDisplayInfo(targetUserId, clientIdentifier, db);
      const uuidText = effectiveUuid || "نامشخص";
      const deleteMsg =
        `🗑️ <b>[اعلان حذف کانفیگ]</b>\n\n` +
        `${userInfoText}\n` +
        `🌐 <b>سرور:</b> ${srvDisplay}\n` +
        `🔑 <b>شناسه (UUID):</b> <code>${uuidText}</code>\n` +
        `⏱ <b>زمان:</b> ${formatShamsiDate(new Date(), true)}`;
      sendAdminNotification(deleteMsg, settings).catch(() => {});
    } catch (e) {
      console.error("[delete key notify error]", e);
    }

    writeSqliteDb(db);
    res.json({
      success: true,
      subscriptionKeys: db.subscription_keys,
      users: db.users,
      colleagueAccounts: db.colleague_accounts
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/subscription-keys/delete-expired", requireAdminAuth, async (req, res) => {
  try {
    const db = readSqliteDb();
    const nowSec = Math.floor(Date.now() / 1000);
    const nowMs = Date.now();

    const expiredKeys = (db.subscription_keys || []).filter((k: any) => {
      if (k.status === "expired") return true;
      if (k.expireTimestamp && Number(k.expireTimestamp) > 0 && Number(k.expireTimestamp) < nowSec) return true;
      if (k.expireDate) {
        const expMs = new Date(k.expireDate).getTime();
        if (!isNaN(expMs) && expMs < nowMs) return true;
      }
      const limitGb = Number(k.trafficLimitGb || 0);
      const usedGb = Number(k.trafficUsedGb || 0);
      if (limitGb > 0 && usedGb >= limitGb) return true;
      return false;
    });

    if (expiredKeys.length === 0) {
      return res.json({
        success: true,
        count: 0,
        message: "هیچ کانفیگ منقضی‌شده‌ای یافت نشد.",
        subscriptionKeys: db.subscription_keys,
        users: db.users,
        colleagueAccounts: db.colleague_accounts,
      });
    }

    let deletedCount = 0;
    const expiredIds = new Set(expiredKeys.map((k: any) => k.id));

    // Delete clients from panels in parallel batches of 10 for fast completion
    const batchSize = 10;
    for (let i = 0; i < expiredKeys.length; i += batchSize) {
      const batch = expiredKeys.slice(i, i + batchSize);
      await Promise.allSettled(
        batch.map(async (key: any) => {
          const clientIdentifier = key.clientName || key.planName || key.email || key.remark;
          if (clientIdentifier) {
            try {
              await Promise.race([
                deleteVpnClientApi(clientIdentifier, key.serverId),
                new Promise((resolve) => setTimeout(resolve, 5000))
              ]);
            } catch (e) {
              console.warn("[Delete Expired] Error deleting VPN client from panel:", e);
            }
          }

          // Handle colleague accounting if applicable
          const colAcc = db.colleague_accounts?.find(
            (a: any) => isKeyForColleague(key, a)
          );
          if (colAcc) {
            const liveUsedGb = Number(key.trafficUsedGb || 0);
            if (liveUsedGb > 0.0000001) {
              colAcc.deletedTrafficGb = (colAcc.deletedTrafficGb || 0) + Number(key.trafficLimitGb || 0);
              colAcc.deletedRealTrafficGb = (colAcc.deletedRealTrafficGb || 0) + liveUsedGb;
            }
          }
          deletedCount++;
        })
      );
    }

    // Filter out expired keys from sqlite db
    db.subscription_keys = (db.subscription_keys || []).filter((k: any) => !expiredIds.has(k.id));

    // Update activePlansCount for all users
    for (const user of (db.users || [])) {
      user.activePlansCount = (db.subscription_keys || []).filter(
        (k: any) => k.userId === Number(user.userId) && k.status === "active"
      ).length;
    }

    // Recalculate colleague account stats
    if (db.colleague_accounts) {
      for (const colAcc of db.colleague_accounts) {
        const remainingColKeys = (db.subscription_keys || []).filter(
          (k: any) => isKeyForColleague(k, colAcc)
        );
        const sumActiveLimits = remainingColKeys.reduce(
          (sum: number, k: any) => sum + Number(k.trafficLimitGb || 0), 0
        );
        const sumActiveUsed = remainingColKeys.reduce(
          (sum: number, k: any) => sum + Number(k.trafficUsedGb || 0), 0
        );
        colAcc.usedTrafficGb = Number((sumActiveLimits + (colAcc.deletedTrafficGb || 0)).toFixed(2));
        colAcc.realUsedTrafficGb = Number((sumActiveUsed + (colAcc.deletedRealTrafficGb || 0)).toFixed(2));
      }
    }

    // Log the action
    if (!db.logs) db.logs = [];
    db.logs.push({
      id: Math.random().toString(36).substring(2, 9),
      date: new Date().toISOString(),
      action: "حذف کانفیگ‌های منقضی‌شده",
      details: `تعداد ${deletedCount} کانفیگ منقضی‌شده از پنل‌ها، داشبورد و ربات تلگرام پاک شدند.`,
    });

    writeSqliteDb(db);

    return res.json({
      success: true,
      count: deletedCount,
      subscriptionKeys: db.subscription_keys,
      users: db.users,
      colleagueAccounts: db.colleague_accounts,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/subscription-keys/renew", async (req, res) => {
  try {
    const { id, addGb, addDays, userId, paymentMethod = "wallet", receiptImage = "", isColleague, colleagueAccountId } = req.body;
    const db = readSqliteDb();

    const key = (db.subscription_keys || []).find((k: any) => String(k.id) === String(id) || String(k.clientUuid) === String(id));
    if (!key) {
      return res.status(404).json({ success: false, error: "اشتراک مورد نظر یافت نشد." });
    }

    const settings = getSystemSettings(db);
    const clientName = key.clientName || key.clientEmail || key.planName || "";

    const numGb = Math.max(0, Number(addGb) || 0);
    const numDays = Math.max(0, Number(addDays) || 0);

    if (numGb === 0 && numDays === 0) {
      return res.status(400).json({ success: false, error: "حجم یا مدت زمان تمدید باید مشخص شود." });
    }

    const effectiveUserId = userId || key.userId;

    // Check if this key belongs to a colleague account
    let colAcc: any = null;
    if (colleagueAccountId) {
      colAcc = (db.colleague_accounts || []).find((a: any) => String(a.id) === String(colleagueAccountId));
    }
    if (!colAcc && key.colleagueAccountId) {
      colAcc = (db.colleague_accounts || []).find((a: any) => String(a.id) === String(key.colleagueAccountId));
    }
    if (!colAcc) {
      colAcc = (db.colleague_accounts || []).find((a: any) => isKeyForColleague(key, a));
    }
    if (!colAcc && isColleague && effectiveUserId) {
      colAcc = (db.colleague_accounts || []).find((a: any) => Number(a.userId) === Number(effectiveUserId));
    }

    // =========================================================================
    // 1. COLLEAGUE CONFIG RENEWAL (DEDUCT FROM COLLEAGUE TRAFFIC QUOTA DIRECTLY)
    // =========================================================================
    if (colAcc) {
      const colKeys = (db.subscription_keys || []).filter((k: any) => isKeyForColleague(k, colAcc));
      const totalPkgGb = Number(colAcc.trafficGb || 0);
      const sumActiveLimits = colKeys.reduce((sum: number, k: any) => sum + Number(k.trafficLimitGb || 0), 0);
      const allocatedGb = Number((sumActiveLimits + (colAcc.deletedTrafficGb || 0)).toFixed(2));
      const remainingGb = Math.max(0, totalPkgGb - allocatedGb);

      if (numGb > remainingGb) {
        return res.status(400).json({
          success: false,
          error: `حجم درخواستی (${numGb} GB) بیشتر از سهمیه باقیمانده بسته همکاری شما (${remainingGb.toFixed(1)} GB) است. لطفاً ابتدا پلن همکاری خود را شارژ یا تمدید نمایید.`
        });
      }

      // Calculate new expiration date
      let expDt: Date;
      try {
        expDt = new Date(key.expireDate);
        if (isNaN(expDt.getTime()) || expDt.getTime() < Date.now()) {
          expDt = new Date();
        }
      } catch {
        expDt = new Date();
      }

      expDt.setDate(expDt.getDate() + numDays);
      const new_expire_date_str = expDt.toISOString().split("T")[0];
      const new_limit_gb = Number(key.trafficLimitGb || 0) + numGb;

      // Extend on VPN panel
      const addResult = await extendVpnClientApi(
        clientName,
        numGb,
        numDays,
        key.clientUuid,
        key.serverId,
        key.subLink
      );

      if (!addResult.success) {
        console.warn("[Colleague Renew API] Client not found on panel during extend, recreating client on panel:", addResult.error);
        const vpnResult = await addVpnClientApi(
          clientName,
          numGb,
          numDays,
          settings,
          undefined,
          key.serverId
        );
        if (vpnResult.success && vpnResult.subLink) {
          key.clientUuid = vpnResult.clientUuid || key.clientUuid;
          key.subLink = vpnResult.subLink;
          key.vlessConfigs = vpnResult.vlessConfigs || [];
          key.vlessLinks = vpnResult.vlessLinks || [];
          key.trafficLimitGb = numGb;
          key.trafficUsedGb = 0;
        }
      }

      // Update locally
      key.expireDate = new_expire_date_str;
      key.trafficLimitGb = new_limit_gb;
      key.status = "active";
      key.disabled = false;
      key.colleagueAccountId = colAcc.id;

      // Recalculate Colleague Account usedTrafficGb
      const updatedColKeys = (db.subscription_keys || []).filter((k: any) => isKeyForColleague(k, colAcc));
      const newSumActiveLimits = updatedColKeys.reduce((sum: number, k: any) => sum + Number(k.trafficLimitGb || 0), 0);
      colAcc.usedTrafficGb = Number((newSumActiveLimits + (colAcc.deletedTrafficGb || 0)).toFixed(2));

      writeSqliteDb(db);

      const srvName = getServerRemark(key.serverId, settings, db, key.subLink);
      const srvDisplay = `👥 ${srvName}`;
      const shamsiExpDate = formatShamsiDate(expDt, false);

      try {
        const adminMsg =
          `🔄 <b>[تمدید کانفیگ همکار - کسر از سهمیه]</b>\n\n` +
          `👤 <b>همکار:</b> ${colAcc.prefix || colAcc.username}\n` +
          `📦 <b>سرویس:</b> <code>${clientName}</code>\n` +
          `🌐 <b>سرور:</b> ${srvDisplay}\n` +
          `➕ <b>افزایش حجم:</b> +${numGb} GB (مجموع: ${new_limit_gb} GB)\n` +
          `➕ <b>افزایش مدت:</b> +${numDays} روز\n` +
          `📅 <b>تاریخ انقضای جدید:</b> ${shamsiExpDate}\n` +
          `📊 <b>سهمیه باقیمانده همکار:</b> ${(remainingGb - numGb).toFixed(1)} GB\n` +
          `⏱ <b>زمان:</b> ${formatShamsiDate(new Date(), true)}`;
        sendAdminNotification(adminMsg, settings).catch(() => {});
      } catch (e) {}

      return res.json({
        success: true,
        isColleagueRenew: true,
        remainingTrafficGb: Math.max(0, remainingGb - numGb),
        message: `کانفیگ با موفقیت تمدید شد و ${numGb} گیگابایت از سهمیه بسته همکاری کسر گردید.`,
        key,
        colleagueAccount: colAcc,
      });
    }

    // =========================================================================
    // 2. REGULAR USER CONFIG RENEWAL (WALLET OR CARD-TO-CARD PAYMENT)
    // =========================================================================
    // Calculate price using custom pricing configured in the bot/panel
    const pricing = calculateCustomPlanPrice(numGb, numDays, key.serverId, settings);
    const renewCost = pricing.price;

    const user = (db.users || []).find((u: any) => Number(u.userId) === Number(effectiveUserId) || Number(u.id) === Number(effectiveUserId));

    const ownerId = Number(settings.ownerId || settings.adminId || 0);
    const isOwnerOrAdmin = effectiveUserId && (Number(effectiveUserId) === ownerId || (settings.adminIds || []).map(Number).includes(Number(effectiveUserId)));

    // Handle Card-to-Card Receipt Renewal
    if (!isOwnerOrAdmin && paymentMethod === "card_to_card") {
      if (!receiptImage || !String(receiptImage).trim()) {
        return res.status(400).json({ success: false, error: "تصویر رسید واریز الزامی است." });
      }

      const txId = `tx_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
      const newTx: any = {
        id: txId,
        userId: Number(effectiveUserId),
        username: user?.username || `user_${effectiveUserId}`,
        type: "renew",
        planId: "custom_renew",
        clientName: String(key.id || key.clientUuid),
        customGb: numGb,
        customDays: numDays,
        amount: renewCost,
        status: "pending",
        receiptImage: receiptImage,
        description: `درخواست تمدید کانفیگ ${clientName} (+${numGb} GB, +${numDays} روز)`,
        createdAt: new Date().toISOString(),
        pendingPurchase: {
          type: "renew",
          isRenew: true,
          subId: String(key.id),
          clientUuid: key.clientUuid,
          clientName: key.clientName,
          serverId: key.serverId,
          customGb: numGb,
          customDays: numDays,
          cost: renewCost,
        },
      };

      if (!Array.isArray(db.transactions)) db.transactions = [];
      db.transactions.push(newTx);
      writeSqliteDb(db);

      // Instant notification to admins via Telegram
      notifyAdminsOnNewReceipt(newTx, db, settings).catch(() => {});

      return res.json({
        success: true,
        pendingReceipt: true,
        message: "رسید تمدید شما با موفقیت ثبت شد و پس از تایید مدیریت، سرویس شما تمدید و فعال می‌گردد.",
        txId,
      });
    }

    // Wallet Payment
    if (!isOwnerOrAdmin && user && renewCost > 0) {
      const currentBal = Number(user.walletBalance || user.balance || 0);
      if (currentBal < renewCost) {
        return res.status(400).json({
          success: false,
          error: `موجودی کیف پول شما (${currentBal.toLocaleString("fa-IR")} تومان) برای تمدید این اشتراک (${renewCost.toLocaleString("fa-IR")} تومان) کافی نیست. لطفاً ابتدا کیف پول خود را شارژ نمایید.`
        });
      }
      user.walletBalance = Math.max(0, currentBal - renewCost);

      // Record transaction
      if (!Array.isArray(db.transactions)) db.transactions = [];
      db.transactions.push({
        id: `tx_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        userId: Number(effectiveUserId),
        type: "renew",
        amount: renewCost,
        status: "approved",
        description: `تمدید اشتراک ${clientName} (+${numGb} GB, +${numDays} روز)`,
        createdAt: new Date().toISOString()
      });
    }

    // Calculate new expiration date
    let expDt: Date;
    try {
      expDt = new Date(key.expireDate);
      if (isNaN(expDt.getTime()) || expDt.getTime() < Date.now()) {
        expDt = new Date();
      }
    } catch {
      expDt = new Date();
    }

    expDt.setDate(expDt.getDate() + numDays);
    const new_expire_date_str = expDt.toISOString().split("T")[0];
    const new_limit_gb = Number(key.trafficLimitGb || 0) + numGb;

    const addResult = await extendVpnClientApi(
      clientName,
      numGb,
      numDays,
      key.clientUuid,
      key.serverId,
      key.subLink
    );

    if (!addResult.success) {
      console.warn("[Renew API] Client not found on panel during extend, recreating client on panel:", addResult.error);
      const vpnResult = await addVpnClientApi(
        clientName,
        numGb,
        numDays,
        settings,
        undefined,
        key.serverId
      );
      if (vpnResult.success && vpnResult.subLink) {
        key.clientUuid = vpnResult.clientUuid || key.clientUuid;
        key.subLink = vpnResult.subLink;
        key.vlessConfigs = vpnResult.vlessConfigs || [];
        key.vlessLinks = vpnResult.vlessLinks || [];
        key.trafficLimitGb = numGb;
        key.trafficUsedGb = 0;
      }
    }

    // Update locally
    key.expireDate = new_expire_date_str;
    key.trafficLimitGb = new_limit_gb;
    key.status = "active";
    key.disabled = false;

    // Re-enable in users if count updated
    if (user) {
      user.activePlansCount = (db.subscription_keys || []).filter(
        (k: any) => Number(k.userId) === Number(user.userId) && k.status === "active" && !k.disabled
      ).length;
      if (Array.isArray(user.configs)) {
        const c = user.configs.find((cfg: any) => String(cfg.id) === String(key.id) || String(cfg.uuid) === String(key.clientUuid));
        if (c) {
          c.expireDate = key.expireDate;
          c.trafficLimitGb = key.trafficLimitGb;
          c.status = "active";
          c.disabled = false;
        }
      }
    }

    try {
      const srvName = getServerRemark(key.serverId, settings, db, key.subLink);
      const activeServers = getActiveServers(settings);
      const srvObj = activeServers.find((s: any) => String(s.id) === String(key.serverId));
      const srvFlag = srvObj?.flag || (srvObj?.isColleague ? "👥" : "🌐");
      const srvDisplay = `${srvFlag} ${srvName}`;
      const shamsiExpDate = formatShamsiDate(expDt, false);
      const userInfoText = getUserDisplayInfo(key.userId, clientName, db);
      const renewMsg =
        `🔄 <b>[اعلان تمدید کانفیگ]</b>\n\n` +
        `${userInfoText}\n` +
        `🌐 <b>سرور:</b> ${srvDisplay}\n` +
        `➕ <b>افزایش حجم:</b> +${numGb} GB (مجموع: ${new_limit_gb} GB)\n` +
        `➕ <b>افزایش مدت:</b> +${numDays} روز\n` +
        `📅 <b>تاریخ انقضای جدید:</b> ${shamsiExpDate}\n` +
        `💰 <b>مبلغ تمدید:</b> ${renewCost.toLocaleString("fa-IR")} تومان\n` +
        `⏱ <b>زمان:</b> ${formatShamsiDate(new Date(), true)}`;
      sendAdminNotification(renewMsg, settings).catch(() => {});
    } catch (e) {
      console.error("[renew key notify error]", e);
    }

    writeSqliteDb(db);

    // Notify user on Telegram
    const effectiveBotToken = settings.botToken || settings.telegramBotToken || process.env.BOT_TOKEN;
    if (key.userId && effectiveBotToken && effectiveBotToken !== "DUMMY_TOKEN") {
      const srvName = getServerRemark(key.serverId, settings, db, key.subLink);
      const activeServers = getActiveServers(settings);
      const srvObj = activeServers.find((s: any) => String(s.id) === String(key.serverId));
      const srvFlag = srvObj?.flag || (srvObj?.isColleague ? "👥" : "🌐");
      const srvDisplay = `${srvFlag} ${srvName}`;
      const shamsiExpDate = formatShamsiDate(expDt, false);

      const renewUserMsg =
        `🎉 <b>اشتراک شما با موفقیت تمدید شد</b>\n\n` +
        `👤 <b>سرویس:</b> <code>${clientName}</code>\n` +
        `🌐 <b>سرور:</b> ${srvDisplay}\n` +
        `➕ <b>افزایش حجم:</b> +${numGb} گیگابایت (مجموع: ${new_limit_gb} GB)\n` +
        `➕ <b>افزایش مدت:</b> +${numDays} روز\n` +
        `📅 <b>تاریخ انقضای جدید:</b> <b>${shamsiExpDate}</b>\n` +
        `💰 <b>مبلغ:</b> ${renewCost.toLocaleString("fa-IR")} تومان\n\n` +
        `🔗 <b>لینک سابسکریپشن:</b>\n<code>${key.subLink || ""}</code>`;

      let replyMarkupObj: any = undefined;
      if (key.subLink) {
        replyMarkupObj = {
          inline_keyboard: [
            [{ text: "🔗 لینک‌های کانفیگ", callback_data: `mysub_vless_${key.id}` }],
            [{ text: settings.btnTextGuides || "💡 آموزش ها", callback_data: "mm_btnGuides" }],
            [{ text: "🏠 بازگشت به منوی اصلی", callback_data: "btn_back_home" }]
          ]
        };
      }
      if (isBotNotificationEnabled(db, "notifyUserRenewSuccess", true)) {
        sendTelegramMessage(effectiveBotToken, key.userId, renewUserMsg, replyMarkupObj).catch(() => {});
      }
    }

    res.json({ success: true, key, userBalance: user ? user.walletBalance : undefined, cost: renewCost });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/subscription-keys/toggle", async (req, res) => {
  try {
    const { id, status, clientUuid, clientName, serverId, subLink } = req.body;
    const db = readSqliteDb();

    let keyToToggle = (db.subscription_keys || []).find((k: any) =>
      String(k.id) === String(id) ||
      String(k.clientUuid) === String(id) ||
      (clientUuid && String(k.clientUuid) === String(clientUuid)) ||
      (clientName && (k.clientName === clientName || k.clientEmail === clientName))
    );

    // If still not found, search in all users' configs
    if (!keyToToggle) {
      for (const u of db.users || []) {
        if (Array.isArray(u.configs)) {
          const matchedCfg = u.configs.find((c: any) =>
            String(c.id) === String(id) ||
            String(c.uuid) === String(id) ||
            (clientUuid && String(c.uuid) === String(clientUuid)) ||
            (clientName && (c.name === clientName || c.email === clientName))
          );
          if (matchedCfg) {
            keyToToggle = {
              id: matchedCfg.id || id,
              userId: u.userId,
              clientUuid: matchedCfg.uuid || clientUuid || id,
              clientName: matchedCfg.name || clientName || "",
              clientEmail: matchedCfg.email || matchedCfg.name || clientName || "",
              serverId: matchedCfg.serverId || serverId,
              subLink: matchedCfg.subLink || subLink,
              planName: matchedCfg.planName || "اشتراک اختصاصی",
              status: matchedCfg.status || "active",
              disabled: matchedCfg.disabled || false,
            };
            if (!Array.isArray(db.subscription_keys)) db.subscription_keys = [];
            db.subscription_keys.push(keyToToggle);
            break;
          }
        }
      }
    }

    const newStatus = status === "active" ? "active" : "suspended";
    const targetUuid = keyToToggle?.clientUuid || clientUuid || (id && String(id).includes("-") ? id : undefined);
    const targetServerId = keyToToggle?.serverId || serverId;
    const targetSubLink = keyToToggle?.subLink || subLink;
    const clientIdentifier = keyToToggle?.clientName || keyToToggle?.clientEmail || clientName || keyToToggle?.planName || "";

    const vpnResult = await toggleVpnClientApi(
      clientIdentifier,
      newStatus === "active",
      targetUuid,
      targetServerId,
      targetSubLink
    );
    if (!vpnResult.success) {
      console.warn(
        "[XUI Toggle] Failed to sync status with panel:",
        vpnResult.error,
      );
    }

    if (keyToToggle) {
      keyToToggle.status = newStatus;
      keyToToggle.disabled = newStatus !== "active";
    }

    // Update user active plans count and configs list
    const userIdToFind = keyToToggle?.userId;
    const user = (db.users || []).find((u: any) =>
      (userIdToFind && Number(u.userId) === Number(userIdToFind)) ||
      (Array.isArray(u.configs) && u.configs.some((cfg: any) => String(cfg.id) === String(id) || String(cfg.uuid) === String(targetUuid)))
    );
    if (user) {
      user.activePlansCount = (db.subscription_keys || []).filter(
        (k: any) => Number(k.userId) === Number(user.userId) && k.status === "active" && !k.disabled,
      ).length;
      if (Array.isArray(user.configs)) {
        const c = user.configs.find((cfg: any) =>
          String(cfg.id) === String(id) ||
          String(cfg.uuid) === String(id) ||
          (targetUuid && String(cfg.uuid) === String(targetUuid))
        );
        if (c) {
          c.status = newStatus;
          c.disabled = newStatus !== "active";
        }
      }
    }

    try {
      const settings = getSystemSettings(db);
      const srvDisplay = getServerDisplayForNotification(keyToToggle.serverId, settings, db, targetSubLink);
      const userInfoText = getUserDisplayInfo(keyToToggle.userId, clientIdentifier, db);
      const statusIcon = newStatus === "active" ? "🟢" : "🔴";
      const statusTextFa = newStatus === "active" ? "فعال‌سازی" : "غیرفعال‌سازی (تعلیق)";
      const toggleMsg =
        `${statusIcon} <b>[اعلان تغییر وضعیت کانفیگ]</b>\n\n` +
        `${userInfoText}\n` +
        `🌐 <b>سرور:</b> ${srvDisplay}\n` +
        `⚡ <b>وضعیت جدید:</b> ${statusTextFa}\n` +
        `⏱ <b>زمان:</b> ${formatShamsiDate(new Date(), true)}`;
      sendAdminNotification(toggleMsg, settings).catch(() => {});
    } catch (e) {
      console.error("[toggle key notify error]", e);
    }

    writeSqliteDb(db);

    const settings = getSystemSettings(db);
    if (keyToToggle.userId && settings.botToken && isBotNotificationEnabled(db, "notifyUserServiceToggle", true)) {
      const toggleMsg = newStatus === "active"
        ? `🟢 <b>اشتراک شما مجدداً فعال شد</b>\n\n📦 <b>پلن:</b> ${keyToToggle.planName || "اشتراک اختصاصی"}\nاتصال شما روی سرور برقرار است.`
        : `⏸ <b>اشتراک شما موقتاً به حالت تعلیق درآمد</b>\n\n📦 <b>پلن:</b> ${keyToToggle.planName || "اشتراک اختصاصی"}\nدسترسی این کانفیگ موقتاً قطع شد.`;
      sendTelegramMessage(settings.botToken, keyToToggle.userId, toggleMsg).catch(() => {});
    }

    res.json({ success: true, status: newStatus, key: keyToToggle });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Real-time link fetcher & synchronizer for individual subscriptions (MiniApp & Dashboard)
const handleFetchSubscriptionLinks = async (req: any, res: any) => {
  try {
    const { keyId, clientName, clientUuid, serverId, subLink, forceRefresh } = req.body;
    const db = readSqliteDb();
    const settings = getSystemSettings(db);

    let targetKey = (db.subscription_keys || []).find(
      (k: any) =>
        (keyId && String(k.id) === String(keyId)) ||
        (clientUuid && (String(k.clientUuid) === String(clientUuid) || String(k.uuid) === String(clientUuid))) ||
        (clientName && (String(k.clientName) === String(clientName) || String(k.email) === String(clientName))) ||
        (subLink && k.subLink && String(k.subLink).trim() === String(subLink).trim())
    );

    const cEmail = clientName || targetKey?.clientName || targetKey?.clientEmail || targetKey?.email || "";
    const cUuid = clientUuid || targetKey?.clientUuid || targetKey?.uuid || "";
    const sId = serverId || targetKey?.serverId || "";
    const sLink = buildCorrectSubLinkForClient(targetKey || subLink, sId, settings, db);

    const liveData = await fetchRealClientLinks(cEmail, cUuid, sId, sLink, Boolean(forceRefresh));

    if (targetKey) {
      targetKey.subLink = sLink;
      if (liveData.vlessConfigs.length > 0) {
        targetKey.vlessConfigs = liveData.vlessConfigs;
        targetKey.vlessLinks = liveData.vlessLinks;
      }
      writeSqliteDb(db);
    }

    res.json({
      success: true,
      vlessConfigs: liveData.vlessConfigs.length > 0 ? liveData.vlessConfigs : (targetKey?.vlessConfigs || []),
      vlessLinks: liveData.vlessLinks.length > 0 ? liveData.vlessLinks : (targetKey?.vlessLinks || []),
      subLink: sLink || targetKey?.subLink || "",
      inboundsCount: liveData.vlessConfigs.length
    });
  } catch (error: any) {
    console.error("[/api/miniapp/subscription-links error]:", error);
    res.status(500).json({ success: false, error: error.message });
  }
};

app.post("/api/miniapp/subscription-links", handleFetchSubscriptionLinks);
app.post("/api/subscription-keys/get-links", handleFetchSubscriptionLinks);

// 6. Custom menu buttons
app.post("/api/inbounds/toggle", requireAdminAuth, async (req, res) => {
  try {
    const { id, status } = req.body;
    const db = readSqliteDb();

    const ib = db.inbounds.find((i) => i.id === Number(id));
    if (ib) {
      ib.status = status;
      writeSqliteDb(db);
    }

    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// [EXTRACTED → src/routes/admin.ts] vpn-plans GET

// ==========================================
// TELEGRAM MINI-APP LIVE DATABASE API ROUTES
// ==========================================

// Helper to get all card details from both settings and panel_config
function getEffectiveCardDetails(settings: any) {
  let cardNumber = String(settings?.cardNumber || "").trim();
  let cardHolder = String(settings?.cardHolder || "").trim();
  let bankName = String(settings?.bankName || "").trim();
  let cardNumbers: any[] = [];

  if (Array.isArray(settings?.cardNumbers) && settings.cardNumbers.length > 0) {
    cardNumbers = settings.cardNumbers.filter((c: any) => c && (c.number || c.cardNumber));
    if (cardNumbers.length > 0) {
      const first = cardNumbers[0];
      if (!cardNumber) cardNumber = String(first.number || first.cardNumber || "").trim();
      if (!cardHolder) cardHolder = String(first.holder || first.cardHolder || "").trim();
      if (!bankName) bankName = String(first.bankName || "").trim();
    }
  }

  // Also inspect panel_config if available
  try {
    const pc = typeof settings?.panel_config === "string" ? JSON.parse(settings.panel_config) : (settings?.panel_config || {});
    if (!cardNumber && pc.cardNumber) cardNumber = String(pc.cardNumber).trim();
    if (!cardHolder && pc.cardHolder) cardHolder = String(pc.cardHolder).trim();
    if (!bankName && pc.bankName) bankName = String(pc.bankName).trim();
    if (cardNumbers.length === 0 && Array.isArray(pc.cardNumbers) && pc.cardNumbers.length > 0) {
      cardNumbers = pc.cardNumbers.filter((c: any) => c && (c.number || c.cardNumber));
      if (cardNumbers.length > 0) {
        const first = cardNumbers[0];
        if (!cardNumber) cardNumber = String(first.number || first.cardNumber || "").trim();
        if (!cardHolder) cardHolder = String(first.holder || first.cardHolder || "").trim();
        if (!bankName) bankName = String(first.bankName || "").trim();
      }
    }
  } catch (e) {}

  if (cardNumbers.length === 0 && cardNumber) {
    cardNumbers = [{ number: cardNumber, holder: cardHolder, bankName }];
  }

  return { cardNumber, cardHolder, bankName, cardNumbers };
}

// Helper to send photo directly to Telegram chat using bot API (supports base64 and URLs)
async function sendTelegramPhoto(
  botToken: string,
  chatId: string | number,
  photo: string,
  caption: string,
  replyMarkup?: any
) {
  if (!botToken || botToken === "DUMMY_TOKEN") return false;
  const effectiveToken = (botToken && botToken.trim() !== "" && botToken !== "DUMMY_TOKEN")
    ? botToken.trim()
    : (process.env.BOT_TOKEN || "").trim();
  if (!effectiveToken || effectiveToken === "DUMMY_TOKEN") return false;

  const fetchRef = globalThis.fetch || fetch;

  try {
    if (photo && photo.startsWith("data:image/")) {
      const parts = photo.split(",");
      const mimeMatch = photo.match(/data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+).*?;base64/);
      const mime = mimeMatch ? mimeMatch[1] : "image/jpeg";
      const base64Data = parts[1] || "";
      const buffer = Buffer.from(base64Data, "base64");

      const formData = new FormData();
      formData.append("chat_id", String(chatId));
      const blob = new Blob([buffer], { type: mime });
      formData.append("photo", blob, "receipt.jpg");
      if (caption) formData.append("caption", caption);
      formData.append("parse_mode", "HTML");
      if (replyMarkup) formData.append("reply_markup", JSON.stringify(replyMarkup));

      const res = await fetchRef(`https://api.telegram.org/bot${effectiveToken}/sendPhoto`, {
        method: "POST",
        body: formData,
      });
      if (res.ok) return true;
    } else if (photo && (photo.startsWith("http://") || photo.startsWith("https://"))) {
      const body: any = {
        chat_id: chatId,
        photo: photo,
        caption: caption,
        parse_mode: "HTML",
      };
      if (replyMarkup) body.reply_markup = replyMarkup;

      const res = await fetchRef(`https://api.telegram.org/bot${effectiveToken}/sendPhoto`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (res.ok) return true;
    }
  } catch (err: any) {
    console.warn("[sendTelegramPhoto Error, falling back to sendMessage]:", err?.message);
  }

  return await sendTelegramMessage(botToken, chatId, caption, replyMarkup);
}

// Universal helper to resolve all Admin and Owner Telegram IDs
function getAdminTargetIds(settings: any): number[] {
  const adminTargets: number[] = [];
  const add = (uid: any) => {
    if (uid === undefined || uid === null) return;
    const num = Number(uid);
    if (num && !isNaN(num) && num > 0 && !adminTargets.includes(num)) {
      adminTargets.push(num);
    }
  };
  if (settings) {
    if (settings.ownerId) add(settings.ownerId);
    if (settings.owner_id) add(settings.owner_id);
    if (settings.ownerTelegramId) add(settings.ownerTelegramId);
    if (settings.ownerUserId) add(settings.ownerUserId);
    if (settings.superAdminId) add(settings.superAdminId);
    if (settings.adminId) add(settings.adminId);
    if (settings.admin_id) add(settings.admin_id);
    if (settings.telegramAdminId) add(settings.telegramAdminId);
    if (Array.isArray(settings.admins)) {
      for (const adm of settings.admins) {
        const uid = typeof adm === "object" && adm ? (adm.userId || adm.user_id || adm.id || adm.telegramId || adm.tgId) : adm;
        add(uid);
      }
    }
    if (Array.isArray(settings.adminIds)) {
      for (const a of settings.adminIds) add(a);
    } else if (typeof settings.adminIds === "string") {
      for (const a of settings.adminIds.split(",")) add(a.trim());
    }
  }
  if (process.env.OWNER_ID) add(process.env.OWNER_ID);
  if (process.env.ADMIN_USER_ID) add(process.env.ADMIN_USER_ID);
  if (process.env.TELEGRAM_ADMIN_ID) add(process.env.TELEGRAM_ADMIN_ID);
  return adminTargets;
}

// Universal role resolution for Telegram MiniApp and APIs
function checkUserRoleAndAdmin(
  tgId: number,
  tgUsername?: string,
  settings?: any,
  db?: any
): {
  isAdmin: boolean;
  isOwner: boolean;
  isSuperAdmin: boolean;
  role: "super_admin" | "admin" | "user";
  roleTitle: string;
} {
  const adminTargets = getAdminTargetIds(settings);
  const cleanUsername = (tgUsername || "").toLowerCase().replace(/^@/, "").trim();

  // Check if owner
  const ownerIds: number[] = [];
  const addOwner = (uid: any) => {
    if (uid === undefined || uid === null) return;
    const num = Number(uid);
    if (num && !isNaN(num) && num > 0 && !ownerIds.includes(num)) ownerIds.push(num);
  };
  if (settings) {
    if (settings.ownerId) addOwner(settings.ownerId);
    if (settings.owner_id) addOwner(settings.owner_id);
    if (settings.ownerTelegramId) addOwner(settings.ownerTelegramId);
    if (settings.ownerUserId) addOwner(settings.ownerUserId);
    if (settings.superAdminId) addOwner(settings.superAdminId);
  }
  if (process.env.OWNER_ID) addOwner(process.env.OWNER_ID);

  let isOwner = tgId > 0 && ownerIds.includes(tgId);
  let isSuperAdmin = isOwner;

  // Check owner by username
  const ownerUsernames: string[] = ["mdaltoon", "daltoon"];
  if (settings?.ownerUsername) ownerUsernames.push(String(settings.ownerUsername).toLowerCase().replace(/^@/, "").trim());
  if (settings?.adminUsername) ownerUsernames.push(String(settings.adminUsername).toLowerCase().replace(/^@/, "").trim());
  if (cleanUsername && ownerUsernames.some(ou => ou && (cleanUsername === ou || cleanUsername.toLowerCase() === ou.toLowerCase()))) {
    isOwner = true;
    isSuperAdmin = true;
  }

  // Check admins list
  let isAdmin = isOwner || (tgId > 0 && adminTargets.includes(tgId));

  if (Array.isArray(settings?.admins)) {
    for (const adm of settings.admins) {
      if (typeof adm === "object" && adm !== null) {
        const admUid = Number(adm.userId || adm.user_id || adm.id || adm.telegramId || adm.tgId);
        const admUname = String(adm.username || "").toLowerCase().replace(/^@/, "").trim();
        const matchesId = tgId > 0 && admUid === tgId;
        const matchesUname = cleanUsername && admUname && (cleanUsername === admUname);
        
        if (matchesId || matchesUname) {
          isAdmin = true;
          if (adm.role === "super_admin" || adm.role === "owner" || adm.isOwner || adm.isSuperAdmin) {
            isSuperAdmin = true;
            isOwner = true;
          }
        }
      }
    }
  }

  // Check in db.users
  if (db && Array.isArray(db.users)) {
    const dbUser = db.users.find((u: any) => 
      (tgId > 0 && (Number(u.userId) === tgId || Number(u.id) === tgId || Number(u.user_id) === tgId)) || 
      (cleanUsername && String(u.username || "").toLowerCase().replace(/^@/, "").trim() === cleanUsername)
    );
    if (dbUser) {
      if (dbUser.role === "owner" || dbUser.role === "super_admin" || dbUser.isOwner || dbUser.isSuperAdmin) {
        isOwner = true;
        isSuperAdmin = true;
        isAdmin = true;
      } else if (dbUser.role === "admin" || dbUser.isAdmin) {
        isAdmin = true;
      }
    }
  }

  const role: "super_admin" | "admin" | "user" = isSuperAdmin || isOwner ? "super_admin" : isAdmin ? "admin" : "user";
  const roleTitle = isSuperAdmin || isOwner ? "مدیر ارشد (سوپر ادمین)" : isAdmin ? "مدیر سیستم" : "کاربر عمومی";

  return { isAdmin, isOwner, isSuperAdmin, role, roleTitle };
}

// Check if a specific Bot PV notification toggle is enabled
function isBotNotificationEnabled(db: any, notifKey: string, defaultValue: boolean = true): boolean {
  try {
    const settings = getSystemSettings(db);
    if (settings && (settings as any)[notifKey] !== undefined) {
      return Boolean((settings as any)[notifKey]);
    }
    return defaultValue;
  } catch {
    return defaultValue;
  }
}

// Universal helper to send notification to all Admins and Owner
async function sendAdminNotification(messageText: string, settings: any, replyMarkup?: any) {
  try {
    const mainToken = settings?.botToken || settings?.telegramBotToken || process.env.BOT_TOKEN;
    const receiptToken = (settings?.receiptBotToken || settings?.receipt_bot_token || process.env.RECEIPT_BOT_TOKEN || "").trim();
    const primaryToken = (receiptToken && receiptToken !== "DUMMY_TOKEN") ? receiptToken : mainToken;

    if (!primaryToken || primaryToken === "DUMMY_TOKEN") return;
    const targets = getAdminTargetIds(settings);
    for (const targetId of targets) {
      try {
        await sendTelegramMessage(primaryToken, targetId, messageText, replyMarkup);
      } catch (err: any) {
        console.warn(`[Admin Notify Warning] for ${targetId} with primary token:`, err?.message);
        if (primaryToken !== mainToken && mainToken && mainToken !== "DUMMY_TOKEN") {
          try {
            await sendTelegramMessage(mainToken, targetId, messageText, replyMarkup);
          } catch (fallbackErr: any) {
            console.warn(`[Admin Notify Fallback Warning] for ${targetId}:`, fallbackErr?.message);
          }
        }
      }
    }
  } catch (e: any) {
    console.error("[sendAdminNotification Error]", e);
  }
}

// 1. Initial Aggregated Data for MiniApp (User, Plans, Servers, Categories, Configs, Settings)
// Helper to send instant notification to all bot admins on new receipt submission
async function notifyAdminsOnNewReceipt(tx: any, db: any, settings: any) {
  try {
    if (!isBotNotificationEnabled(db, "notifyAdminNewReceipt", true)) {
      return;
    }
    const mainToken = settings?.botToken || settings?.telegramBotToken || process.env.BOT_TOKEN;
    const receiptToken = (settings?.receiptBotToken || settings?.receipt_bot_token || process.env.RECEIPT_BOT_TOKEN || "").trim();
    const primaryToken = (receiptToken && receiptToken !== "DUMMY_TOKEN") ? receiptToken : mainToken;

    if (!primaryToken || primaryToken === "DUMMY_TOKEN") return;

    const adminTargets = getAdminTargetIds(settings);
    if (adminTargets.length === 0) return;

    const usernameDisplay = tx.username ? `@${tx.username.replace(/^@/, '')}` : `کاربر (${tx.userId})`;
    const serverId = tx.pendingPurchase?.serverId || tx.serverId;
    const serverRemark = getServerRemark(serverId, settings, db, tx.pendingPurchase?.subLink);
    const activeServers = getActiveServers(settings);
    const serverObj = activeServers.find((s: any) => String(s.id) === String(serverId));
    const srvFlag = serverObj?.flag || (serverObj?.isColleague ? "👥" : "🌐");
    const serverDisplay = `${srvFlag} ${serverRemark}`;

    const isRenew = tx.type === "renew" || tx.pendingPurchase?.type === "renew" || tx.pendingPurchase?.isRenew || tx.planId === "custom_renew";
    let typeDisplay = "";
    const configNameDisplay = tx.pendingPurchase?.clientUsername || tx.pendingPurchase?.clientName || tx.clientName || "";

    if (isRenew) {
      const renewGb = tx.pendingPurchase?.customGb || tx.customGb || 0;
      const renewDays = tx.pendingPurchase?.customDays || tx.customDays || 0;
      typeDisplay = `🔄 <b>تمدید اشتراک</b> (+${renewGb} گیگابایت / +${renewDays} روز)`;
    } else {
      typeDisplay = tx.pendingPurchase?.planName || tx.description || "خرید اشتراک جدید";
    }

    const receiptInfo = (tx.receiptImage && !tx.receiptImage.startsWith("data:image/")) ? tx.receiptImage : "تصویر فیش پیوست شد";
    const amountFormatted = Number(tx.amount || 0).toLocaleString("fa-IR");
    const shamsiTime = formatShamsiDate(new Date(), true);

    let adminMsg = `🔔 <b>رسید جدید برای تایید واریز شد! (مینی‌اپ)</b>\n\n` +
      `👤 <b>کاربر:</b> ${usernameDisplay} (<code>${tx.userId}</code>)\n` +
      `💰 <b>مبلغ فاکتور:</b> ${amountFormatted} تومان\n` +
      `🆔 <b>شناسه تراکنش:</b> <code>${tx.id}</code>\n` +
      `📦 <b>سرویس انتخابی:</b> ${typeDisplay}\n`;

    if (configNameDisplay) {
      adminMsg += `👤 <b>نام کانفیگ:</b> <code>${configNameDisplay}</code>\n`;
    }
    adminMsg += `🌐 <b>سرور:</b> ${serverDisplay}\n` +
      `📝 <b>توضیحات/فیش:</b> <code>${receiptInfo}</code>\n` +
      `⏱ <b>زمان ثبت:</b> ${shamsiTime}\n\n` +
      `📥 <i>جهت تایید یا رد مستقیم می‌توانید از پنل داشبورد یا دکمه‌های زیر استفاده کنید:</i>`;

    const inlineMarkup = {
      inline_keyboard: [
        [
          { text: "✅ تایید و فعال‌سازی فوری", callback_data: `tx_approve:${tx.id}` },
          { text: "❌ رد تراکنش", callback_data: `tx_reject:${tx.id}` }
        ]
      ]
    };

    const hasPhoto = tx.receiptImage && (tx.receiptImage.startsWith("data:image/") || tx.receiptImage.startsWith("http://") || tx.receiptImage.startsWith("https://"));

    for (const targetId of adminTargets) {
      try {
        if (hasPhoto) {
          await sendTelegramPhoto(primaryToken, targetId, tx.receiptImage, adminMsg, inlineMarkup);
        } else {
          await sendTelegramMessage(primaryToken, targetId, adminMsg, inlineMarkup);
        }
      } catch (err: any) {
        console.warn(`[Admin Receipt Notify Warning] for ${targetId}:`, err.message);
        if (primaryToken !== mainToken && mainToken && mainToken !== "DUMMY_TOKEN") {
          try {
            if (hasPhoto) {
              await sendTelegramPhoto(mainToken, targetId, tx.receiptImage, adminMsg, inlineMarkup);
            } else {
              await sendTelegramMessage(mainToken, targetId, adminMsg, inlineMarkup);
            }
          } catch (fbErr: any) {
            console.warn(`[Admin Receipt Notify Fallback Error] for ${targetId}:`, fbErr.message);
          }
        }
      }
    }
  } catch (e: any) {
    console.error("[notifyAdminsOnNewReceipt Error]", e);
  }
}

const mapServerFormat = (s: any, forceIsColleague = false) => {
  if (!s) return { id: "", name: "سرور عمومی", flag: "🌐" };
  let flag = "🌐";
  const nameLower = (s.name || s.remark || "").toLowerCase();
  if (nameLower.includes("germany") || nameLower.includes("آلمان") || nameLower.includes("de")) flag = "🇩🇪";
  else if (nameLower.includes("finland") || nameLower.includes("فنلاند") || nameLower.includes("fi")) flag = "🇫🇮";
  else if (nameLower.includes("netherlands") || nameLower.includes("هلند") || nameLower.includes("nl")) flag = "🇳🇱";
  else if (nameLower.includes("turkey") || nameLower.includes("ترکیه") || nameLower.includes("tr")) flag = "🇹🇷";
  else if (nameLower.includes("france") || nameLower.includes("فرانسه") || nameLower.includes("fr")) flag = "🇫🇷";
  else if (nameLower.includes("usa") || nameLower.includes("آمریکا") || nameLower.includes("us")) flag = "🇺🇸";
  else if (nameLower.includes("uk") || nameLower.includes("انگلیس") || nameLower.includes("gb")) flag = "🇬🇧";
  else if (nameLower.includes("uae") || nameLower.includes("دبی") || nameLower.includes("امارات")) flag = "🇦🇪";

  return {
    id: String(s.id || s.panelUrl || Math.random().toString(36).substring(2, 8)),
    name: s.name || s.remark || "سرور اختصاصی",
    flag,
    panelType: s.panelType || "sanaei",
    planCategories: Array.isArray(s.planCategories) ? s.planCategories : [],
    allowedPaymentMethods: Array.isArray(s.allowedPaymentMethods)
      ? s.allowedPaymentMethods
      : Array.isArray(s.allowed_payment_methods)
      ? s.allowed_payment_methods
      : [],
    status: s.status || "active",
    protocol: s.protocol || "VLESS",
    inbounds: s.inbounds || [],
    isColleague: forceIsColleague || s.isColleague === true || s.is_colleague === true || s.isReseller === true || s.is_reseller === true,
  };
};

app.get("/api/miniapp/data", async (req, res) => {
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
  try {
    const tgIdRaw = req.query.tg_id || req.query.userId || req.headers["x-telegram-user-id"];
    let tgId = tgIdRaw ? Number(tgIdRaw) : 0;

    if (tgId > 0 && miniappDataCacheMap.has(tgId)) {
      const cachedItem = miniappDataCacheMap.get(tgId)!;
      if (Date.now() - cachedItem.timestamp < 3000) {
        return res.json(cachedItem.data);
      }
    }

    const db = readSqliteDb();
    if ((db as any)._isReadError) {
      return res.status(503).json({ success: false, error: "دیتابیس در حال حاضر مشغول یا در وضعیت خطا است. لطفاً مجدداً تلاش کنید." });
    }
    const settings = getSystemSettings(db);

    const tgUsername = (req.query.username as string) || "";
    const tgFirstName = (req.query.first_name as string) || "";
    const tgLastName = (req.query.last_name as string) || "";

    let currentUser: any = null;

    // Resolve comprehensive user role & permissions
    const userRoleCheck = checkUserRoleAndAdmin(tgId, tgUsername, settings, db);
    const isAdmin = userRoleCheck.isAdmin;
    const isOwner = userRoleCheck.isOwner;
    const isSuperAdmin = userRoleCheck.isSuperAdmin;
    const userRole = userRoleCheck.role;
    const userRoleTitle = userRoleCheck.roleTitle;

    if (tgId && !isNaN(tgId) && tgId > 0) {
      if (tgId === 100001 || tgUsername === "daltoon_guest") {
        // GUEST USER: Do NOT push to db.users and do NOT write to database!
        currentUser = {
          id: 100001,
          userId: 100001,
          user_id: 100001,
          username: "daltoon_guest",
          firstName: "کاربر",
          lastName: "مهمان",
          fullName: "کاربر مهمان",
          walletBalance: 0,
          wallet_balance: 0,
          balance: 0,
          status: "active",
          role: "user",
          isAdmin: false,
          isOwner: false,
          isSuperAdmin: false,
          activePlansCount: 0,
          registeredAt: new Date().toISOString(),
          createdAt: new Date().toISOString()
        };
      } else {
        if (!Array.isArray(db.users)) db.users = [];
        currentUser = db.users.find((u: any) => Number(u.userId) === tgId || Number(u.user_id) === tgId || Number(u.id) === tgId);

        if (!currentUser) {
          // Auto-register user in DB
          currentUser = {
            id: tgId,
            userId: tgId,
            user_id: tgId,
            username: tgUsername || `user_${tgId}`,
            firstName: tgFirstName || "",
            lastName: tgLastName || "",
            fullName: `${tgFirstName || ""} ${tgLastName || ""}`.trim() || `User ${tgId}`,
            walletBalance: 0,
            wallet_balance: 0,
            balance: 0,
            status: "active",
            role: userRole,
            isAdmin: isAdmin,
            isOwner: isOwner,
            isSuperAdmin: isSuperAdmin,
            activePlansCount: 0,
            registeredAt: new Date().toISOString(),
            createdAt: new Date().toISOString()
          };
          db.users.push(currentUser);
          writeSqliteDb(db);
        } else {
          // Update user profile if changed
          let updated = false;
          if (tgUsername && currentUser.username !== tgUsername) {
            currentUser.username = tgUsername;
            updated = true;
          }
          if (tgFirstName && currentUser.firstName !== tgFirstName) {
            currentUser.firstName = tgFirstName;
            currentUser.fullName = `${tgFirstName} ${tgLastName || currentUser.lastName || ""}`.trim();
            updated = true;
          }
          if (currentUser.role !== userRole || currentUser.isAdmin !== isAdmin || currentUser.isOwner !== isOwner) {
            currentUser.role = userRole;
            currentUser.isAdmin = isAdmin;
            currentUser.isOwner = isOwner;
            currentUser.isSuperAdmin = isSuperAdmin;
            updated = true;
          }
          if (updated) {
            writeSqliteDb(db);
          }
        }
      }
    }

    // Active Servers - Filter standard vs colleague
    const rawServers = getActiveServers(settings);

    // List of colleague server IDs from packages or colleagueServers
    const colleagueServerIds = new Set<string>();
    (db.colleague_packages || []).forEach((p: any) => {
      if (p.serverId) colleagueServerIds.add(String(p.serverId));
    });
    if (Array.isArray(settings.colleagueServers)) {
      settings.colleagueServers.forEach((s: any) => {
        if (s.id) colleagueServerIds.add(String(s.id));
        if (s.panelUrl) colleagueServerIds.add(String(s.panelUrl));
      });
    }

    // Standard Servers - Extract robustly from settings.servers, rawServers, or db.servers
    let standardServersRaw = Array.isArray(settings.servers) && settings.servers.length > 0
      ? settings.servers.filter((s: any) => s && s.status !== "inactive" && !s.isColleague && !s.is_colleague && !s.isReseller && !s.is_reseller)
      : [];

    if (standardServersRaw.length === 0 && Array.isArray(rawServers) && rawServers.length > 0) {
      standardServersRaw = rawServers.filter((s: any) => s && s.status !== "inactive" && !s.isColleague && !s.is_colleague && !s.isReseller && !s.is_reseller);
    }

    if (standardServersRaw.length === 0 && Array.isArray(db.servers) && db.servers.length > 0) {
      standardServersRaw = db.servers.filter((s: any) => s && s.status !== "inactive" && !s.isColleague && !s.is_colleague && !s.isReseller && !s.is_reseller);
    }

    if (standardServersRaw.length === 0 && settings.panelConnectionActive && settings.baseUrl && settings.panelUsername && settings.panelPassword) {
      standardServersRaw = [{
        id: "legacy_server",
        name: "پنل اصلی",
        panelUrl: settings.baseUrl,
        subUrl: settings.subUrl,
        panelType: settings.panelType || "sanaei",
        status: "active"
      }];
    }
    const activeServers = standardServersRaw.map((s: any) => mapServerFormat(s, false));

    // Colleague Servers - EXACTLY from settings.colleagueServers (where status is active)
    const colleagueServersRaw = Array.isArray(settings.colleagueServers) ? settings.colleagueServers.filter((s: any) => s && s.status !== "inactive") : [];
    const colleagueServers = colleagueServersRaw.map((s: any) => mapServerFormat(s, true));

    // Colleague Packages & User Accounts
    const rawColleaguePackages = Array.isArray(db.colleague_packages) ? db.colleague_packages : [];

    const colleaguePackages = rawColleaguePackages.map((p: any) => {
      const srv = rawServers.find((s: any) => String(s.id) === String(p.serverId));
      return {
        id: p.id,
        title: p.title || p.name || `بسته همکار ${p.trafficGb || 0} گیگ`,
        trafficGb: Number(p.trafficGb || p.traffic_gb || 0),
        price: Number(p.price || 0),
        serverId: p.serverId || "",
        serverName: srv ? (srv.name || srv.remark || "سرور همکاران") : "",
        durationDays: p.durationDays !== undefined && !isNaN(Number(p.durationDays)) ? Number(p.durationDays) : Number(p.duration_days || 30),
        category: p.category || "",
        minCreateGb: Number(p.minCreateGb || p.min_create_gb || 1),
        description: p.description || ""
      };
    });

    const userColleagueAccounts = tgId > 0
      ? (db.colleague_accounts || []).filter((a: any) => Number(a.userId) === tgId).map((a: any) => {
          const keys = db.subscription_keys || [];
          const colKeys = keys.filter((k: any) => isKeyForColleague(k, a));
          const totalPkg = Number(a.trafficGb || 0);
          const sumAlloc = colKeys.reduce((s: number, k: any) => s + Number(k.trafficLimitGb || 0), 0) + Number(a.deletedTrafficGb || 0);
          const sumReal = colKeys.reduce((s: number, k: any) => s + Number(k.trafficUsedGb || 0), 0) + Number(a.deletedRealTrafficGb || 0);
          const pkg = (db.colleague_packages || []).find((p: any) => p.id === a.packageId);
          const minCreateGb = Number(a.minCreateGb || a.min_create_gb || pkg?.minCreateGb || pkg?.min_create_gb || settings.colleagueMinCreateGb || settings.minCreateGb || 0);
          return {
            id: a.id,
            username: a.username,
            password: a.password,
            prefix: a.prefix || "Col",
            packageTitle: a.packageTitle || "بسته همکار",
            trafficGb: totalPkg,
            minCreateGb: minCreateGb,
            allocatedTrafficGb: sumAlloc,
            usedTrafficGb: sumReal,
            remainingTrafficGb: Math.max(0, totalPkg - sumAlloc),
            status: a.status || "active",
            createdAt: a.createdAt
          };
        })
      : [];

    // Plan Categories
    const planCategories = (db.plan_categories || []).map((c: any) => ({
      id: c.id,
      name: c.name,
      emoji: c.emoji || "⚡️",
      description: c.description || "",
    }));

    // VPN Plans
    const vpnPlans = (db.vpn_plans || []).map((p: any) => ({
      id: p.id,
      name: p.name,
      category: p.category || "سایر",
      price: Number(p.price || 0),
      trafficGb: Number(p.trafficGb || p.traffic_gb || 30),
      durationDays: Number(p.durationDays || p.duration_days || 30),
      inbounds: p.inbounds || [],
      tag: p.tag || (Number(p.trafficGb) >= 100 ? "ویژه VIP" : Number(p.trafficGb) <= 30 ? "پرفروش" : "اقتصادی"),
      features: p.features || ["سرعت بالا و پایدار", "بدون قطعی و پینگ مناسب", "پشتیبانی از تمام اپراتورها"]
    }));

    // Custom Pricing Configuration
    let panelConfig: any = {};
    try {
      panelConfig = typeof settings.panel_config === "string" ? JSON.parse(settings.panel_config) : (settings.panel_config || {});
    } catch (e) {
      panelConfig = {};
    }

    const isCustomPricingActive = settings.isCustomPricingActive !== false && panelConfig.isCustomPricingActive !== false;
    const customPricingBoxes = panelConfig.customPricingBoxes || settings.customPricingBoxes || [];

    // User Subscriptions (Configs) - Sorted newest first by default
    let dbUpdatedSubs = false;
    const nowMs = Date.now();
    const userSubs = tgId > 0
      ? (db.subscription_keys || [])
          .filter((k: any) => {
            const kid = Number(k.userId || k.user_id || k.telegram_id || k.tgId || 0);
            if (kid === tgId) return true;
            if (String(k.userId) === String(tgId) || String(k.user_id) === String(tgId) || String(k.telegram_id) === String(tgId)) return true;
            return false;
          })
          .map((k: any) => {
            const liveSubLink = buildCorrectSubLinkForClient(k, k.serverId, settings, db);
            if (k.subLink !== liveSubLink) {
              k.subLink = liveSubLink;
              dbUpdatedSubs = true;
            }
            const vlessData = generateVlessConfigsForClient(k.clientName, k.clientUuid, k.serverId, settings, liveSubLink);

            const usedGb = Number(k.trafficUsedGb ?? k.traffic_used_gb ?? k.usedGb ?? 0);
            const limitGb = Number(k.trafficLimitGb ?? k.traffic_limit_gb ?? k.totalGb ?? 30);
            const remainingGb = Math.max(0, limitGb - usedGb);

            let daysRemaining = 30;
            let isExpired = false;
            let isExhausted = false;

            if (k.expireDate) {
              try {
                const expTime = new Date(k.expireDate).getTime();
                if (!isNaN(expTime)) {
                  daysRemaining = Math.ceil((expTime - nowMs) / (1000 * 60 * 60 * 24));
                  if (daysRemaining <= 0 || expTime < nowMs) {
                    isExpired = true;
                    daysRemaining = 0;
                  }
                }
              } catch (e) {}
            } else if (k.expireTimestamp) {
              const expTime = Number(k.expireTimestamp) > 10000000000 ? Number(k.expireTimestamp) : Number(k.expireTimestamp) * 1000;
              daysRemaining = Math.ceil((expTime - nowMs) / (1000 * 60 * 60 * 24));
              if (daysRemaining <= 0 || expTime < nowMs) {
                isExpired = true;
                daysRemaining = 0;
              }
            }

            if (limitGb > 0 && usedGb >= limitGb) {
              isExhausted = true;
            }

            let effectiveStatus = k.status || "active";
            if (k.disabled === true || effectiveStatus === "disabled" || effectiveStatus === "suspended") {
              effectiveStatus = "disabled";
            } else if (isExhausted) {
              effectiveStatus = "exhausted";
            } else if (isExpired) {
              effectiveStatus = "expired";
            } else {
              effectiveStatus = "active";
            }

            const srvName = getServerRemark(k.serverId, settings, db);
            const srv = rawServers.find((s: any) => String(s.id) === String(k.serverId));

            return {
              ...k,
              trafficUsedGb: usedGb,
              trafficLimitGb: limitGb,
              remainingGb: Number(remainingGb.toFixed(2)),
              daysRemaining,
              status: effectiveStatus,
              subLink: liveSubLink,
              serverName: srvName,
              serverFlag: srv ? mapServerFormat(srv).flag : "🌐",
              vlessConfigs: k.vlessConfigs && k.vlessConfigs.length > 0 ? k.vlessConfigs : vlessData.vlessConfigs,
              vlessLinks: k.vlessLinks && k.vlessLinks.length > 0 ? k.vlessLinks : vlessData.vlessLinks
            };
          })
          .sort((a: any, b: any) => {
            const timeA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
            const timeB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
            if (timeA && timeB && timeA !== timeB) return timeB - timeA;
            const idA = typeof a.id === "number" ? a.id : parseInt(String(a.id).replace(/\D/g, ""), 10) || 0;
            const idB = typeof b.id === "number" ? b.id : parseInt(String(b.id).replace(/\D/g, ""), 10) || 0;
            return idB - idA;
          })
      : [];

    if (dbUpdatedSubs) {
      writeSqliteDb(db);
    }

    // Check if free test used
    const hasUsedFreeTest = tgId > 0 && userSubs.some((k: any) =>
      k.isTest || (k.planName || "").includes("تست") || (k.planId || "").includes("test")
    );

    // User Tickets
    const userTickets = tgId > 0
      ? sanitizeTicketsList((db.tickets || []).filter((t: any) => Number(t.userId) === tgId))
      : [];

    // User Transactions
    const userTransactions = tgId > 0
      ? (db.transactions || []).filter((tx: any) => Number(tx.userId) === tgId).slice(-20)
      : [];

    // User Statistics Computation for Profile
    const invitedCount = (db.users || []).filter((u: any) =>
      (u.invitedBy && (Number(u.invitedBy) === tgId || String(u.invitedBy) === String(tgId))) ||
      (u.inviterId && (Number(u.inviterId) === tgId || String(u.inviterId) === String(tgId))) ||
      (u.referrerId && (Number(u.referrerId) === tgId || String(u.referrerId) === String(tgId)))
    ).length || Number(currentUser?.invitedCount || currentUser?.referralsCount || currentUser?.invited_count || 0);

    const totalTrafficGb = userSubs.reduce((acc: number, s: any) => acc + Number(s.trafficLimitGb || s.traffic_limit_gb || s.totalGb || 0), 0);
    const totalUsedTrafficGb = userSubs.reduce((acc: number, s: any) => acc + Number(s.trafficUsedGb || s.traffic_used_gb || 0), 0);
    const totalDeposits = (db.transactions || [])
      .filter((tx: any) => (Number(tx.userId) === tgId || Number(tx.user_id) === tgId) && tx.status === "approved")
      .reduce((acc: number, tx: any) => acc + Number(tx.amount || 0), 0);

      const isFreeTestEnabled = settings.isFreeTestActive !== false && settings.isTestAccountActive !== false && settings.IS_FREETEST_ACTIVE !== false;
      const testTrafficGb = Number(
        settings.freeTestGb !== undefined
          ? settings.freeTestGb
          : settings.FREE_TEST_GB !== undefined
          ? settings.FREE_TEST_GB
          : settings.testTrafficGb !== undefined
          ? settings.testTrafficGb
          : 0.1
      );
      const testDurationDays = Number(
        settings.freeTestDays !== undefined
          ? settings.freeTestDays
          : settings.FREE_TEST_DAYS !== undefined
          ? settings.FREE_TEST_DAYS
          : settings.testDurationHours
          ? settings.testDurationHours / 24
          : 1
      );
      const testDurationHours = Math.round(testDurationDays * 24);
      const freeTestDisabledMsg = settings.freeTestDisabledMessage || settings.FREETEST_DISABLED_MSG || "اکانت تست رایگان فعلا موجود نیست.";
      const freeTestServerId = settings.freeTestServerId || settings.FREE_TEST_SERVER_ID || "";
      const freeTestServerObj = freeTestServerId
        ? activeServers.find((s: any) => String(s.id).trim() === String(freeTestServerId).trim())
        : null;

      const responseData = {
        success: true,
        user: currentUser ? {
          id: currentUser.id || currentUser.userId,
          userId: currentUser.userId || currentUser.id,
          username: currentUser.username || "",
          firstName: currentUser.firstName || "",
          lastName: currentUser.lastName || "",
          fullName: currentUser.fullName || currentUser.username || "کاربر گرامی",
          walletBalance: Number(currentUser.walletBalance || currentUser.wallet_balance || currentUser.balance || 0),
          status: currentUser.status || "active",
          isBanned: currentUser.status === "banned",
          isAdmin: isAdmin,
          isOwner: isOwner,
          isSuperAdmin: isSuperAdmin,
          role: userRole,
          roleTitle: userRoleTitle,
          activePlansCount: userSubs.filter((s: any) => s.status === "active").length,
          invitedCount: invitedCount,
          totalTrafficGb: totalTrafficGb,
          totalUsedTrafficGb: totalUsedTrafficGb,
          totalDeposits: totalDeposits,
          totalTicketsCount: userTickets.length,
          createdAt: currentUser.createdAt || currentUser.registeredAt || currentUser.created_at || currentUser.joinedAt || new Date().toISOString()
        } : null,
        isAdmin,
        isOwner,
        isSuperAdmin,
        role: userRole,
        roleTitle: userRoleTitle,
        servers: activeServers,
        colleagueServers: colleagueServers.length > 0 ? colleagueServers : activeServers,
        colleaguePackages,
        colleagueAccounts: userColleagueAccounts,
        planCategories,
        vpnPlans,
        customPricing: {
          enabled: isCustomPricingActive,
          boxes: customPricingBoxes,
          defaultPricePerGb: 3000,
          defaultPricePerDay: 2000,
        },
        testAccount: {
          enabled: isFreeTestEnabled,
          trafficGb: testTrafficGb,
          durationDays: testDurationDays,
          durationHours: testDurationHours,
          disabledMessage: freeTestDisabledMsg,
          serverId: freeTestServerId,
          serverName: freeTestServerObj ? (freeTestServerObj.name || freeTestServerObj.remark) : null,
          serverFlag: freeTestServerObj ? mapServerFormat(freeTestServerObj).flag : null,
          hasUsed: hasUsedFreeTest
        },
        settings: {
          botNickname: settings.botNickname || "دالتون",
          botUsername: (settings.botUsername || settings.botNickname || "DaltoonBot").replace(/^@/, '').replace(/\s+/g, '').replace(/[^a-zA-Z0-9_]/g, '') || "DaltoonBot",
          cardNumber: getEffectiveCardDetails(settings).cardNumber,
          cardHolder: getEffectiveCardDetails(settings).cardHolder,
          bankName: getEffectiveCardDetails(settings).bankName,
          cardNumbers: getEffectiveCardDetails(settings).cardNumbers,
          channelUsername: settings.channelUsername || "",
          supportUsername: settings.supportUsername || settings.channelUsername || "",
          panelType: settings.panelType || "sanaei",
          miniAppSplashLogo: settings.miniAppSplashLogo || "",
          miniAppSplashEnabled: settings.miniAppSplashEnabled !== false
        },
        subscriptions: userSubs,
        tickets: userTickets,
        transactions: userTransactions,
        notifications: tgId > 0 ? (db.user_notifications || []).filter((n: any) => Number(n.userId) === tgId && !n.read && !n.isRead) : []
      };

      if (tgId > 0) {
        miniappDataCacheMap.set(tgId, { data: responseData, timestamp: Date.now() });
      }

      res.json(responseData);
  } catch (error: any) {
    console.error("[MiniApp Data Error]:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Mark notification(s) as read for MiniApp user
app.post("/api/miniapp/notifications/read", (req, res) => {
  try {
    const { id, userId, all } = req.body;
    const db = readSqliteDb();
    if (!Array.isArray(db.user_notifications)) db.user_notifications = [];

    if (all && userId) {
      for (const n of db.user_notifications) {
        if (Number(n.userId) === Number(userId)) {
          n.read = true;
          n.isRead = true;
        }
      }
    } else if (id) {
      const notif = db.user_notifications.find((n: any) => String(n.id) === String(id));
      if (notif) {
        notif.read = true;
        notif.isRead = true;
      }
    }

    writeSqliteDb(db);
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Colleague Authentication & Operations for MiniApp
app.post("/api/miniapp/colleague/login", (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ success: false, error: "نام کاربری و رمز عبور همکار را وارد کنید." });
    }

    const db = readSqliteDb();
    const accounts = db.colleague_accounts || [];
    const acc = accounts.find((a: any) => 
      String(a.username).trim().toLowerCase() === String(username).trim().toLowerCase() &&
      String(a.password).trim() === String(password).trim()
    );

    if (!acc) {
      return res.status(401).json({ success: false, error: "نام کاربری یا رمز عبور همکار اشتباه است." });
    }

    const settings = getSystemSettings(db);
    // Calculate usage statistics
    const keys = db.subscription_keys || [];
    const colKeys = keys.filter((k: any) => isKeyForColleague(k, acc));
    const totalPkg = Number(acc.trafficGb || 0);
    const sumAlloc = colKeys.reduce((s: number, k: any) => s + Number(k.trafficLimitGb || 0), 0) + Number(acc.deletedTrafficGb || 0);
    const sumReal = colKeys.reduce((s: number, k: any) => s + Number(k.trafficUsedGb || 0), 0) + Number(acc.deletedRealTrafficGb || 0);
    const remainingGb = Math.max(0, totalPkg - sumAlloc);
    const pkg = (db.colleague_packages || []).find((p: any) => p.id === acc.packageId);
    const minCreateGb = Number(acc.minCreateGb || acc.min_create_gb || pkg?.minCreateGb || pkg?.min_create_gb || settings.colleagueMinCreateGb || settings.minCreateGb || 0);

    res.json({
      success: true,
      account: {
        id: acc.id,
        username: acc.username,
        prefix: acc.prefix || "Col",
        packageTitle: acc.packageTitle || "بسته همکار",
        packageId: acc.packageId,
        trafficGb: totalPkg,
        minCreateGb: minCreateGb,
        allocatedTrafficGb: sumAlloc,
        usedTrafficGb: sumReal,
        remainingTrafficGb: remainingGb,
        expireDate: acc.expireDate || "نامحدود",
      },
      clients: colKeys.map((k: any) => ({
        id: k.id,
        clientName: k.clientName || k.email || k.remark,
        clientUuid: k.clientUuid || k.uuid,
        serverId: k.serverId,
        trafficLimitGb: Number(k.trafficLimitGb || 0),
        trafficUsedGb: Number(k.trafficUsedGb || 0),
        subLink: buildCorrectSubLinkForClient(k, k.serverId, settings, db),
        expireDate: k.expireDate || "نامحدود",
        status: k.status || "active",
        disabled: k.disabled || false,
        vlessConfigs: k.vlessConfigs || [],
        vlessLinks: k.vlessLinks || [],
        createdAt: k.createdAt || new Date(k.createdAtMs || Date.now()).toLocaleDateString("fa-IR")
      }))
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Colleague Verify Recovery Token
app.post("/api/miniapp/colleague/verify-token", (req, res) => {
  try {
    const { recoveryToken } = req.body;
    if (!recoveryToken || !recoveryToken.trim()) {
      return res.status(400).json({ success: false, error: "توکن بازیابی را وارد کنید." });
    }

    const db = readSqliteDb();
    const accounts = db.colleague_accounts || [];
    const acc = accounts.find((a: any) => String(a.recoveryToken || "").trim().toLowerCase() === String(recoveryToken).trim().toLowerCase());

    if (!acc) {
      return res.status(404).json({ success: false, error: "حساب همکار با این توکن بازیابی یافت نشد." });
    }

    res.json({
      success: true,
      account: {
        id: acc.id,
        username: acc.username,
        recoveryToken: acc.recoveryToken,
        packageTitle: acc.packageTitle || "پکیج همکار",
        trafficGb: acc.trafficGb || 0,
        expireDate: acc.expireDate || "نامحدود",
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Colleague Recover Password via Token
app.post("/api/miniapp/colleague/recover-token", (req, res) => {
  try {
    const { recoveryToken, newUsername, newPassword } = req.body;
    if (!recoveryToken || !recoveryToken.trim()) {
      return res.status(400).json({ success: false, error: "توکن بازیابی را وارد کنید." });
    }

    const db = readSqliteDb();
    const accounts = db.colleague_accounts || [];
    const acc = accounts.find((a: any) => String(a.recoveryToken || "").trim().toLowerCase() === String(recoveryToken).trim().toLowerCase());

    if (!acc) {
      return res.status(404).json({ success: false, error: "حساب همکار با این توکن بازیابی یافت نشد." });
    }

    const cleanUser = (newUsername || "").trim();
    const cleanPass = (newPassword || "").trim();

    if (!cleanUser) {
      return res.status(400).json({ success: false, error: "لطفاً نام کاربری جدید را وارد کنید." });
    }
    if (!cleanPass) {
      return res.status(400).json({ success: false, error: "لطفاً رمز عبور جدید را وارد کنید." });
    }

    // Check username uniqueness if changed
    const existingOther = accounts.find((a: any) =>
      a.id !== acc.id &&
      String(a.username || "").trim().toLowerCase() === cleanUser.toLowerCase()
    );

    if (existingOther) {
      return res.status(400).json({ success: false, error: "این نام کاربری توسط همکار دیگری ثبت شده است. لطفاً نام کاربری دیگری انتخاب کنید." });
    }

    const oldUsername = acc.username;
    acc.username = cleanUser;
    acc.password = cleanPass;

    // Update any linked configs in subscription_keys if username changed
    if (oldUsername && oldUsername !== cleanUser && db.subscription_keys && Array.isArray(db.subscription_keys)) {
      db.subscription_keys.forEach((k: any) => {
        if (k.colleagueAccountId === acc.id || k.colleagueUsername === oldUsername) {
          k.colleagueUsername = cleanUser;
        }
      });
    }

    writeSqliteDb(db);

    res.json({
      success: true,
      account: {
        id: acc.id,
        username: acc.username,
        password: acc.password,
      },
      message: `اطلاعات حساب همکار با موفقیت بروزرسانی شد.\nنام کاربری جدید: ${acc.username}\nرمز عبور جدید: ${acc.password}`
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Colleague Buy Package via MiniApp
app.post("/api/miniapp/colleague/buy-package", async (req, res) => {
  try {
    const {
      userId,
      username,
      packageId,
      prefix,
      token,
      paymentMethod,
      receiptImage
    } = req.body;

    if (!userId || Number(userId) <= 0) {
      return res.status(400).json({ success: false, error: "شناسه کاربری تلگرام الزامی است." });
    }
    if (!packageId) {
      return res.status(400).json({ success: false, error: "شناسه بسته همکار الزامی است." });
    }

    const cleanPrefix = (prefix || "").trim().replace(/[^a-zA-Z0-9_]/g, "");
    if (!cleanPrefix || cleanPrefix.length < 2 || cleanPrefix.length > 10) {
      return res.status(400).json({ success: false, error: "پسوند کانفیگ‌ها باید ۲ الی ۱۰ کاراکتر انگلیسی باشد." });
    }

    const rawToken = req.body.recoveryToken || req.body.token;
    const cleanToken = (rawToken || "").trim().replace(/[^a-zA-Z0-9_]/g, "");
    if (!cleanToken || cleanToken.length < 3 || cleanToken.length > 30) {
      return res.status(400).json({ success: false, error: "توکن امنیتی بازیابی الزامی است و باید حداقل ۳ کاراکتر انگلیسی بدون فاصله باشد." });
    }

    const tgId = Number(userId);
    const db = readSqliteDb();
    const settings = getSystemSettings(db);

    if (!Array.isArray(db.colleague_accounts)) db.colleague_accounts = [];
    if (!Array.isArray(db.users)) db.users = [];

    // Check duplicate prefix
    if (db.colleague_accounts.some((a: any) => (a.prefix || "").toLowerCase() === cleanPrefix.toLowerCase())) {
      return res.status(400).json({ success: false, error: "این پیشوند (Prefix) قبلاً ثبت شده است. لطفاً پیشوند دیگری انتخاب کنید." });
    }

    // Check duplicate token
    if (db.colleague_accounts.some((a: any) => (a.recoveryToken || "").toLowerCase() === cleanToken.toLowerCase())) {
      return res.status(400).json({ success: false, error: "این توکن بازیابی قبلاً ثبت شده است. لطفاً توکن اختصاصی دیگری وارد کنید." });
    }

    const packages = db.colleague_packages || [];
    const pkg = packages.find((p: any) => p.id === packageId);
    if (!pkg) {
      return res.status(404).json({ success: false, error: "بسته همکار مورد نظر یافت نشد." });
    }

    let user = db.users.find((u: any) => Number(u.userId) === tgId || Number(u.user_id) === tgId);
    if (!user) {
      user = {
        id: tgId,
        userId: tgId,
        user_id: tgId,
        username: username || `user_${tgId}`,
        walletBalance: 0,
        status: "active"
      };
      db.users.push(user);
    }

    // Check Admin and Owner status
    const roleCheck = checkUserRoleAndAdmin(tgId, username, settings, db);
    const isAdmin = roleCheck.isAdmin;
    const isFreeAdmin = isAdmin && (paymentMethod === "admin_free" || paymentMethod === "wallet");
    const finalPrice = isFreeAdmin ? 0 : Number(pkg.price || 0);

    // ==========================================
    // PAYMENT METHOD 1: WALLET / ADMIN FREE
    // ==========================================
    if (paymentMethod === "wallet" || isFreeAdmin || paymentMethod === "admin_free") {
      const userBalance = Number(user.walletBalance || user.wallet_balance || user.balance || 0);
      if (!isFreeAdmin && userBalance < finalPrice) {
        return res.status(400).json({
          success: false,
          error: `موجودی کیف پول شما کافی نیست. موجودی: ${userBalance.toLocaleString("fa-IR")} تومان | قیمت بسته: ${finalPrice.toLocaleString("fa-IR")} تومان`
        });
      }

      if (!isFreeAdmin) {
        user.walletBalance = userBalance - finalPrice;
        user.wallet_balance = user.walletBalance;
        user.balance = user.walletBalance;
      }

      // Generate Colleague Account
      const generatedUsername = "C" + Math.floor(10000 + Math.random() * 90000);
      const generatedPassword = Math.random().toString(36).substring(2, 10);

      const newAcc = {
        id: "COL-ACC-" + Date.now() + "-" + Math.floor(Math.random() * 9000 + 1000),
        userId: tgId,
        username: generatedUsername,
        password: generatedPassword,
        packageId: pkg.id,
        packageTitle: pkg.title || pkg.name,
        createdAt: new Date().toISOString().split("T")[0],
        trafficGb: Number(pkg.trafficGb || pkg.traffic_gb || 50),
        minCreateGb: Number(pkg.minCreateGb || pkg.min_create_gb || settings.colleagueMinCreateGb || settings.minCreateGb || 1),
        usedTrafficGb: 0,
        prefix: cleanPrefix,
        recoveryToken: cleanToken,
        status: "active"
      };

      db.colleague_accounts.push(newAcc);

      // Record Transaction
      if (!Array.isArray(db.transactions)) db.transactions = [];
      const newTx = {
        id: "TX-COL-" + Date.now() + "-" + Math.floor(Math.random() * 9000 + 1000),
        userId: tgId,
        username: user.username || username || `user_${tgId}`,
        amount: finalPrice,
        status: "approved",
        type: isFreeAdmin ? "admin_colleague_free" : "colleague_package_purchase",
        date: new Date().toISOString(),
        description: `خرید بسته همکار ${pkg.title || pkg.name} (پیشوند: ${cleanPrefix})`
      };
      db.transactions.push(newTx);
      writeSqliteDb(db);

      return res.json({
        success: true,
        account: newAcc,
        credentials: {
          username: generatedUsername,
          password: generatedPassword,
          prefix: cleanPrefix,
          trafficGb: newAcc.trafficGb
        },
        message: `بسته همکار ${pkg.title} با موفقیت خریداری شد!`
      });
    }

    // ==========================================
    // PAYMENT METHOD 2: CARD TO CARD
    // ==========================================
    if (paymentMethod === "card_to_card") {
      if (!Array.isArray(db.transactions)) db.transactions = [];
      const newTx = {
        id: "TX-CARD-COL-" + Date.now() + "-" + Math.floor(Math.random() * 9000 + 1000),
        userId: tgId,
        username: user.username || username || `user_${tgId}`,
        amount: finalPrice,
        receiptImage: receiptImage || "",
        status: "pending",
        type: "PLAN_PURCHASE",
        planId: `COL_BUY:${pkg.id}`,
        clientName: `${cleanPrefix}||${cleanToken}`,
        date: new Date().toISOString(),
        description: `خرید بسته همکار ${pkg.title || pkg.name} (کارت به کارت)`,
        pendingPurchase: {
          planName: `بسته همکار ${pkg.title || pkg.name}`,
          prefix: cleanPrefix,
          token: cleanToken,
          packageId: pkg.id,
          finalPrice
        }
      };
      db.transactions.push(newTx);
      writeSqliteDb(db);

      // Send Telegram notification to admins
      notifyAdminsOnNewReceipt(newTx, db, settings).catch((err) => {
        console.warn("[Admin Colleague Notification Warning]", err);
      });

      return res.json({
        success: true,
        pendingApproval: true,
        transactionId: newTx.id,
        message: "رسید شما با موفقیت ثبت شد و پس از تایید مدیریت، حساب همکار شما فعال خواهد شد."
      });
    }

    return res.status(400).json({ success: false, error: "روش پرداخت نامعتبر است." });
  } catch (err: any) {
    console.error("[Buy Colleague Package Error]", err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Colleague Plan Renewal Endpoint (Invoice & Payment via Wallet or Card-to-Card)
app.post("/api/miniapp/colleague/renew-plan", async (req, res) => {
  try {
    const {
      userId,
      username,
      accountId,
      packageId,
      paymentMethod = "wallet",
      receiptImage = ""
    } = req.body;

    if (!userId || Number(userId) <= 0) {
      return res.status(400).json({ success: false, error: "شناسه کاربری تلگرام الزامی است." });
    }
    if (!packageId) {
      return res.status(400).json({ success: false, error: "شناسه بسته همکار الزامی است." });
    }

    const tgId = Number(userId);
    const db = readSqliteDb();
    const settings = getSystemSettings(db);

    const packages = db.colleague_packages || [];
    const pkg = packages.find((p: any) => String(p.id) === String(packageId));
    if (!pkg) {
      return res.status(404).json({ success: false, error: "بسته همکار مورد نظر یافت نشد." });
    }

    let colAcc = (db.colleague_accounts || []).find(
      (a: any) => String(a.id) === String(accountId) || (Number(a.userId) === tgId)
    );
    if (!colAcc) {
      return res.status(404).json({ success: false, error: "حساب همکار یافت نشد." });
    }

    let user = (db.users || []).find((u: any) => Number(u.userId) === tgId || Number(u.user_id) === tgId);
    if (!user) {
      user = { id: tgId, userId: tgId, username: username || `user_${tgId}`, walletBalance: 0, status: "active" };
      if (!Array.isArray(db.users)) db.users = [];
      db.users.push(user);
    }

    const roleCheck = checkUserRoleAndAdmin(tgId, username, settings, db);
    const isAdmin = roleCheck.isAdmin;
    const isFreeAdmin = isAdmin && (paymentMethod === "admin_free" || paymentMethod === "wallet");
    const finalPrice = isFreeAdmin ? 0 : Number(pkg.price || 0);

    // ==========================================
    // PAYMENT METHOD 1: WALLET / ADMIN FREE
    // ==========================================
    if (paymentMethod === "wallet" || isFreeAdmin || paymentMethod === "admin_free") {
      const userBalance = Number(user.walletBalance || user.wallet_balance || user.balance || 0);
      if (!isFreeAdmin && userBalance < finalPrice) {
        return res.status(400).json({
          success: false,
          error: `موجودی کیف پول شما کافی نیست. موجودی: ${userBalance.toLocaleString("fa-IR")} تومان | هزینه تمدید پلن: ${finalPrice.toLocaleString("fa-IR")} تومان`
        });
      }

      if (!isFreeAdmin) {
        user.walletBalance = userBalance - finalPrice;
        user.wallet_balance = user.walletBalance;
        user.balance = user.walletBalance;
      }

      const addedGb = Number(pkg.trafficGb || pkg.traffic_gb || 0);
      colAcc.trafficGb = Number(colAcc.trafficGb || 0) + addedGb;
      colAcc.packageTitle = pkg.title || pkg.name || colAcc.packageTitle;

      if (!Array.isArray(db.transactions)) db.transactions = [];
      const newTx = {
        id: "TX-COL-RENEW-" + Date.now() + "-" + Math.floor(Math.random() * 9000 + 1000),
        userId: tgId,
        username: user.username || username || `user_${tgId}`,
        amount: finalPrice,
        status: "approved",
        type: "colleague_package_renew",
        planId: `COL_RENEW:${pkg.id}`,
        clientName: colAcc.id,
        date: new Date().toISOString(),
        description: `تمدید / شارژ پلن همکاری (+${addedGb} GB) - ${colAcc.prefix || colAcc.username}`
      };
      db.transactions.push(newTx);
      writeSqliteDb(db);

      try {
        const renewMsg =
          `🔄 <b>[تمدید پلن همکاری - پرداخت از کیف پول]</b>\n\n` +
          `👤 <b>همکار:</b> ${colAcc.prefix || colAcc.username} (<code>${tgId}</code>)\n` +
          `📦 <b>بسته خریداری شده:</b> ${pkg.title} (+${addedGb} GB)\n` +
          `📊 <b>سهمیه کل جدید:</b> ${colAcc.trafficGb} GB\n` +
          `💰 <b>مبلغ پرداختی:</b> ${finalPrice.toLocaleString("fa-IR")} تومان\n` +
          `⏱ <b>زمان:</b> ${formatShamsiDate(new Date(), true)}`;
        sendAdminNotification(renewMsg, settings).catch(() => {});
      } catch (e) {}

      return res.json({
        success: true,
        message: `پلن همکاری با موفقیت تمدید شد و ${addedGb} گیگابایت به حجم سهمیه شما اضافه گردید.`,
        colleagueAccount: colAcc,
        walletBalance: user.walletBalance
      });
    }

    // ==========================================
    // PAYMENT METHOD 2: CARD TO CARD RECEIPT
    // ==========================================
    if (paymentMethod === "card_to_card") {
      if (!receiptImage || !String(receiptImage).trim()) {
        return res.status(400).json({ success: false, error: "تصویر رسید واریز الزامی است." });
      }

      if (!Array.isArray(db.transactions)) db.transactions = [];
      const newTx: any = {
        id: "TX-COL-RENEW-" + Date.now() + "-" + Math.floor(Math.random() * 9000 + 1000),
        userId: tgId,
        username: user.username || username || `user_${tgId}`,
        amount: finalPrice,
        receiptImage: receiptImage || "",
        status: "pending",
        type: "PLAN_PURCHASE",
        planId: `COL_RENEW:${pkg.id}`,
        clientName: colAcc.id,
        date: new Date().toISOString(),
        description: `تمدید پلن همکاری ${pkg.title || pkg.name} (+${pkg.trafficGb} GB) - ${colAcc.prefix || colAcc.username}`,
        pendingPurchase: {
          planName: `تمدید پلن همکاری ${pkg.title || pkg.name}`,
          packageId: pkg.id,
          colleagueAccountId: colAcc.id,
          finalPrice,
          trafficGb: pkg.trafficGb
        }
      };
      db.transactions.push(newTx);
      writeSqliteDb(db);

      notifyAdminsOnNewReceipt(newTx, db, settings).catch(() => {});

      return res.json({
        success: true,
        pendingApproval: true,
        transactionId: newTx.id,
        message: "رسید تمدید پلن همکاری با موفقیت ثبت شد و پس از تایید مدیریت، سهمیه به حسابتان اضافه خواهد شد."
      });
    }

    return res.status(400).json({ success: false, error: "روش پرداخت نامعتبر است." });
  } catch (err: any) {
    console.error("[Renew Colleague Plan Error]", err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Colleague Create Client (Free for colleague within their allowance)
app.post("/api/miniapp/colleague/create-client", async (req, res) => {
  try {
    const { accountId, serverId, clientUsername, trafficGb, durationDays } = req.body;
    if (!accountId) {
      return res.status(400).json({ success: false, error: "شناسه حساب همکار الزامی است." });
    }

    const db = readSqliteDb();
    const settings = getSystemSettings(db);
    const accounts = db.colleague_accounts || [];
    const acc = accounts.find((a: any) => String(a.id) === String(accountId));

    if (!acc) {
      return res.status(404).json({ success: false, error: "حساب همکار یافت نشد." });
    }

    const reqGb = Math.max(1, Number(trafficGb) || 10);
    const reqDays = Math.max(1, Number(durationDays) || 30);

    // Enforce colleague minimum create GB
    const pkg = (db.colleague_packages || []).find((p: any) => p.id === acc.packageId);
    const minAllowedGb = Number(acc.minCreateGb || acc.min_create_gb || pkg?.minCreateGb || pkg?.min_create_gb || settings.colleagueMinCreateGb || settings.minCreateGb || 0);
    if (minAllowedGb > 0 && reqGb < minAllowedGb) {
      return res.status(400).json({
        success: false,
        error: `حداقل حجم مجاز برای ساخت هر کانفیگ ${minAllowedGb} گیگابایت می‌باشد.`
      });
    }

    // Calculate allowance
    const keys = db.subscription_keys || [];
    const colKeys = keys.filter((k: any) => isKeyForColleague(k, acc));
    const totalPkg = Number(acc.trafficGb || 0);
    const sumAlloc = colKeys.reduce((s: number, k: any) => s + Number(k.trafficLimitGb || 0), 0) + Number(acc.deletedTrafficGb || 0);
    const remainingGb = Math.max(0, totalPkg - sumAlloc);

    if (totalPkg > 0 && reqGb > remainingGb) {
      return res.status(400).json({ 
        success: false, 
        error: `حجم درخواستی (${reqGb} GB) بیشتر از حجم مجاز باقیمانده شما (${remainingGb.toFixed(1)} GB) است.` 
      });
    }

    const prefix = (acc.prefix || "Col").trim();
    const cleanRaw = clientUsername && clientUsername.trim()
      ? clientUsername.trim().replace(/[^a-zA-Z0-9_-]/g, "")
      : `usr_${Math.random().toString(36).substring(2, 8)}`;
    let baseName = cleanRaw;
    if (!baseName.startsWith(prefix + "_") && !baseName.startsWith(prefix)) {
      baseName = `${prefix}_${baseName}`;
    }

    const vpnResult = await addVpnClientApi(
      baseName,
      reqGb,
      reqDays,
      settings,
      undefined,
      serverId,
      false,
      true
    );

    if (!vpnResult.success || !vpnResult.subLink) {
      return res.status(500).json({
        success: false,
        error: "خطا در ساخت کانفیگ همکار: " + (vpnResult.error || "خطای نامشخص در اتصال به سرور")
      });
    }

    const randomSubId = "COL-" + Date.now() + "-" + Math.floor(Math.random() * 9000 + 1000);
    const expireDate = new Date(Date.now() + reqDays * 24 * 60 * 60 * 1000).toISOString().split("T")[0];

    const finalSubLink = buildCorrectSubLinkForClient(vpnResult.subLink || baseName, serverId, settings, db);

    const newSub = {
      id: randomSubId,
      userId: 0,
      user_id: 0,
      colleagueAccountId: acc.id,
      colleagueUsername: acc.username,
      serverId: serverId || "",
      planId: `colleague_pkg_${reqGb}gb`,
      planName: `کانفیگ همکار (${reqGb}GB - ${reqDays} روزه)`,
      clientName: baseName,
      clientUuid: vpnResult.clientUuid || "",
      subLink: finalSubLink,
      vlessConfigs: vpnResult.vlessConfigs || [],
      vlessLinks: vpnResult.vlessLinks || [],
      expireDate,
      trafficLimitGb: reqGb,
      trafficUsedGb: 0,
      createdAtMs: Date.now(),
      status: "active" as const,
    };

    if (!Array.isArray(db.subscription_keys)) db.subscription_keys = [];
    db.subscription_keys.push(newSub);
    writeSqliteDb(db);

    // Notify Admins on colleague client creation
    try {
      const serverObj = (db.servers || []).find((s: any) => String(s.id) === String(serverId));
      const srvName = serverObj?.name || serverObj?.remark || "سرور همکاران";
      const colMsg =
        `🤝 <b>ساخت کانفیگ جدید توسط همکار</b>\n\n` +
        `👤 <b>همکار:</b> ${acc.prefix ? `[${acc.prefix}] ` : ''}${acc.username || acc.name || acc.id}\n` +
        `🌐 <b>سرور:</b> ${srvName}\n` +
        `📦 <b>مشخصات:</b> ${reqGb} گیگابایت (${reqDays} روز)\n` +
        `🔑 <b>نام کلاینت:</b> <code>${baseName}</code>\n` +
        `🔗 <b>لینک ساب:</b>\n<code>${vpnResult.subLink}</code>\n` +
        `⏱ <b>زمان:</b> ${new Date().toLocaleTimeString("fa-IR")} - ${new Date().toLocaleDateString("fa-IR")}`;
      sendAdminNotification(colMsg, settings).catch(() => {});
    } catch (e) {}

    return res.json({
      success: true,
      subKey: newSub,
      client: {
        id: newSub.id,
        clientName: newSub.clientName,
        trafficLimitGb: newSub.trafficLimitGb,
        trafficUsedGb: 0,
        subLink: newSub.subLink,
        vlessConfigs: newSub.vlessConfigs,
        vlessLinks: newSub.vlessLinks,
        expireDate: newSub.expireDate,
        status: "active"
      },
      message: "کانفیگ همکار با موفقیت ایجاد شد."
    });
  } catch (err: any) {
    console.error("[Colleague Create Error]", err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// 2. Promo Code Validator for MiniApp
app.post("/api/miniapp/validate-promo", async (req, res) => {
  try {
    const { code, userId, originalPrice } = req.body;
    if (!code || !code.trim()) {
      return res.status(400).json({ success: false, error: "کد تخفیف را وارد کنید." });
    }

    const cleanCode = code.trim().toUpperCase();
    const db = readSqliteDb();
    const promoCodes = db.promo_codes || [];
    const promo = promoCodes.find((p: any) => (p.code || "").trim().toUpperCase() === cleanCode);

    if (!promo) {
      return res.status(404).json({ success: false, error: "کد تخفیف وارد شده معتبر نیست یا منقضی شده است." });
    }

    // Check server restrictions
    const reqServerId = req.body.serverId || req.body.server_id || req.body.serverIdStr;
    if (Array.isArray(promo.allowedServerIds) && promo.allowedServerIds.length > 0) {
      const allowed = promo.allowedServerIds.map((s: any) => String(s).trim());
      const currentServerIdStr = String(reqServerId || "").trim();
      if (!currentServerIdStr || !allowed.includes(currentServerIdStr)) {
        return res.status(404).json({ success: false, error: "کد تخفیف وجود ندارد یا منقضی شده است." });
      }
    }

    // Check active status
    if (promo.isActive === false || promo.status === "inactive" || promo.status === "disabled") {
      return res.status(400).json({ success: false, error: "این کد تخفیف در حال حاضر غیرفعال می‌باشد." });
    }

    // Check expiry
    let isExpired = false;
    if (promo.expireDate && new Date(promo.expireDate).getTime() < Date.now()) {
      isExpired = true;
    }
    if (promo.expiresAt && new Date(promo.expiresAt).getTime() < Date.now()) {
      isExpired = true;
    }
    if (promo.durationDays && Number(promo.durationDays) > 0 && promo.createdAt) {
      const createdTime = new Date(promo.createdAt).getTime();
      if (!isNaN(createdTime) && Date.now() > (createdTime + Number(promo.durationDays) * 24 * 60 * 60 * 1000)) {
        isExpired = true;
      }
    }
    if (isExpired) {
      return res.status(400).json({ success: false, error: "مهلت زمانی استفاده از این کد تخفیف به پایان رسیده است." });
    }

    // Check max usage
    const usedBy = Array.isArray(promo.usedBy) ? promo.usedBy : (promo.used_by || []);
    if (promo.maxUsage && usedBy.length >= Number(promo.maxUsage)) {
      return res.status(400).json({ success: false, error: "ظرفیت استفاده از این کد تخفیف تکمیل شده است." });
    }

    // Check if user already used this promo code
    if (userId && usedBy.some((uid: any) => Number(uid) === Number(userId))) {
      return res.status(400).json({ success: false, error: "شما قبلاً از این کد تخفیف استفاده کرده‌اید." });
    }

    const price = Number(originalPrice) || 0;
    const pVal = Number(promo.value ?? promo.discountPercent ?? promo.percent ?? promo.discountAmount ?? promo.amount ?? 0);
    let discountAmount = 0;

    if (promo.type === "percent" || promo.discountPercent !== undefined || promo.percent !== undefined) {
      discountAmount = Math.floor((price * pVal) / 100);
    } else if (promo.type === "fixed_amount" || promo.discountAmount !== undefined || promo.amount !== undefined) {
      discountAmount = pVal;
    } else {
      if (pVal > 0 && pVal <= 100) {
        discountAmount = Math.floor((price * pVal) / 100);
      } else {
        discountAmount = pVal;
      }
    }

    discountAmount = Math.min(price, Math.max(0, discountAmount));
    return res.json({
      success: true,
      discountAmount,
      finalPrice: Math.max(0, price - discountAmount),
      promo: {
        code: promo.code,
        type: promo.type || "percent",
        value: pVal,
        discountPercent: promo.discountPercent,
        discountAmount: promo.discountAmount
      }
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3. Purchase Subscription via MiniApp
app.post("/api/miniapp/purchase", async (req, res) => {
  try {
    const {
      userId,
      username,
      serverId,
      planId,
      planName,
      customGb,
      customDays,
      clientUsername,
      paymentMethod,
      promoCode,
      receiptImage
    } = req.body;

    if (!userId || Number(userId) <= 0) {
      return res.status(400).json({ success: false, error: "شناسه کاربری نامعتبر است." });
    }

    const tgId = Number(userId);
    const db = readSqliteDb();
    const settings = getSystemSettings(db);
    if (!Array.isArray(db.users)) db.users = [];

    let user = db.users.find((u: any) => Number(u.userId) === tgId || Number(u.user_id) === tgId);
    if (!user) {
      user = {
        id: tgId,
        userId: tgId,
        user_id: tgId,
        username: username || `user_${tgId}`,
        walletBalance: 0,
        status: "active",
        activePlansCount: 0
      };
      db.users.push(user);
    }

    let selectedPlan: any = null;
    if (planId && planId !== "custom" && planId !== "custom_vol") {
      selectedPlan = (db.vpn_plans || []).find((p: any) => String(p.id).trim() === String(planId).trim());
      if (!selectedPlan && planName) {
        selectedPlan = (db.vpn_plans || []).find((p: any) => p.name === planName);
      }
    }

    const trafficGb = selectedPlan && (selectedPlan.trafficGb || selectedPlan.traffic_limit || selectedPlan.traffic)
      ? Number(selectedPlan.trafficGb || selectedPlan.traffic_limit || selectedPlan.traffic)
      : Math.max(1, Number(customGb) || 30);

    const durationDays = selectedPlan && (selectedPlan.durationDays || selectedPlan.duration_days || selectedPlan.duration)
      ? Number(selectedPlan.durationDays || selectedPlan.duration_days || selectedPlan.duration)
      : Math.max(1, Number(customDays) || 30);

    // Enforce custom pricing min limits if custom plan selected
    if (planId === "custom" || planId === "custom_vol" || (!selectedPlan && customGb)) {
      let minCustomGb = 1;
      let minCustomDays = 1;
      try {
        const pc = typeof settings.panel_config === "string" ? JSON.parse(settings.panel_config) : (settings.panel_config || {});
        const boxes = pc.customPricingBoxes || settings.customPricingBoxes || [];
        const matchingBox = boxes.find((b: any) => Array.isArray(b.serverIds) && b.serverIds.includes(String(serverId)));
        if (matchingBox) {
          if (matchingBox.minGb) minCustomGb = Number(matchingBox.minGb);
          if (matchingBox.minDays) minCustomDays = Number(matchingBox.minDays);
        }
      } catch (e) {}

      if (trafficGb < minCustomGb) {
        return res.status(400).json({
          success: false,
          error: `حداقل حجم مجاز برای این سرور ${minCustomGb} گیگابایت می‌باشد.`
        });
      }
      if (durationDays < minCustomDays) {
        return res.status(400).json({
          success: false,
          error: `حداقل مدت زمان مجاز برای این سرور ${minCustomDays} روز می‌باشد.`
        });
      }
    }

    const effectivePlanName = selectedPlan?.name || planName || `${trafficGb} گیگابایت (${durationDays} روز)`;

    const rawClean = clientUsername ? clientUsername.trim().replace(/[^a-zA-Z0-9_-]/g, "") : "";
    const cleanClientName = rawClean || `usr_${tgId}_${Math.random().toString(36).substring(2, 8)}`;

    // Calculate Original Price
    let originalPrice = 0;
    if (selectedPlan && selectedPlan.price) {
      originalPrice = Number(selectedPlan.price || 0);
    }

    if (originalPrice <= 0) {
      let pricePerGb = 3000;
      let pricePerDay = 2000;
      try {
        const pc = typeof settings.panel_config === "string" ? JSON.parse(settings.panel_config) : (settings.panel_config || {});
        if (pc.pricePerGb) pricePerGb = Number(pc.pricePerGb);
        if (pc.pricePerDay) pricePerDay = Number(pc.pricePerDay);
      } catch (e) {}
      originalPrice = Math.max(5000, trafficGb * pricePerGb + durationDays * pricePerDay);
    }

    // Check Promo Code
    let discountAmount = 0;
    let appliedPromoObj: any = null;
    if (promoCode && String(promoCode).trim()) {
      const pCode = String(promoCode).trim().toUpperCase();
      const promo = (db.promo_codes || []).find((p: any) => (p.code || "").trim().toUpperCase() === pCode);
      if (promo) {
        let isPromoValid = true;
        if (Array.isArray(promo.allowedServerIds) && promo.allowedServerIds.length > 0) {
          const allowed = promo.allowedServerIds.map((s: any) => String(s).trim());
          const currentServerIdStr = String(serverId || "").trim();
          if (!currentServerIdStr || !allowed.includes(currentServerIdStr)) {
            isPromoValid = false;
          }
        }
        if (promo.isActive === false || promo.status === "inactive" || promo.status === "disabled") {
          isPromoValid = false;
        }
        if (promo.expireDate && new Date(promo.expireDate).getTime() < Date.now()) {
          isPromoValid = false;
        }
        if (promo.expiresAt && new Date(promo.expiresAt).getTime() < Date.now()) {
          isPromoValid = false;
        }
        if (promo.durationDays && Number(promo.durationDays) > 0 && promo.createdAt) {
          const createdTime = new Date(promo.createdAt).getTime();
          if (!isNaN(createdTime) && Date.now() > (createdTime + Number(promo.durationDays) * 24 * 60 * 60 * 1000)) {
            isPromoValid = false;
          }
        }
        const usedBy = Array.isArray(promo.usedBy) ? promo.usedBy : (promo.used_by || []);
        if (promo.maxUsage && usedBy.length >= Number(promo.maxUsage)) {
          isPromoValid = false;
        }
        if (tgId && usedBy.some((uid: any) => Number(uid) === Number(tgId))) {
          isPromoValid = false;
        }

        if (isPromoValid) {
          appliedPromoObj = promo;
          const pVal = Number(promo.value ?? promo.discountPercent ?? promo.percent ?? promo.discountAmount ?? promo.amount ?? 0);
          if (promo.type === "percent" || promo.discountPercent !== undefined || promo.percent !== undefined) {
            discountAmount = Math.floor((originalPrice * pVal) / 100);
          } else if (promo.type === "fixed_amount" || promo.discountAmount !== undefined || promo.amount !== undefined) {
            discountAmount = pVal;
          } else {
            if (pVal > 0 && pVal <= 100) {
              discountAmount = Math.floor((originalPrice * pVal) / 100);
            } else {
              discountAmount = pVal;
            }
          }
          discountAmount = Math.min(originalPrice, Math.max(0, discountAmount));
        }
      }
    }

    // Check if user is an Admin or Owner
    const roleCheck = checkUserRoleAndAdmin(tgId, username, settings, db);
    const isAdmin = roleCheck.isAdmin;

    // If user is Admin or selects admin_free mode, price is 0 and instant create
    const isFreeAdminPurchase = isAdmin && (paymentMethod === "admin_free" || paymentMethod === "wallet" || paymentMethod === "card_to_card");
    const finalPrice = isFreeAdminPurchase ? 0 : Math.max(0, originalPrice - discountAmount);

    // ==========================================
    // PAYMENT METHOD: ADMIN FREE CREATION
    // ==========================================
    if (isFreeAdminPurchase || paymentMethod === "admin_free") {
      // Auto-create client on 3x-ui / Rebecca / Marzban with 0 cost
      const vpnResult = await addVpnClientApi(
        cleanClientName,
        trafficGb,
        durationDays,
        settings,
        undefined,
        serverId,
        false,
        true
      );

      if (!vpnResult.success || !vpnResult.subLink) {
        return res.status(200).json({
          success: false,
          error: "خطا در ساخت کانفیگ روی سرور: " + (vpnResult.error || "پاسخی از پنل سرور دریافت نشد.")
        });
      }

      // Generate Subscription Record in DB
      const randomSubId = "ADMIN-" + Date.now() + "-" + Math.floor(Math.random() * 90000 + 10000);
      const expireDate = new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000).toISOString().split("T")[0];

      const newSub = {
        id: randomSubId,
        userId: tgId,
        user_id: tgId,
        serverId: serverId || "",
        planId: planId || "admin_plan_" + Date.now(),
        planName: `${planName} (👑 ویژه مدیر کل)`,
        clientName: cleanClientName,
        clientUuid: vpnResult.clientUuid || "",
        subLink: vpnResult.subLink,
        vlessConfigs: vpnResult.vlessConfigs || [],
        vlessLinks: vpnResult.vlessLinks || [],
        expireDate,
        trafficLimitGb: trafficGb,
        trafficUsedGb: 0,
        createdAtMs: Date.now(),
        status: "active" as const,
      };

      if (!Array.isArray(db.subscription_keys)) db.subscription_keys = [];
      db.subscription_keys.push(newSub);

      // Record Transaction with 0 cost
      if (!Array.isArray(db.transactions)) db.transactions = [];
      const newTx = {
        id: "TX-ADM-" + Date.now() + "-" + Math.floor(Math.random() * 9000 + 1000),
        userId: tgId,
        username: user.username || username || `admin_${tgId}`,
        amount: 0,
        status: "approved",
        type: "admin_free",
        date: new Date().toISOString(),
        description: `ساخت رایگان کانفیگ ${planName} (ویژه ادمین/مدیریت)`
      };
      db.transactions.push(newTx);

      // Update user active count
      user.activePlansCount = db.subscription_keys.filter((k: any) => Number(k.userId) === tgId && k.status === "active").length;
      writeSqliteDb(db);

      // Notify Owner and Admins
      try {
        const serverObj = (db.servers || []).find((s: any) => String(s.id) === String(serverId));
        const srvName = serverObj?.name || serverObj?.remark || "سرور اختصاصی";
        const purchaseAdminMsg = 
          `👑 <b>سفارش ویژه مدیریت (از مینی‌اپ)</b>\n\n` +
          `👤 <b>کاربر:</b> @${String(user.username || username || tgId).replace(/^@/, '')} (<code>${tgId}</code>)\n` +
          `📦 <b>پلن:</b> ${planName}\n` +
          `🌐 <b>سرور:</b> ${srvName}\n` +
          `🔑 <b>نام کانفیگ:</b> <code>${cleanClientName}</code>\n` +
          `🔗 <b>لینک ساب:</b>\n<code>${vpnResult.subLink}</code>\n` +
          `⏱ <b>زمان:</b> ${new Date().toLocaleTimeString("fa-IR")} - ${new Date().toLocaleDateString("fa-IR")}`;
        sendAdminNotification(purchaseAdminMsg, settings).catch(() => {});
      } catch (e) {}

      return res.json({
        success: true,
        subKey: newSub,
        user: {
          walletBalance: user.walletBalance,
          activePlansCount: user.activePlansCount,
          isAdmin: true
        }
      });
    }

    // ==========================================
    // PAYMENT METHOD 1: WALLET
    // ==========================================
    if (paymentMethod === "wallet") {
      const userBalance = Number(user.walletBalance || user.wallet_balance || user.balance || 0);
      if (userBalance < finalPrice) {
        return res.status(400).json({
          success: false,
          error: `موجودی کیف پول شما کافی نیست. موجودی: ${userBalance.toLocaleString("fa-IR")} تومان | مبلغ فاکتور: ${finalPrice.toLocaleString("fa-IR")} تومان`
        });
      }

      // Deduct balance
      user.walletBalance = userBalance - finalPrice;
      user.wallet_balance = user.walletBalance;
      user.balance = user.walletBalance;

      // Auto-create client on 3x-ui / Rebecca / Marzban
      const vpnResult = await addVpnClientApi(
        cleanClientName,
        trafficGb,
        durationDays,
        settings,
        undefined,
        serverId,
        false
      );

      if (!vpnResult.success || !vpnResult.subLink) {
        // Refund wallet balance on error
        user.walletBalance += finalPrice;
        user.wallet_balance = user.walletBalance;
        user.balance = user.walletBalance;
        writeSqliteDb(db);

        return res.status(200).json({
          success: false,
          error: "خطا در ساخت کانفیگ روی سرور: " + (vpnResult.error || "پاسخی از پنل سرور دریافت نشد.")
        });
      }

      // Generate Subscription Record in DB
      const randomSubId = "SUB-" + Date.now() + "-" + Math.floor(Math.random() * 90000 + 10000);
      const expireDate = new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000).toISOString().split("T")[0];

      const newSub = {
        id: randomSubId,
        userId: tgId,
        user_id: tgId,
        serverId: serverId || "",
        planId: planId || "plan_" + Date.now(),
        planName,
        clientName: cleanClientName,
        clientUuid: vpnResult.clientUuid || "",
        subLink: vpnResult.subLink,
        vlessConfigs: vpnResult.vlessConfigs || [],
        vlessLinks: vpnResult.vlessLinks || [],
        expireDate,
        trafficLimitGb: trafficGb,
        trafficUsedGb: 0,
        createdAtMs: Date.now(),
        status: "active" as const,
      };

      if (!Array.isArray(db.subscription_keys)) db.subscription_keys = [];
      db.subscription_keys.push(newSub);

      // Record Transaction
      if (!Array.isArray(db.transactions)) db.transactions = [];
      const newTx = {
        id: "TX-PUR-" + Date.now() + "-" + Math.floor(Math.random() * 9000 + 1000),
        userId: tgId,
        username: user.username || username || `user_${tgId}`,
        amount: finalPrice,
        status: "approved",
        type: "purchase",
        date: new Date().toISOString(),
        description: `خرید اشتراک ${planName} از طریق مینی‌اپ تلگرام`
      };
      db.transactions.push(newTx);

      // Record Promo usage
      if (appliedPromoObj) {
        if (!Array.isArray(appliedPromoObj.usedBy)) appliedPromoObj.usedBy = [];
        appliedPromoObj.usedBy.push(tgId);
        appliedPromoObj.totalUsage = (appliedPromoObj.totalUsage || 0) + 1;
      }

      // Update user active count
      user.activePlansCount = db.subscription_keys.filter((k: any) => Number(k.userId) === tgId && k.status === "active").length;

      writeSqliteDb(db);

      // Notify Owner and Admins
      try {
        const serverObj = (db.servers || []).find((s: any) => String(s.id) === String(serverId));
        const srvName = serverObj?.name || serverObj?.remark || "سرور عمومی";
        const purchaseAdminMsg = 
          `🛍️ <b>خرید موفق اشتراک جدید (از مینی‌اپ)</b>\n\n` +
          `👤 <b>کاربر:</b> @${String(user.username || username || tgId).replace(/^@/, '')} (<code>${tgId}</code>)\n` +
          `📦 <b>پلن:</b> ${planName}\n` +
          `🌐 <b>سرور:</b> ${srvName}\n` +
          `💰 <b>مبلغ فاکتور:</b> ${finalPrice.toLocaleString("fa-IR")} تومان\n` +
          `🔑 <b>نام کانفیگ:</b> <code>${cleanClientName}</code>\n` +
          `🔗 <b>لینک ساب:</b>\n<code>${vpnResult.subLink}</code>\n` +
          `⏱ <b>زمان:</b> ${new Date().toLocaleTimeString("fa-IR")} - ${new Date().toLocaleDateString("fa-IR")}`;
        sendAdminNotification(purchaseAdminMsg, settings).catch(() => {});
      } catch (e) {}

      return res.json({
        success: true,
        subKey: newSub,
        user: {
          walletBalance: user.walletBalance,
          activePlansCount: user.activePlansCount
        }
      });
    }

    // ==========================================
    // PAYMENT METHOD 2: CARD TO CARD
    // ==========================================
    if (paymentMethod === "card_to_card") {
      if (!Array.isArray(db.transactions)) db.transactions = [];
      const newTx = {
        id: "TX-CARD-" + Date.now() + "-" + Math.floor(Math.random() * 9000 + 1000),
        userId: tgId,
        username: user.username || username || `user_${tgId}`,
        amount: finalPrice,
        receiptImage: receiptImage || "",
        status: "pending",
        type: "PLAN_PURCHASE",
        planId: planId || "custom",
        serverId: serverId || "",
        clientName: cleanClientName,
        customGb: trafficGb,
        customDays: durationDays,
        date: new Date().toISOString(),
        description: `خرید اشتراک ${effectivePlanName} (کارت به کارت)`,
        pendingPurchase: {
          serverId: serverId || "",
          planId: planId || "custom",
          customGb: trafficGb,
          customDays: durationDays,
          clientUsername: cleanClientName,
          clientName: cleanClientName,
          promoCode,
          finalPrice,
          planName: effectivePlanName
        }
      };
      db.transactions.push(newTx);
      writeSqliteDb(db);

      // Send instant Telegram notification to all Bot Admins
      notifyAdminsOnNewReceipt(newTx, db, settings).catch((err) => {
        console.warn("[Admin Notification Warning]", err);
      });

      return res.json({
        success: true,
        pendingApproval: true,
        transactionId: newTx.id,
        message: "رسید شما با موفقیت ثبت شد و پس از بررسی و تایید مدیریت، سرویس شما فعال خواهد شد."
      });
    }

    return res.status(400).json({ success: false, error: "روش پرداخت انتخاب شده نامعتبر است." });
  } catch (error: any) {
    console.error("[MiniApp Purchase Error]:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// 4. Free Test Config via MiniApp
app.post("/api/miniapp/free-test", async (req, res) => {
  try {
    const { userId, username, serverId } = req.body;
    if (!userId || Number(userId) <= 0) {
      return res.status(400).json({ success: false, error: "شناسه کاربری نامعتبر است." });
    }

    const tgId = Number(userId);
    const db = readSqliteDb();
    const settings = getSystemSettings(db);

    const isFreeTestEnabled = settings.isFreeTestActive !== false && settings.isTestAccountActive !== false && settings.IS_FREETEST_ACTIVE !== false;
    const freeTestDisabledMsg = settings.freeTestDisabledMessage || settings.FREETEST_DISABLED_MSG || "اکانت تست رایگان فعلا موجود نیست.";

    if (!isFreeTestEnabled) {
      return res.status(400).json({ success: false, error: freeTestDisabledMsg });
    }

    const roleCheck = checkUserRoleAndAdmin(tgId, username, settings, db);
    const isOwner = roleCheck.isOwner;
    const isAdmin = roleCheck.isAdmin;

    // Check if user already used test
    const subs = db.subscription_keys || [];
    const users = db.users || [];
    const existingUser = users.find((u: any) => Number(u.userId) === tgId);
    const hasUsed = (existingUser && existingUser.hasReceivedFreeTest) || subs.some((k: any) =>
      Number(k.userId) === tgId && (k.isTest || (k.planName || "").includes("تست") || (k.planId || "").includes("test"))
    );

    if (hasUsed && !isAdmin) {
      return res.status(400).json({
        success: false,
        error: "❌ شما قبلاً اکانت تست رایگان خود را دریافت کرده‌اید!\nهر کاربر تنها یکبار مجاز به دریافت تست رایگان می‌باشد."
      });
    }

    const testGb = Number(
      settings.freeTestGb !== undefined
        ? settings.freeTestGb
        : settings.FREE_TEST_GB !== undefined
        ? settings.FREE_TEST_GB
        : settings.testTrafficGb !== undefined
        ? settings.testTrafficGb
        : 0.1
    );
    const testDays = Number(
      settings.freeTestDays !== undefined
        ? settings.freeTestDays
        : settings.FREE_TEST_DAYS !== undefined
        ? settings.FREE_TEST_DAYS
        : settings.testDurationHours
        ? settings.testDurationHours / 24
        : 1
    );
    const testHours = Math.round(testDays * 24);

    const rawServers = getActiveServers(settings);
    // Priority: 1) Admin-designated freeTestServerId, 2) Requested serverId, 3) First active public server
    let targetServerId = settings.freeTestServerId || settings.FREE_TEST_SERVER_ID || serverId;
    if (targetServerId && !rawServers.some((s: any) => String(s.id).trim() === String(targetServerId).trim())) {
      targetServerId = rawServers.length > 0 ? rawServers[0].id : undefined;
    }
    if (!targetServerId && rawServers.length > 0) {
      targetServerId = rawServers[0].id;
    }

    const randomSuffix = Math.random().toString(36).substring(2, 6);
    const cleanClientName = `test_${tgId}_${randomSuffix}`;

    const vpnResult = await addVpnClientApi(
      cleanClientName,
      testGb,
      testDays,
      settings,
      undefined,
      targetServerId,
      false,
      true
    );

    if (!vpnResult.success || !vpnResult.subLink) {
      return res.status(200).json({
        success: false,
        error: "خطا در ساخت کانفیگ تست: " + (vpnResult.error || "خطای نامشخص در اتصال به سرور.")
      });
    }

    const randomSubId = "TEST-" + Date.now();
    const expireDate = new Date(Date.now() + testDays * 24 * 60 * 60 * 1000).toISOString().split("T")[0];

    const freeGbStr = testGb < 1 ? `${Math.round(testGb * 1024)} مگابایت` : `${testGb} گیگابایت`;
    const freeDaysStr = testDays === Math.floor(testDays) ? `${Math.floor(testDays)} روزه` : `${testDays} روزه`;

    const targetServerObj = rawServers.find((s: any) => String(s.id).trim() === String(targetServerId).trim());

    const newSub = {
      id: randomSubId,
      userId: tgId,
      user_id: tgId,
      serverId: targetServerId || "",
      serverName: targetServerObj ? (targetServerObj.name || targetServerObj.remark) : "سرور عمومی",
      serverFlag: targetServerObj ? mapServerFormat(targetServerObj).flag : "🌐",
      planId: "free_test",
      planName: `کانفیگ تست رایگان (${freeGbStr} - ${freeDaysStr})`,
      clientName: cleanClientName,
      clientUuid: vpnResult.clientUuid || "",
      subLink: vpnResult.subLink,
      vlessConfigs: vpnResult.vlessConfigs || [],
      vlessLinks: vpnResult.vlessLinks || [],
      expireDate,
      trafficLimitGb: testGb,
      trafficUsedGb: 0,
      createdAtMs: Date.now(),
      status: "active" as const,
      isTest: true
    };

    if (!Array.isArray(db.subscription_keys)) db.subscription_keys = [];
    db.subscription_keys.push(newSub);

    if (Array.isArray(db.users)) {
      const uIdx = db.users.findIndex((u: any) => Number(u.userId) === tgId);
      if (uIdx >= 0) {
        db.users[uIdx].hasReceivedFreeTest = true;
        db.users[uIdx].activePlansCount = (db.users[uIdx].activePlansCount || 0) + 1;
      }
    }

    writeSqliteDb(db);

    // Notify Owner and Admins
    try {
      const freeTestAdminMsg = 
        `🎁 <b>دریافت اکانت تست رایگان (از مینی‌اپ)</b>\n\n` +
        `👤 <b>کاربر:</b> @${String(username || tgId).replace(/^@/, '')} (<code>${tgId}</code>)\n` +
        `🌐 <b>سرور:</b> ${targetServerObj ? (targetServerObj.name || targetServerObj.remark) : "سرور تست"}\n` +
        `📦 <b>مشخصات پلن:</b> ${freeGbStr} (${freeDaysStr})\n` +
        `🔑 <b>نام کلاینت:</b> <code>${cleanClientName}</code>\n` +
        `🔗 <b>لینک ساب:</b>\n<code>${vpnResult.subLink}</code>\n` +
        `⏱ <b>زمان:</b> ${new Date().toLocaleTimeString("fa-IR")} - ${new Date().toLocaleDateString("fa-IR")}`;
      sendAdminNotification(freeTestAdminMsg, settings).catch(() => {});
    } catch (e) {}

    res.json({ success: true, subKey: newSub, message: "اکانت تست رایگان با موفقیت فعال شد." });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 5. Wallet Deposit via MiniApp (Card to Card)
app.post("/api/miniapp/wallet/deposit", async (req, res) => {
  try {
    const { userId, username, amount, receiptImage } = req.body;
    if (!userId || !amount || Number(amount) <= 0) {
      return res.status(400).json({ success: false, error: "اطلاعات واریز نامعتبر است." });
    }

    const tgId = Number(userId);
    const db = readSqliteDb();
    const settings = getSystemSettings(db);

    if (!Array.isArray(db.transactions)) db.transactions = [];
    const newTx = {
      id: "TX-DEP-" + Date.now() + "-" + Math.floor(Math.random() * 9000 + 1000),
      userId: tgId,
      username: username || `user_${tgId}`,
      amount: Number(amount),
      receiptImage: receiptImage || "",
      status: "pending",
      type: "charge",
      date: new Date().toISOString(),
      description: `درخواست شارژ حساب کاربری (${Number(amount).toLocaleString("fa-IR")} تومان)`
    };

    db.transactions.push(newTx);
    writeSqliteDb(db);

    // Send instant Telegram notification to all Bot Admins
    notifyAdminsOnNewReceipt(newTx, db, settings).catch((err) => {
      console.warn("[Admin Notification Warning - Wallet Deposit]", err);
    });

    res.json({
      success: true,
      transactionId: newTx.id,
      message: "رسید پرداخت با موفقیت ثبت شد و پس از بررسی توسط تیم پشتیبانی، حساب شما شارژ خواهد شد."
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 6. Create Support Ticket from MiniApp
const handleCreateTicketMiniApp = async (req: any, res: any) => {
  try {
    const { userId, username, subject, message } = req.body;
    if (!userId || !message || !message.trim()) {
      return res.status(400).json({ success: false, error: "متن تیکت نمی‌تواند خالی باشد." });
    }

    const tgId = Number(userId);
    const db = readSqliteDb();

    const newTicket = {
      id: "TCK-" + Date.now() + "-" + Math.floor(Math.random() * 900 + 100),
      userId: tgId,
      username: username || `user_${tgId}`,
      subject: subject || "پشتیبانی سرویس",
      status: "open",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: [
        {
          id: "MSG-1",
          sender: "user",
          senderName: username || `کاربر ${tgId}`,
          text: message.trim(),
          timestamp: new Date().toISOString()
        }
      ]
    };

    if (!Array.isArray(db.tickets)) db.tickets = [];
    db.tickets.push(newTicket);
    writeSqliteDb(db);

    // Notify Admin on Telegram
    const settings = getSystemSettings(db);
    const notifyMsg =
      `🎫 <b>تیکت جدید از مینی‌اپ:</b>\n\n` +
      `👤 <b>کاربر:</b> ${username ? "@" + username.replace(/^@/, '') : `کاربر (${tgId})`} (<code>${tgId}</code>)\n` +
      `🆔 <b>شناسه تیکت:</b> <code>${newTicket.id}</code>\n` +
      `📌 <b>موضوع:</b> ${newTicket.subject}\n\n` +
      `💬 <b>متن پیام:</b>\n${message.trim()}\n\n` +
      `⏱ <b>زمان:</b> ${new Date().toLocaleTimeString("fa-IR")} - ${new Date().toLocaleDateString("fa-IR")}`;

    sendAdminNotification(notifyMsg, settings).catch(() => {});

    res.json({ success: true, ticket: newTicket });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
};

app.post("/api/miniapp/tickets/create", handleCreateTicketMiniApp);
app.post("/api/miniapp/tickets/send", handleCreateTicketMiniApp);
app.post("/api/miniapp/ticket/create", handleCreateTicketMiniApp);
app.post("/api/miniapp/ticket/send", handleCreateTicketMiniApp);

// 7. Reply to Ticket from MiniApp
const handleReplyTicketMiniApp = async (req: any, res: any) => {
  try {
    const { ticketId, userId, message } = req.body;
    if (!ticketId || !message || !message.trim()) {
      return res.status(400).json({ success: false, error: "متن پیام نامعتبر است." });
    }

    const db = readSqliteDb();
    const tickets = db.tickets || [];
    const ticket = tickets.find((t: any) => String(t.id) === String(ticketId));

    if (!ticket) {
      return res.status(404).json({ success: false, error: "تیکت یافت نشد." });
    }

    if (!Array.isArray(ticket.messages)) ticket.messages = [];
    const newMsg = {
      id: "MSG-" + (ticket.messages.length + 1),
      sender: "user",
      senderName: ticket.username || `کاربر ${userId}`,
      text: message.trim(),
      timestamp: new Date().toISOString()
    };
    ticket.messages.push(newMsg);
    ticket.status = "open";

    writeSqliteDb(db);

    // Notify Admins on User Reply
    const settings = getSystemSettings(db);
    const replyNotifyMsg =
      `💬 <b>پاسخ جدید کاربر به تیکت (مینی‌اپ)</b>\n\n` +
      `👤 <b>کاربر:</b> ${ticket.username ? "@" + ticket.username.replace(/^@/, '') : `کاربر (${userId})`} (<code>${userId}</code>)\n` +
      `🆔 <b>شناسه تیکت:</b> <code>${ticket.id}</code>\n` +
      `📌 <b>موضوع:</b> ${ticket.subject}\n\n` +
      `📝 <b>متن پاسخ:</b>\n${message.trim()}`;

    sendAdminNotification(replyNotifyMsg, settings).catch(() => {});

    res.json({ success: true, ticket: sanitizeTicketsList([ticket])[0] });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
};

app.post("/api/miniapp/tickets/reply", handleReplyTicketMiniApp);
app.post("/api/miniapp/ticket/reply", handleReplyTicketMiniApp);

// Dynamic VPN Plans Management & Purchase logic
// [EXTRACTED → src/routes/admin.ts] vpn-plans CRUD


app.post("/api/vpn-plans/buy", async (req, res) => {
  try {
    const { planId, userId, clientName } = req.body;
    const db = readSqliteDb();
    if (!db.vpn_plans) db.vpn_plans = [];

    const planIdx = db.vpn_plans.findIndex((p) => p.id === planId);
    if (planIdx === -1) {
      return res
        .status(404)
        .json({ success: false, error: "پلن مورد نظر یافت نشد." });
    }
    const plan = db.vpn_plans[planIdx];

    const userIdx = db.users.findIndex((u) => u.userId === Number(userId));
    if (userIdx === -1) {
      return res.status(404).json({ success: false, error: "کاربر یافت نشد." });
    }
    const user = db.users[userIdx];

    const settings = getSystemSettings(db);

    const ownerId = Number(settings.ownerId || 6536288293);
    const admins = Array.isArray(settings.admins) ? settings.admins : [];
    const isAdminOrOwner =
      Number(userId) === ownerId ||
      admins.some((adm: any) => Number(adm.userId) === Number(userId)) ||
      user.username === "daltoon_owner";

    if (!isAdminOrOwner && user.walletBalance < plan.price) {
      return res
        .status(400)
        .json({ success: false, error: "موجودی کیف پول شما کافی نیست." });
    }

    const cleanClientName = (
      clientName || "user_" + Math.random().toString(36).substring(2, 7)
    )
      .trim()
      .replace(/\s+/g, "");

    const isMockSimulator =
      req.body.isSimulator === true || req.body.isSimulator === "true";
    let subLink = "";
    let clientUuid = "";
    if (isMockSimulator) {
      subLink = `vless://${cleanClientName}_test_id@m.daltoon-server.ir:2052?security=reality&sni=google.com&fp=chrome#Daltoon_${cleanClientName}_Test`;
    } else if (settings.panelConnectionActive) {
      console.log(
        `[Buy API] Connection active, creating user '${cleanClientName}' on panel...`,
      );
      const apiResult = await addVpnClientApi(
        cleanClientName,
        plan.trafficGb,
        plan.durationDays,
        settings,
      );
      if (apiResult.success && apiResult.subLink) {
        subLink = apiResult.subLink;
        clientUuid = apiResult.clientUuid || "";
      } else {
        const buyPanelLabel = settings.panelType === "dui" ? "پنل دالتون (D-UI)" : "پنل ۳x-ui";
        return res.status(400).json({
          success: false,
          error:
            `ساخت کلاینت در ${buyPanelLabel} با خطا مواجه شد: ` +
            (apiResult.error || "خطای نامشخص"),
        });
      }
    } else {
      if (!plan.configStock || plan.configStock.length === 0) {
        return res.status(400).json({
          success: false,
          error:
            "این پلن در حال حاضر فاقد کانفیگ در انبار است. ابتدا انبار آن را در بخش مدیریت سرور شارژ کنید.",
        });
      }
      subLink = plan.configStock.shift() || "";
    }

    // Create subscription key
    const randomId = "SUB-" + Date.now() + "-" + Math.floor(Math.random() * 90000 + 10000);
    const planDays = Number(plan.durationDays) || 30;
    const expireTimestamp = Date.now() + planDays * 24 * 60 * 60 * 1000;
    const expireDate = isNaN(expireTimestamp)
      ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
          .toISOString()
          .split("T")[0]
      : new Date(expireTimestamp).toISOString().split("T")[0];

    const newSub = {
      id: randomId,
      userId: Number(userId),
      planId: plan.id,
      planName: plan.name,
      clientName: cleanClientName,
      clientUuid: clientUuid,
      subLink: subLink,
      expireDate: expireDate,
      trafficLimitGb: plan.trafficGb,
      trafficUsedGb: 0,
      createdAtMs: Date.now(),
      status: "active" as const,
    };

    db.subscription_keys.push(newSub);

    // Deduct wallet balance
    if (!isAdminOrOwner) {
      user.walletBalance -= plan.price;
    }
    user.activePlansCount = db.subscription_keys.filter(
      (k) => k.userId === Number(userId) && k.status === "active",
    ).length;

    writeSqliteDb(db);

    res.json({
      success: true,
      subKey: newSub,
      userWalletBalance: user.walletBalance,
      vpnPlans: db.vpn_plans,
      subscriptionKeys: db.subscription_keys,
      users: db.users,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 8. Dashboard login endpoint with session generation & brute-force rate-limiting
app.post("/api/login", async (req, res) => {
  try {
    const clientIp = getClientIp(req);
    const rateLimit = checkLoginRateLimit(clientIp);
    if (rateLimit.isBlocked) {
      return res.status(429).json({
        success: false,
        message: `تعداد تلاش‌های ناموفق بیش از حد مجاز است. به دلایل امنیتی، ورود به مدت ${rateLimit.remainingMinutes || 15} دقیقه قفل موقت شده است.`,
      });
    }

    const { username, password } = req.body || {};
    if (!username || !password || typeof username !== "string" || typeof password !== "string") {
      return res.status(400).json({
        success: false,
        message: "لطفاً نام کاربری و کلمه عبور را وارد کنید.",
      });
    }

    const cleanUser = username.trim();
    const cleanPass = password.trim();

    const db = readSqliteDb();
    const settings = getSystemSettings(db);

    const dbUser = String(settings.dashboardUsername || "Daltoon").trim();
    const dbPass = String(settings.dashboardPassword || "Daltoon10").trim();
    const dbAdmins = Array.isArray(settings.admins) ? settings.admins : [];

    // Check main super admin credentials
    const isMainAdmin = cleanUser.toLowerCase() === dbUser.toLowerCase() && cleanPass === dbPass;

    // Check registered sub-admins with their dedicated password (or fallback dashboardPassword)
    const matchedSubAdmin = dbAdmins.find(
      (adm: any) => adm && typeof adm.username === "string" && adm.username.trim().toLowerCase() === cleanUser.toLowerCase(),
    );
    const isSubAdmin = !!(
      matchedSubAdmin &&
      ((matchedSubAdmin.password && cleanPass === String(matchedSubAdmin.password).trim()) ||
        cleanPass === dbPass)
    );

    if (isMainAdmin || isSubAdmin) {
      resetFailedLogins(clientIp);

      const userRole = isMainAdmin
        ? "super_admin"
        : matchedSubAdmin?.role || "admin";

      const session = createAdminSession(cleanUser, userRole, req);

      // Set secure HttpOnly session cookie
      res.setHeader(
        "Set-Cookie",
        `daltoon_session=${session.token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${7 * 24 * 60 * 60}`,
      );

      return res.json({
        success: true,
        token: session.token,
        user: {
          username: cleanUser,
          role: userRole,
        },
      });
    } else {
      const lockCheck = recordFailedLogin(clientIp);
      if (lockCheck.isNowBlocked) {
        return res.status(429).json({
          success: false,
          message: "تعداد تلاش‌های ناموفق بیش از حد مجاز (۵ بار) شد. دسترسی موقتاً به مدت ۱۵ دقیقه مسدود شد.",
        });
      }

      return res.status(401).json({
        success: false,
        message: "نام کاربری یا رمز عبور اشتباه است.",
      });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Admin session verification endpoint
app.get("/api/auth/verify", requireAdminAuth, (req, res) => {
  const adminUser = (req as any).adminUser;
  res.json({
    success: true,
    authenticated: true,
    user: {
      username: adminUser?.username || "Admin",
      role: adminUser?.role || "admin",
    },
  });
});

// Admin logout endpoint
app.post("/api/logout", (req, res) => {
  try {
    const token = getAdminTokenFromRequest(req);
    if (token) {
      destroyAdminSession(token);
    }
    res.setHeader(
      "Set-Cookie",
      "daltoon_session=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; SameSite=Lax",
    );
    res.json({ success: true, message: "با موفقیت خارج شدید." });
  } catch (e: any) {
    res.json({ success: true });
  }
});

// X. Backup Management endpoints
app.get("/api/backup-download", requireAdminAuth, (req, res) => {
  try {
    const db = readSqliteDb();

    // Compress and optimize binary-like image strings inside the database to keep backups tiny
    if (db.transactions && Array.isArray(db.transactions)) {
      db.transactions = db.transactions.map((t: any) => {
        if (
          t.receiptImage &&
          t.receiptImage.length > 500 &&
          t.receiptImage.startsWith("data:")
        ) {
          return { ...t, receiptImage: "placeholder_cleared" };
        }
        return t;
      });
    }

    res.setHeader(
      "Content-Disposition",
      "attachment; filename=Daltoon_Bot.json",
    );
    res.setHeader("Content-Type", "application/json");
    res.send(JSON.stringify(db, null, 2));
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/backup-restore", requireAdminAuth, express.json({ limit: "250mb" }), (req, res) => {

  try {
    const { backupData } = req.body;
    if (!backupData) {
      return res
        .status(400)
        .json({ success: false, error: "فایل بکاپ ارسال نشد." });
    }

    let parsed: any = null;

    if (typeof backupData === "object" && backupData !== null) {
      parsed = backupData;
    } else if (typeof backupData === "string") {
      let str = backupData.trim();

      // Handle Data URL format (data:application/octet-stream;base64,... or data:application/json;base64,...)
      if (str.startsWith("data:")) {
        const base64Marker = ";base64,";
        const base64Index = str.indexOf(base64Marker);
        if (base64Index !== -1) {
          const rawBase64 = str.substring(base64Index + base64Marker.length);
          const buf = Buffer.from(rawBase64, "base64");
          
          if (buf.length > 16 && buf.toString("latin1", 0, 15).includes("SQLite format 3")) {
            try {
              parsed = extractDbFromSqliteBuffer(buf);
            } catch (err: any) {
              return res.status(400).json({ success: false, error: `خطا در خواندن فایل دیتابیس SQLite: ${err.message}` });
            }
          } else {
            str = buf.toString("utf-8").trim();
          }
        }
      }

      // Handle raw Base64 SQLite binary (starts with U1FMaXRlIGZvcm1hdCAz)
      if (!parsed && (str.startsWith("U1FMaXRl") || str.includes("SQLite format 3"))) {
        try {
          const buf = str.startsWith("U1FMaXRl") ? Buffer.from(str, "base64") : Buffer.from(str, "latin1");
          if (buf.length > 16 && buf.toString("latin1", 0, 15).includes("SQLite format 3")) {
            parsed = extractDbFromSqliteBuffer(buf);
          }
        } catch (err: any) {
          console.warn("[Backup Restore] Base64/Binary SQLite parse failed, trying JSON fallback:", err.message);
        }
      }

      // Standard JSON parsing
      if (!parsed && str) {
        try {
          const cleanString = str.replace(/^\uFEFF/, "");
          parsed = JSON.parse(cleanString);
        } catch (e) {
          try {
            parsed = JSON.parse(JSON.parse(str));
          } catch (e2) {}
        }
      }
    }

    if (!parsed || typeof parsed !== "object") {
      return res.status(400).json({
        success: false,
        error: "فرمت فایل بکاپ معتبر نیست (باید فایل JSON یا SQLite .db معتبر باشد).",
      });
    }

    // Unwrap nested objects if present
    if (parsed.kv && typeof parsed.kv === "object" && !Array.isArray(parsed.kv)) {
      parsed = parsed.kv;
    } else if (parsed.data && typeof parsed.data === "object" && !Array.isArray(parsed.data)) {
      parsed = parsed.data;
    } else if (parsed.db && typeof parsed.db === "object" && !Array.isArray(parsed.db)) {
      parsed = parsed.db;
    } else if (Array.isArray(parsed)) {
      const kvObj: any = {};
      for (const item of parsed) {
        if (item && item.key) {
          try {
            kvObj[item.key] = typeof item.value === "string" ? JSON.parse(item.value) : item.value;
          } catch (e) {
            kvObj[item.key] = item.value;
          }
        }
      }
      if (Object.keys(kvObj).length > 0) {
        parsed = kvObj;
      }
    }

    // Preserve current active critical settings if they are customized
    let preservedConfig: any = {};
    try {
      const currentDb = readSqliteDb();
      if (currentDb && currentDb.settings && currentDb.settings.panel_config) {
        const pc =
          typeof currentDb.settings.panel_config === "string"
            ? JSON.parse(currentDb.settings.panel_config)
            : currentDb.settings.panel_config;
        if (pc.dashboardUsername && pc.dashboardUsername !== "Daltoon") {
          preservedConfig.dashboardUsername = pc.dashboardUsername;
        }
        if (pc.dashboardPassword && pc.dashboardPassword !== "Daltoon10") {
          preservedConfig.dashboardPassword = pc.dashboardPassword;
        }
        if (pc.serverPort && Number(pc.serverPort) !== 3000) {
          preservedConfig.serverPort = Number(pc.serverPort);
        }
        if (pc.botToken && pc.botToken !== "DUMMY_TOKEN") {
          preservedConfig.botToken = pc.botToken;
        }
        if (pc.ownerId && Number(pc.ownerId) !== 0) {
          preservedConfig.ownerId = Number(pc.ownerId);
        }
      }
    } catch (e) {}

    // Always keep backup data clean and minimal
    if (parsed.transactions && Array.isArray(parsed.transactions)) {
      parsed.transactions = parsed.transactions.map((t: any) => {
        if (
          t.receiptImage &&
          t.receiptImage.length > 500 &&
          t.receiptImage.startsWith("data:")
        ) {
          return { ...t, receiptImage: "placeholder_cleared" };
        }
        return t;
      });
    }

    // Merge preserved active config into restored database settings
    if (Object.keys(preservedConfig).length > 0) {
      if (!parsed.settings) parsed.settings = {};
      if (!parsed.settings.panel_config) parsed.settings.panel_config = "{}";
      try {
        let pc =
          typeof parsed.settings.panel_config === "string"
            ? JSON.parse(parsed.settings.panel_config)
            : parsed.settings.panel_config;
        pc = { ...preservedConfig, ...pc };
        parsed.settings.panel_config = JSON.stringify(pc);
      } catch (e) {}
    }

    parsed.isNewInstall = false;

    try { execSync("pm2 stop daltoon-bot"); } catch(e) {};
    
    const writeSuccess = writeSqliteDb(parsed, true);
    
    if (!writeSuccess) {
      return res.status(500).json({ success: false, error: "خطا در ذخیره بکاپ به دلیل مشکلات سیستمی (Safeguard). فایل ممکن است نامعتبر باشد." });
    }

    // Attempt dynamic python bot restart to apply configurations immediately
    startPythonBot();

    res.json({ success: true, message: "فایل بکاپ با موفقیت بازگردانی شد." });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

async function performAutoBackup() {
  try {
    const db = readSqliteDb();
    const settings = getSystemSettings(db);

    if (!settings.autoBackupEnabled) return;
    if (!settings.autoBackupInterval) return;

    const ownerId = Number(settings.ownerId || 6536288293);
    const botToken = settings.botToken;
    if (!botToken || botToken === "DUMMY_TOKEN") return;

    const fileBuffer = Buffer.from(JSON.stringify(db, null, 2), "utf8");

    const dateStr = new Date().toLocaleString("fa-IR", {
      timeZone: "Asia/Tehran",
    });
    const periods: any = {
      hourly: "ساعتی",
      daily: "روزانه",
      weekly: "هفتگی",
      monthly: "ماهانه",
    };
    const caption = `📦 پشتیبان‌گیری خودکار\n\n🕒 تاریخ: ${dateStr}\nتنظیمات: ${periods[settings.autoBackupInterval] || settings.autoBackupInterval}\n\n#DaltoonBot`;

    // Extremely robust manual multipart payload construction to bypass Node.js FormData/Blob fetch boundary bugs
    const boundary = "----WebKitFormBoundaryDaltoonBackup" + Math.random().toString(36).substring(2);
    
    const headerParts = [
      `--${boundary}`,
      `Content-Disposition: form-data; name="chat_id"`,
      '',
      String(ownerId),
      `--${boundary}`,
      `Content-Disposition: form-data; name="caption"`,
      '',
      caption,
      `--${boundary}`,
      `Content-Disposition: form-data; name="document"; filename="Daltoon_Bot.db"`,
      `Content-Type: application/json`,
      '',
      ''
    ].join('\r\n');

    const headerBuffer = Buffer.from(headerParts);
    const footerBuffer = Buffer.from(`\r\n--${boundary}--\r\n`);
    const bodyBuffer = Buffer.concat([headerBuffer, fileBuffer, footerBuffer]);

    const response = await fetch(`https://api.telegram.org/bot${botToken}/sendDocument`, {
      method: "POST",
      headers: {
        "Content-Type": `multipart/form-data; boundary=${boundary}`,
      },
      body: bodyBuffer,
    });

    const resJson = await response.json() as any;
    if (!resJson || !resJson.ok) {
      throw new Error(resJson?.description || "Failed to send backup document to Telegram");
    }

    const freshDb = readSqliteDb();
    if (!freshDb.settings) freshDb.settings = {};
    freshDb.settings.lastAutoBackup = String(Date.now());
    writeSqliteDb({ settings: freshDb.settings } as any);
    console.log(`[Auto Backup] Successfully sent backup to owner ${ownerId}`);
  } catch (err: any) {
    console.error(`[Auto Backup Error]`, err.message);
  }
}

async function checkAutoBackup() {
  try {
    const db = readSqliteDb();
    const settings = getSystemSettings(db);

    if (!settings.autoBackupEnabled || !settings.autoBackupInterval) return;

    const lastBackup = Number(db.settings?.lastAutoBackup) || 0;
    const now = Date.now();

    let shouldBackup = false;

    if (lastBackup === 0) {
      shouldBackup = true;
    } else {
      const diffMs = now - lastBackup;
      const interval = settings.autoBackupInterval;

      if (interval === "hourly") {
        // Run hourly if at least 55 minutes have passed
        if (diffMs >= 55 * 60 * 1000) {
          shouldBackup = true;
        }
      } else if (interval === "daily") {
        // Run daily if at least 23 hours have passed
        if (diffMs >= 23 * 60 * 60 * 1000) {
          shouldBackup = true;
        }
      } else if (interval === "weekly") {
        // Run weekly if at least 6 days and 23 hours have passed
        if (diffMs >= (7 * 24 - 1) * 60 * 60 * 1000) {
          shouldBackup = true;
        }
      } else if (interval === "monthly") {
        // Run monthly if at least 29 days have passed
        if (diffMs >= 29 * 24 * 60 * 60 * 1000) {
          shouldBackup = true;
        }
      }
    }

    if (shouldBackup) {
      await performAutoBackup();
    }
  } catch (e) {
    console.error("[Auto Backup Check Error]", e);
  }
}


app.get("/api/system/bot/status", requireAdminAuth, (req, res) => {
  exec("pm2 jlist", (err, stdout, stderr) => {
    if (err) {
      return res.json({ status: "unknown", isRunning: true }); // Fallback
    }
    try {
      const pm2list = JSON.parse(stdout);
      const botProcess = pm2list.find((p: any) => p.name === "daltoon-bot");
      if (botProcess) {
        return res.json({ status: botProcess.pm2_env.status, isRunning: botProcess.pm2_env.status === "online" });
      }
      return res.json({ status: "not_found", isRunning: false });
    } catch (e) {
      return res.json({ status: "unknown", isRunning: true });
    }
  });
});

app.post("/api/system/bot/action", requireAdminAuth, (req, res) => {
  const { action } = req.body;
  if (!["start", "stop", "restart", "restart-all"].includes(action)) {
    return res.status(400).json({ error: "Invalid action" });
  }
  
  if (action === "restart-all") {
    res.json({ success: true, message: `System restarting...` });
    setTimeout(() => {
      exec("pm2 restart daltoon-bot; pm2 restart daltoon-store || pm2 restart all || true");
      process.exit(0);
    }, 1500);
    return;
  }

  const isPM2 =
    process.env.PM2_HOME !== undefined ||
    process.env.pm_id !== undefined ||
    process.env.name === "daltoon-store";

  if (isPM2) {
    exec(`pm2 ${action} daltoon-bot`, (err, stdout, stderr) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.json({ success: true, message: `Action ${action} executed via PM2` });
    });
  } else {
    // Non-PM2 environment
    if (action === "stop" || action === "restart") {
      if (botProcess) {
        try {
          botProcess.kill("SIGKILL");
          botProcess = null;
        } catch(e) {}
      } else {
        // Try to kill via PID file just in case
        try {
          if (fs.existsSync("bot.pid")) {
            const pid = parseInt(fs.readFileSync("bot.pid", "utf8"));
            if (pid) process.kill(pid, "SIGKILL");
          }
        } catch(e) {}
      }
    }
    
    if (action === "start" || action === "restart") {
      setTimeout(() => {
        startPythonBot();
        res.json({ success: true, message: `Action ${action} executed internally` });
      }, 1000);
    } else {
      res.json({ success: true, message: `Action ${action} executed internally` });
    }
  }
});

// 9. System auto-update endpoints

app.get("/api/system/version", (req, res) => {
  try {
    const pkgPath = path.join(process.cwd(), "package.json");
    if (fs.existsSync(pkgPath)) {
      const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8"));
      res.json({ success: true, version: pkg.version || "1.0.0" });
    } else {
      res.json({ success: true, version: "2.0.0" });
    }
  } catch (err: any) {
    res.json({ success: false, error: err.message, version: "2.0.0" });
  }
});

app.get("/api/system/status", requireAdminAuth, (req, res) => {
  try {
    // os imported at top

    // CPU load calculation using load average or synthetic load representation
    const cpus = os.cpus();
    const loadAvg = os.loadavg()[0];
    const cpuCount = cpus ? cpus.length : 1;
    let cpuUsage = Math.round((loadAvg / cpuCount) * 100);
    if (!cpuUsage || cpuUsage <= 0 || isNaN(cpuUsage)) {
      // safe fallback for development / server startup
      cpuUsage = Math.floor(Math.random() * 15) + 8;
    }
    if (cpuUsage > 100) cpuUsage = 100;

    // Memory usage
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;
    const memoryUsage = Math.round((usedMem / totalMem) * 100) || 10;

    const totalMemGB = (totalMem / (1024 * 1024 * 1024)).toFixed(2) + " GB";
    const usedMemGB = (usedMem / (1024 * 1024 * 1024)).toFixed(2) + " GB";

    let swapUsage = 0;
    let swapTotal = "0 MB";
    let swapUsed = "0 MB";
    try {
      const freeOut = execSync("free -m").toString().split("\n");
      const swapLine = freeOut.find(line => line.startsWith("Swap:"));
      if (swapLine) {
        const parts = swapLine.split(/\s+/);
        const total = parseInt(parts[1], 10);
        const used = parseInt(parts[2], 10);
        if (total > 0) {
          swapUsage = parseFloat(((used / total) * 100).toFixed(1));
          swapTotal = total + " MB";
          swapUsed = used + " MB";
        }
      }
    } catch (e) {}

    let cpuModel = "Unknown CPU";
    let cpuSpeed = 0;
    if (cpus && cpus.length > 0) {
      cpuModel = cpus[0].model;
      cpuSpeed = cpus[0].speed;
    }

    // Disk usage calculation
    let diskUsage = 38;
    let diskTotal = "80GB";
    let diskUsed = "30.4GB";
    try {
      // execSync imported at top
      const dfOut = execSync("df -h /").toString().split("\n")[1];
      const parts = dfOut.split(/\s+/);
      if (parts.length >= 5) {
        diskTotal = parts[1];
        diskUsed = parts[2];
        diskUsage = parseInt(parts[4].replace("%", ""), 10);
      }
    } catch (e) {
      // silent fallback
    }

    // Uptime calculation
    const sysUptimeSec = os.uptime();
    const days = Math.floor(sysUptimeSec / 86400);
    const hours = Math.floor((sysUptimeSec % 86400) / 3600);
    const minutes = Math.floor((sysUptimeSec % 3600) / 60);
    const uptimeStr = days > 0 ? `${days}d ${hours}h ${minutes}m` : `${hours}h ${minutes}m`;

    res.json({
      cpu: { usage: cpuUsage, cores: cpuCount, speed: cpuSpeed, model: cpuModel },
      memory: { usage: memoryUsage, total: totalMemGB, used: usedMemGB },
      swap: { usage: swapUsage, total: swapTotal, used: swapUsed },
      disk: { usage: diskUsage, total: diskTotal, used: diskUsed },
      uptime: uptimeStr,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get("/api/system/info", requireAdminAuth, async (req, res) => {
  try {
    let ipv4 = "Unknown";
    let ipv6 = "Unknown";
    
    const services = [
      { url: "https://api4.ipify.org?format=json", type: "v4" },
      { url: "https://api6.ipify.org?format=json", type: "v6" },
      { url: "https://ifconfig.co/json", type: "both" }
    ];

    for (const service of services) {
      try {
        const response = await fetch(service.url, { signal: AbortSignal.timeout(1500) });
        const data = await response.json();
        if (service.type === "v4") ipv4 = data.ip;
        if (service.type === "v6") ipv6 = data.ip;
        if (service.type === "both") {
          if (!ipv4 || ipv4 === "Unknown") ipv4 = data.ip;
          if (data.ip.includes(":")) ipv6 = data.ip;
        }
      } catch {}
    }

    // Fallback for IPv4 using shell
    if (ipv4 === "Unknown") {
      try {
        ipv4 = execSync("curl -4 -s https://api.ipify.org", { encoding: "utf8", timeout: 2000 }).trim();
      } catch {}
    }

    const loads = os.loadavg();
    const baseLoad = (loads[0] * 10) + 20;
    const activityData = Array.from({ length: 20 }, (_, i) => {
      const randomNoise = Math.floor(Math.random() * 15) - 7;
      return Math.min(100, Math.max(10, Math.floor(baseLoad + randomNoise + (Math.sin(i / 3) * 10))));
    });

    res.json({
      success: true,
      publicIp: ipv4, // backwards compatibility
      ipv4,
      ipv6,
      uptime: os.uptime(),
      load: os.loadavg(),
      activityData
    });
  } catch (err) {
    res.status(500).json({ success: false, error: "Failed to fetch system info" });
  }
});

function isVersionNewer(current: string, latest: string): boolean {
  const parse = (v: string) => String(v || '').replace(/^v/i, '').replace(/-dev.*$/i, '').split('.').map(x => parseInt(x, 10) || 0);
  const curParts = parse(current);
  const latParts = parse(latest);
  for (let i = 0; i < Math.max(curParts.length, latParts.length); i++) {
    const c = curParts[i] || 0;
    const l = latParts[i] || 0;
    if (l > c) return true;
    if (c > l) return false;
  }
  return false;
}

function runCommandAsync(cmd: string, cwd: string = process.cwd()): Promise<{ success: boolean; stdout: string; stderr: string }> {
  return new Promise((resolve) => {
    const customPath = `${process.env.PATH || ""}:/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin:${cwd}/node_modules/.bin:/root/.nvm/versions/node/${process.version}/bin`;
    exec(cmd, { cwd, env: { ...process.env, PATH: customPath } }, (error, stdout, stderr) => {
      resolve({
        success: !error,
        stdout: stdout || "",
        stderr: stderr || "",
      });
    });
  });
}

function runCommandStreaming(
  cmd: string, 
  onData: (chunk: string) => void, 
  cwd: string = process.cwd()
): Promise<{ success: boolean; stdout: string; stderr: string }> {
  return new Promise((resolve) => {
    const customPath = `${process.env.PATH || ""}:/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin:${cwd}/node_modules/.bin:/root/.nvm/versions/node/${process.version}/bin`;
    const child = exec(cmd, { cwd, env: { ...process.env, PATH: customPath }, maxBuffer: 20 * 1024 * 1024 });
    let stdout = "";
    let stderr = "";

    if (child.stdout) {
      child.stdout.on("data", (chunk: any) => {
        const str = chunk.toString();
        stdout += str;
        onData(str);
      });
    }

    if (child.stderr) {
      child.stderr.on("data", (chunk: any) => {
        const str = chunk.toString();
        stderr += str;
        onData(str);
      });
    }

    child.on("close", (code) => {
      resolve({
        success: code === 0,
        stdout,
        stderr,
      });
    });

    child.on("error", (err: any) => {
      const msg = err ? err.message : "Unknown error";
      stderr += msg;
      onData(`[Command Error] ${msg}\n`);
      resolve({
        success: false,
        stdout,
        stderr,
      });
    });
  });
}

app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

app.get("/api/system/logs", requireAdminAuth, (req, res) => {
  try {
    // Attempt to read pm2 logs for daltoon-dashboard or fallback to update.log
    let logs = "";
    try {
      logs = execSync("pm2 logs daltoon-dashboard --lines 200 --nostream").toString();
    } catch (e) {
      try {
        logs = execSync("pm2 logs --lines 200 --nostream | grep -i daltoon").toString();
      } catch (e2) {
        const logFile = path.join(process.cwd(), "update.log");
        if (fs.existsSync(logFile)) {
          logs = fs.readFileSync(logFile, "utf-8");
        } else {
          logs = "No PM2 logs or update.log available.";
        }
      }
    }
    res.json({ success: true, log: logs });
  } catch (err: any) {
    res.status(500).json({ success: false, log: "Failed to read logs: " + err.message });
  }
});

app.get("/api/system/update-log", requireAdminAuth, (req, res) => {
  const logFile = path.join(process.cwd(), "update.log");
  if (fs.existsSync(logFile)) {
    try {
      const content = fs.readFileSync(logFile, "utf8");
      const isFinished = content.includes("=== Auto-Update Completed Successfully ===") || content.includes("Exiting process to trigger clean restart");
      const hasError = content.includes("=== Auto-Update Failed");
      res.json({ success: true, log: content, isFinished, hasError });
    } catch (err: any) {
      res.json({ success: false, error: err.message });
    }
  } else {
    res.json({ success: false, error: "No update log found" });
  }
});

app.get("/api/system/check-update", async (req, res) => {
  let version = "3.7.4";
  const pkgPath = path.join(process.cwd(), "package.json");
  if (fs.existsSync(pkgPath)) {
    try {
      version = JSON.parse(fs.readFileSync(pkgPath, "utf8")).version || version;
    } catch {}
  }

  const channel = req.query.channel || (version.includes('dev') ? 'dev' : 'stable');

  try {
    let updateAvailable = false;
    let latestVersion = "";
    const isGit = fs.existsSync(path.join(process.cwd(), ".git"));

    // Helper to check and set update status from a version string
    const applyLatestVersion = (latVer: string) => {
      latestVersion = latVer;
      const cleanCurrent = version.replace('-dev', '');
      if (isVersionNewer(cleanCurrent, latestVersion)) {
        updateAvailable = true;
      }
    };

    try {
      if (channel === 'dev') {
        const randomSha = Math.random().toString(16).substring(2, 9);
        version = `Dev+${randomSha}`;
        latestVersion = version;
        updateAvailable = false;
        res.json({
          success: true,
          updateAvailable,
          currentVersion: version,
          latestVersion
        });
        return;
      }
      
      const githubUrl = `https://api.github.com/repos/mdaltoon10/Daltoon-Bot/releases?t=${Date.now()}`;
      const response = await fetch(githubUrl, { 
        headers: { 
          'User-Agent': 'Daltoon-Dashboard',
          'Accept': 'application/vnd.github.v3+json'
        },
        signal: AbortSignal.timeout(8000)
      });
      if (response.ok) {
        const releases = await response.json();
        if (Array.isArray(releases) && releases.length > 0) {
          // Find published releases (not drafts)
          const publishedReleases = releases.filter((r: any) => !r.draft);
          
          // Depending on channel, allow prereleases or strict stable only
          const targetReleases = channel === 'dev' 
            ? publishedReleases 
            : publishedReleases.filter((r: any) => !r.prerelease);
            
          if (targetReleases.length > 0) {
            // Find the highest version instead of just taking the first one
            let highestTag = targetReleases[0].tag_name;
            let highestVersion = highestTag.startsWith('v') ? highestTag.substring(1) : highestTag;
            
            for (let j = 1; j < targetReleases.length; j++) {
              const currentTag = targetReleases[j].tag_name;
              const currentVersion = currentTag.startsWith('v') ? currentTag.substring(1) : currentTag;
              if (isVersionNewer(highestVersion, currentVersion)) {
                highestVersion = currentVersion;
                highestTag = currentTag;
              }
            }
            
            applyLatestVersion(highestVersion);
          }
        }

        // Also check tags API to ensure we don't miss tags created without a release
        try {
          const tagsUrl = `https://api.github.com/repos/mdaltoon10/Daltoon-Bot/tags?t=${Date.now()}`;
          const tagsResponse = await fetch(tagsUrl, { 
            headers: { 
              'User-Agent': 'Daltoon-Dashboard',
              'Accept': 'application/vnd.github.v3+json'
            },
            signal: AbortSignal.timeout(6000)
          });
          if (tagsResponse.ok) {
            const tags = await tagsResponse.json();
            if (Array.isArray(tags) && tags.length > 0) {
              for (const tag of tags) {
                const tVer = (tag.name || '').replace(/^v/i, '');
                if (isVersionNewer(latestVersion || version, tVer)) {
                  applyLatestVersion(tVer);
                }
              }
            }
          }
        } catch {}
      } else {
        const errorText = await response.text().catch(() => "Unknown error");
        console.warn(`GitHub API failed: ${response.status} ${errorText}. Trying fallbacks...`);
        throw new Error(`API returned ${response.status}`);
      }
    } catch (err: any) {
      console.warn("GitHub API check failed, trying raw file fallbacks:", err.message);
      
      // Fallback 1: raw.githubusercontent.com
      try {
        const rawUrl = `https://raw.githubusercontent.com/mdaltoon10/Daltoon-Bot/main/package.json?t=${Date.now()}`;
        const rawRes = await fetch(rawUrl, { signal: AbortSignal.timeout(6000) });
        if (rawRes.ok) {
          const rawPkg = await rawRes.json();
          if (rawPkg && rawPkg.version) {
            console.log(`Fallback 1 Success: Found version ${rawPkg.version}`);
            applyLatestVersion(rawPkg.version);
          }
        } else {
          throw new Error(`Raw fallback 1 returned status ${rawRes.status}`);
        }
      } catch (f1Err: any) {
        console.warn("Fallback 1 (raw.githubusercontent.com) failed, trying fallback 2:", f1Err.message);
        
        // Fallback 2: github.com/.../raw/...
        try {
          const rawUrl2 = `https://github.com/mdaltoon10/Daltoon-Bot/raw/main/package.json?t=${Date.now()}`;
          const rawRes2 = await fetch(rawUrl2, { signal: AbortSignal.timeout(6000) });
          if (rawRes2.ok) {
            const rawPkg2 = await rawRes2.json();
            if (rawPkg2 && rawPkg2.version) {
              console.log(`Fallback 2 Success: Found version ${rawPkg2.version}`);
              applyLatestVersion(rawPkg2.version);
            }
          }
        } catch (f2Err: any) {
          console.warn("All update check fallbacks failed:", f2Err.message);
        }
      }
    }

    res.json({ 
      success: true, 
      updateAvailable, 
      currentVersion: version,
      latestVersion: latestVersion || version,
      channel,
      isGit
    });
  } catch (err: any) {
    res.json({
      success: false,
      updateAvailable: false,
      currentVersion: version,
      error: err.message
    });
  }
});

app.post("/api/system/update", requireAdminAuth, async (req, res) => {
  const channel = req.body.channel || "stable";
  try {
    res.json({
      success: true,
      message:
        "به‌روزرسانی در پس‌زمینه آغاز شد. سیستم به‌زودی راه‌اندازی مجدد می‌شود...",
    });

    // Run update sequence asynchronously
    setTimeout(async () => {
      const logFile = path.join(process.cwd(), "update.log");
      const writeLog = (message: string) => {
        const time = new Date().toISOString();
        try {
          fs.appendFileSync(logFile, `[${time}] ${message}\n`, "utf8");
        } catch {}
        console.log(`[Auto-Update] ${message}`);
      };

      try {
        fs.writeFileSync(logFile, `=== Auto-Update Started ===\n`, "utf8");
        writeLog(`Starting background update sequence for channel: ${channel}...`);

        let targetTag = "";
        const isGit = fs.existsSync(path.join(process.cwd(), ".git"));

        // Determine target from GitHub Releases
        try {
          const githubUrl = `https://api.github.com/repos/mdaltoon10/Daltoon-Bot/releases?t=${Date.now()}`;
          const response = await fetch(githubUrl, { 
            headers: { 
              "User-Agent": "Daltoon-Dashboard",
              "Accept": "application/vnd.github.v3+json"
            },
            signal: AbortSignal.timeout(8000)
          });
          if (response.ok) {
            const releases = await response.json();
            if (Array.isArray(releases) && releases.length > 0) {
              const publishedReleases = releases.filter((r: any) => !r.draft);
              const targetReleases = channel === 'dev' 
                ? publishedReleases 
                : publishedReleases.filter((r: any) => !r.prerelease);
                
              if (targetReleases.length > 0) {
                let highestTag = targetReleases[0].tag_name;
                let highestVersion = highestTag.startsWith('v') ? highestTag.substring(1) : highestTag;
                
                for (let j = 1; j < targetReleases.length; j++) {
                  const currentTag = targetReleases[j].tag_name;
                  const currentVersion = currentTag.startsWith('v') ? currentTag.substring(1) : currentTag;
                  if (isVersionNewer(highestVersion, currentVersion)) {
                    highestVersion = currentVersion;
                    highestTag = currentTag;
                  }
                }
                targetTag = highestTag;
              }
            }
          } else {
            throw new Error(`API response status ${response.status}`);
          }
        } catch (tErr: any) {
          writeLog(`Failed to fetch target release via GitHub API: ${tErr.message}. Trying fallbacks...`);
          
          // Fallback 1: raw.githubusercontent.com
          try {
            const rawUrl = `https://raw.githubusercontent.com/mdaltoon10/Daltoon-Bot/main/package.json?t=${Date.now()}`;
            const rawRes = await fetch(rawUrl, { signal: AbortSignal.timeout(6000) });
            if (rawRes.ok) {
              const rawPkg = await rawRes.json();
              if (rawPkg && rawPkg.version) {
                targetTag = `v${rawPkg.version}`;
                writeLog(`Fallback 1 Success: Determined target tag from raw package.json: ${targetTag}`);
              }
            } else {
              throw new Error(`Status ${rawRes.status}`);
            }
          } catch (f1Err: any) {
            writeLog(`Fallback 1 failed: ${f1Err.message}. Trying Fallback 2...`);
            
            // Fallback 2: github.com/raw
            try {
              const rawUrl2 = `https://github.com/mdaltoon10/Daltoon-Bot/raw/main/package.json?t=${Date.now()}`;
              const rawRes2 = await fetch(rawUrl2, { signal: AbortSignal.timeout(6000) });
              if (rawRes2.ok) {
                const rawPkg2 = await rawRes2.json();
                if (rawPkg2 && rawPkg2.version) {
                  targetTag = `v${rawPkg2.version}`;
                  writeLog(`Fallback 2 Success: Determined target tag from raw package.json: ${targetTag}`);
                }
              }
            } catch (f2Err: any) {
              writeLog(`All fallbacks failed to determine targetTag: ${f2Err.message}`);
            }
          }
        }

        // Default fallback if targetTag is still empty
        if (!targetTag) {
          targetTag = "main";
          writeLog(`Using default target fallback: ${targetTag}`);
        }

        writeLog(`Configuring git safe directory and checking status...`);
        await runCommandAsync('git config --global --add safe.directory "*" 2>/dev/null || true');
        const statusResult = await runCommandAsync("git status");
        writeLog(`Git status before update:\n${statusResult.stdout}\n${statusResult.stderr}`);

        let updateSuccess = false;

        writeLog(`[Step 1/5] Pulling latest changes from origin/main branch or release tag (${targetTag})...`);
        
        // CRITICAL DATA PRESERVATION: Backup databases + runtime data before destructive git/tar commands.
        // uploads/ (broadcast media), receipts/, data.db, node-compile-cache/ etc. are wiped by `git clean -fd`,
        // so they MUST be backed up and restored or users lose their files on update.
        const backupDir = path.join(os.tmpdir(), `daltoon_update_backup_${Date.now()}`);
        const permBackupDir = "/var/backups/daltoon";
        const runtimeBackupPatterns = "Daltoon_Bot* database.json db.json .env* uploads receipts data.db nohup.out node-compile-cache bot.pid";
        await runCommandAsync(`mkdir -p ${backupDir} ${permBackupDir}`);
        await runCommandAsync(`cp -r ${runtimeBackupPatterns} ${backupDir}/ 2>/dev/null || true`);
        await runCommandAsync(`cp -r ${runtimeBackupPatterns} ${permBackupDir}/ 2>/dev/null || true`);
        
        let gitResult = { success: false, stdout: "", stderr: "" };
        if (isGit) {
          // Fetch main & tags, then reset to origin/main or target tag
          const targetRef = targetTag && targetTag !== "main" ? targetTag : "origin/main";
          const gitCmd = `git fetch origin --tags --force && git fetch origin main --force && (git reset --hard ${targetRef} || git reset --hard origin/main || (test -n "${targetTag}" && git reset --hard ${targetTag})) && git clean -fd`;
          gitResult = await runCommandAsync(gitCmd);
          writeLog(`Git output:\n${gitResult.stdout}\n${gitResult.stderr}`);
        }
        
        if (!gitResult.success || !isGit) {
          writeLog(`Git update needs tarball fallback. Clearing corrupted git index and trying tarball fallback...`);
          await runCommandAsync("rm -rf .git");
          const tarUrl = targetTag && targetTag !== "main" ? `https://github.com/mdaltoon10/Daltoon-Bot/archive/refs/tags/${targetTag}.tar.gz` : `https://github.com/mdaltoon10/Daltoon-Bot/archive/refs/heads/main.tar.gz`;
          const tarCmd = `curl -sL "${tarUrl}" | tar -xz --overwrite --strip-components=1 || curl -sL "https://github.com/mdaltoon10/Daltoon-Bot/archive/refs/heads/main.tar.gz" | tar -xz --overwrite --strip-components=1`;
          const tarResult = await runCommandAsync(tarCmd);
          writeLog(`Tarball output:\n${tarResult.stdout}\n${tarResult.stderr}`);
          updateSuccess = tarResult.success;
        } else {
          updateSuccess = true;
        }
        
        // RESTORE BACKUP FORCEFULLY (OVERWRITE) SO USER DATABASE AND CONFIGS ARE NEVER LOST OR ROLLED BACK BY GIT
        await runCommandAsync(`cp -r -f ${backupDir}/* . 2>/dev/null || true`);
        await runCommandAsync(`rm -rf ${backupDir}`);
        
        if (!updateSuccess) {
           writeLog(`CRITICAL: Step 1 failed to update source code. Proceeding with caution.`);
        }
        
        writeLog(`[Step 2/5] Installing dependencies...`);
        const npmInstallResult = await runCommandAsync("npm install");
        writeLog(`npm install output:\n${npmInstallResult.stdout}\n${npmInstallResult.stderr}`);

        writeLog(`[Step 3/5] Building project...`);
        if (!npmInstallResult.success) {
          writeLog(`WARNING: npm install reported a failure. Continuing anyway - the build below will tell us if the installed dependencies are usable.`);
        }
        const buildResult = await runCommandAsync(`npm run build`);
        writeLog(`Build output:\n${buildResult.stdout}\n${buildResult.stderr}`);

        // CRITICAL OUTAGE GUARD: if the new code failed to build, do NOT restart PM2 and do NOT exit.
        // The currently running process keeps serving the old (working) bundle in memory, so an
        // auto-update can never take the panel down by shipping a broken build.
        const distServerCjs = path.join(process.cwd(), "dist", "server.cjs");
        const buildOk = buildResult.success && fs.existsSync(distServerCjs);
        if (!buildOk) {
          writeLog(`=== Auto-Update FAILED: the new build did not complete successfully. Keeping the current running version online to avoid an outage. Fix the build errors manually, then run the update again. ===`);
          writeLog(`Build success: ${buildResult.success} | dist/server.cjs exists: ${fs.existsSync(distServerCjs)}`);
          return;
        }

        // Step 4: Make files executable and update python packages
        writeLog(`[Step 4/5] Updating executable permissions and Python dependencies...`);
        await runCommandAsync("chmod +x daltoon-dashboard install.sh 2>/dev/null || true");
        const pipCmd = "pip3 install -U pyTelegramBotAPI python-dotenv requests deep_translator --break-system-packages 2>/dev/null || pip3 install -U pyTelegramBotAPI python-dotenv requests deep_translator 2>/dev/null || true";
        const pipResult = await runCommandAsync(pipCmd);
        writeLog(`Pip output:\n${pipResult.stdout}\n${pipResult.stderr}`);

        // Step 5: Restart PM2 processes & exit process
        writeLog(`[Step 5/5] Finishing update and restarting PM2 processes...`);
        writeLog(`=== Auto-Update Completed Successfully ===`);
        const restartCmd = `export PATH=$PATH:/usr/local/bin:/usr/bin:/bin:~/.nvm/versions/node/$(node -v 2>/dev/null)/bin; (pm2 restart daltoon-store daltoon-bot || pm2 restart all || /usr/local/bin/pm2 restart all || true)`;
        const restartResult = await runCommandAsync(restartCmd);
        writeLog(`PM2 restart output:\n${restartResult.stdout}\n${restartResult.stderr}`);

        // Force process exit to ensure process supervisor reloads fresh server bundle
        setTimeout(() => {
          writeLog("Exiting process to trigger clean restart...");
          process.exit(0);
        }, 1500);
      } catch (err: any) {
        writeLog(`=== Auto-Update Failed with error: ${err.message} ===`);
      }
    }, 1000);
  } catch (err: any) {
    console.error("[Auto-Update Catch Error]", err.message);
  }
});

// Integrate Vite developer server in development environment
// --- CRON JOBS ---
async function autoCleanExpiredFreeTrials() {
  try {
    const db = readSqliteDb();
    const now = new Date();
    // Allow 1 day buffer or strict? The user said "تست های رایگان بعد از تموم شدن مستقیم پاک بشن"
    // So if expireDate is yesterday or earlier, delete.
    now.setHours(0, 0, 0, 0);

    const keysToKeep = [];
    const keysToDelete = [];

    for (let k of db.subscription_keys || []) {
      if (k.planName && k.planName.includes("تست رایگان")) {
        const expDate = new Date(k.expireDate);
        if (expDate < now) {
          keysToDelete.push(k);
          continue;
        }
      }
      keysToKeep.push(k);
    }

    if (keysToDelete.length === 0) return;

    console.log(
      `[Auto Cleanup] Found ${keysToDelete.length} expired free trials. Deleting...`,
    );

    const parsedSettings = getSystemSettings(db);
    const activeServers = getActiveServers(parsedSettings);

    for (const server of activeServers) {
      try {
        const cleanedUrl = normalizeXuiUrl(server.panelUrl);
        const loginResult = await loginXuiPanel(
          cleanedUrl,
          server.panelUsername,
          server.panelPassword,
        );

        if (loginResult.success) {
          const headers: Record<string, string> = {
            Cookie: loginResult.cookie!,
            Accept: "application/json",
          };
          if (loginResult.csrfToken)
            headers["X-Csrf-Token"] = loginResult.csrfToken!;

          for (let k of keysToDelete) {
            let uuid = "";
            if (k.subLink) {
              const match = k.subLink.match(
                /(vless|vmess|trojan):\/\/([^@]+)@/,
              );
              if (match && match[2]) uuid = match[2];
            }

            if (uuid) {
              await xuiFetch(
                `${cleanedUrl}/panel/api/client/${uuid}/del`,
                { method: "POST", headers },
                4000,
              ).catch(() => {});
              try {
                const inbRes = await xuiFetch(
                  `${cleanedUrl}/panel/api/inbounds/list`,
                  { method: "GET", headers },
                  4000,
                );
                if (inbRes.ok) {
                  const inbJson = await inbRes.json();
                  if (inbJson.success && Array.isArray(inbJson.obj)) {
                    for (let inb of inbJson.obj) {
                      await xuiFetch(
                        `${cleanedUrl}/panel/api/inbounds/${inb.id}/delClient/${uuid}`,
                        { method: "POST", headers },
                        3000,
                      ).catch(() => {});
                    }
                  }
                }
              } catch (err) {}
            }
          }
        }
      } catch (err) {
        // Continue to next server
      }
    }

    const freshDb = readSqliteDb();

    // We only remove keys that we specifically decided to delete earlier
    const deletedIds = new Set(keysToDelete.map((k) => k.id));
    const newSubscriptionKeys = (freshDb.subscription_keys || []).filter(
      (k) => !deletedIds.has(k.id),
    );

    for (let u of freshDb.users || []) {
      u.activePlansCount = newSubscriptionKeys.filter(
        (sk: any) =>
          sk.userId === u.userId &&
          sk.status === "active" &&
          !sk.planName.includes("تست رایگان"),
      ).length;
    }

    writeSqliteDb({
      subscription_keys: newSubscriptionKeys,
      users: freshDb.users
    } as any);
    console.log(
      `[Auto Cleanup] Successfully deleted ${keysToDelete.length} expired free trials from Panel and Local DB.`,
    );
  } catch (err) {
    console.error("[Auto Cleanup Error]", err);
  }
}

async function sendTelegramMessage(
  botToken: string,
  chatId: string | number,
  text: string,
  replyMarkup?: any,
) {
  if (!botToken || botToken === "DUMMY_TOKEN") return;
  
  try {
    const settings = getSystemSettings();
    const usePremium = String(settings.usePremiumEmojis || "false") === "true";
    const useButtonColors = String(settings.useButtonColors || "false") === "true";
    const customEmojis = settings.premiumEmojiMapping || {
      "🛒": "5449640306352655512",
      "🎁": "5368324170671202286",
      "👤": "5368324170671202287",
      "🎧": "5368324170671202288",
      "🚀": "5368324170671202289",
      "✅": "5368324170671202290",
      "❌": "5368324170671202291",
      "⚠️": "5368324170671202292",
      "💎": "5368324170671202293",
      "💰": "5368324170671202294",
      "📊": "5368324170671202295",
      "🔄": "5368324170671202296",
      "🎫": "5368324170671202297",
      "⚡": "5368324170671202298",
      "💳": "5368324170671202299",
      "📝": "5368324170671202300",
      "⏳": "5368324170671202301",
      "🌐": "5368324170671202302",
      "⚙️": "5368324170671202303",
      "🔌": "5368324170671202304",
      "🔋": "5368324170671202305",
      "💡": "5368324170671202306",
      "🔒": "5368324170671202307",
      "🔓": "5368324170671202308",
      "🔑": "5368324170671202309",
      "🇯🇵": "5368324170671202331",
      "🇰🇷": "5368324170671202332",
      "🇦🇺": "5368324170671202333",
      "🇿🇦": "5368324170671202334",
      "🇲🇽": "5368324170671202335",
      "🇦🇷": "5368324170671202336",
      "🇸🇦": "5368324170671202337",
      "🇮🇶": "5368324170671202338",
    };

    if (usePremium && text) {
      for (const [std, customId] of Object.entries(customEmojis)) {
        text = text.split(std).join(`<tg-emoji emoji-id="${customId}">${std}</tg-emoji>`);
      }
    }

    if (replyMarkup) {
      const isInline = !!replyMarkup.inline_keyboard;
      const rows = replyMarkup.inline_keyboard || replyMarkup.keyboard || [];
      
      const primaryColors = settings.primaryButtonColors || {};
      const primaryTexts: Record<string, string> = {
        [settings.btnTextBuyNew || "🛒 خرید اشتراک جدید"]: "btnBuyNew",
        [settings.btnTextMySubs || "🗂 اشتراک های من / تمدید"]: "btnMySubs",
        [settings.btnTextGuides || "💡 آموزش ها"]: "btnGuides",
        [settings.btnTextProfile || "👤 حساب کاربری"]: "btnProfile",
        [settings.btnTextSupport || "📞 پشتیبانی"]: "btnSupport",
        [settings.btnTextTicketSupport || "🎫 تیکت به پشتیبانی"]: "btnTicketSupport",
        [settings.btnTextFreeTest || "🎁 موجودی رایگان"]: "btnFreeTest",
        [settings.btnTextInstantSupport || "🤖 پشتیبانی آنی"]: "btnInstantSupport",
        [settings.btnTextFeedback || "💌 بازخورد کاربر ها"]: "btnFeedback",
        [settings.btnTextReferral || "👥 زیرمجموعه گیری"]: "btnReferral",
        [settings.btnTextWallet || "شارژ کیف پول 💳"]: "btnWallet",
        [settings.btnTextColleagues || "بسته ویژه همکاران"]: "btnColleagues",
        [settings.btnTextAiChat || "🤖 چت با ربات"]: "btnAiChat",
        [settings.btnTextAi || "🧠 هوش مصنوعی"]: "btnAi",
        [settings.btnTextAddConfig || "➕ افزودن کانفیگ به ربات"]: "btnAddConfig",
        [settings.btnTextConfigDetails || "📊 مشخصات کانفیگ"]: "btnConfigDetails",
        [settings.btnTextSearchConfig || "🔍 سرچ کانفیگ (مدیریت)"]: "btnSearchConfig",
      };

      const cleanBtnText = (t: string) => {
        if (!t) return "";
        return Array.from(t).filter(c => c.charCodeAt(0) < 0x2000 || (c.charCodeAt(0) >= 0xFB00 && c.charCodeAt(0) <= 0xFEFF)).join("").trim();
      };

      const getButtonStyle = (btnText: string) => {
        const cleaned = cleanBtnText(btnText);
        let matchedKey = null;
        for (const [txt, key] of Object.entries(primaryTexts)) {
          if (txt === btnText || cleanBtnText(txt) === cleaned) {
            matchedKey = key;
            break;
          }
        }
        if (matchedKey) {
          const color = primaryColors[matchedKey];
          if (color && color !== "none") return color;
          return null;
        }
        const customStyles = settings.buttonStylesMapping || { "success": [], "danger": [], "primary": [] };
        for (const [style, keywords] of Object.entries(customStyles)) {
          if (Array.isArray(keywords)) {
            for (const kw of keywords) {
              if (kw && btnText.includes(kw)) return style;
            }
          }
        }
        return null;
      };

      for (const row of rows) {
        for (let i = 0; i < row.length; i++) {
          let btn = row[i];
          if (typeof btn === "string") continue;
          
          if (btn.text) {
            const originalText = btn.text;
            
            if (isInline && useButtonColors) {
              const assignedStyle = getButtonStyle(originalText);
              if (assignedStyle) {
                btn.style = assignedStyle;
              }
            }
            
            if (isInline && usePremium) {
              let hasCustom = false;
              for (const [std, customId] of Object.entries(customEmojis)) {
                if (originalText.includes(std) || btn.text.includes(std)) {
                  if (!hasCustom) {
                    btn.icon_custom_emoji_id = String(customId);
                    hasCustom = true;
                  }
                  btn.text = btn.text.split(std).join("").split("  ").join(" ").trim();
                }
              }
            }
          }
        }
      }
    }

  } catch(e) {
    console.error("Error applying styles to msg:", e);
  }

  try {
    const fetchRef = globalThis.fetch || fetch;
    const effectiveToken = (botToken && botToken.trim() !== "" && botToken !== "DUMMY_TOKEN")
      ? botToken.trim()
      : (process.env.BOT_TOKEN || "").trim();

    if (!effectiveToken || effectiveToken === "DUMMY_TOKEN") return false;

    const body: any = {
      chat_id: chatId,
      text: text,
      parse_mode: "HTML",
    };
    if (replyMarkup) {
      // Retain custom non-Telegram button properties like 'style' and 'icon_custom_emoji_id' so custom clients (like Telegraph) can render them
      const cleanMarkup = JSON.parse(JSON.stringify(replyMarkup));
      body.reply_markup = cleanMarkup;
    }

    const res = await fetchRef(`https://api.telegram.org/bot${effectiveToken}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const errTxt = await res.text();
      console.warn(`[Telegram Warning] HTML sendMessage failed (${res.status}): ${errTxt}. Retrying plain text...`);

      // Strip HTML tags for fallback
      const plainText = text.replace(/<[^>]*>/g, "");
      const fallbackBody: any = {
        chat_id: chatId,
        text: plainText,
      };
      if (replyMarkup) {
        try {
          const cleanMarkup = JSON.parse(JSON.stringify(replyMarkup));
          fallbackBody.reply_markup = cleanMarkup;
        } catch (e) {}
      }
      const res2 = await fetchRef(`https://api.telegram.org/bot${effectiveToken}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(fallbackBody),
      });
      return res2.ok;
    }
    return true;
  } catch (err) {
    console.error(`[Telegram Warning] Fail to send to ${chatId}:`, err);
    return false;
  }
}

async function sendPurchaseSuccessNoteIfAnyServer(
  botToken: string,
  chatId: string | number,
  settings: any,
) {
  if (!botToken || botToken === "DUMMY_TOKEN") return;
  const fetchRef = globalThis.fetch || fetch;
  const noteText = settings.purchaseSuccessNote || "";
  const attachment = settings.purchaseSuccessAttachment || null;

  if (!noteText && !attachment) return;

  try {
    if (attachment && attachment.fileData) {
      const fileType = attachment.fileType || "image";
      let b64Str = attachment.fileData;
      if (b64Str.includes(",")) b64Str = b64Str.split(",")[1];

      const buffer = Buffer.from(b64Str, "base64");
      const blob = new Blob([buffer]);
      const fd = new FormData();
      fd.append("chat_id", String(chatId));
      if (noteText) fd.append("caption", noteText);
      fd.append("parse_mode", "HTML");

      let endpoint = "sendDocument";
      if (fileType === "image") {
        endpoint = "sendPhoto";
        fd.append("photo", blob, "image.png");
      } else if (fileType === "video") {
        endpoint = "sendVideo";
        fd.append("video", blob, "video.mp4");
      } else if (fileType === "voice") {
        endpoint = "sendVoice";
        fd.append("voice", blob, "voice.ogg");
      } else {
        fd.append("document", blob, attachment.fileName || "attachment.dat");
      }

      await fetchRef(`https://api.telegram.org/bot${botToken}/${endpoint}`, {
        method: "POST",
        body: fd as any,
      });
    } else if (noteText) {
      await sendTelegramMessage(botToken, chatId, noteText);
    }
  } catch (err) {
    console.warn(
      `[Purchase Success Note Server] Error sending to ${chatId}:`,
      err,
    );
  }
}

async function autoSyncTrafficUsage() {
  try {
    const db = readSqliteDb();
    let settings = getSystemSettings(db);

    const activeServers = getActiveServers(settings);

    // Only continue if panel is connected
    if (activeServers.length === 0) {
      return;
    }

    const trafficMap: Record<
      string,
      {
        up: number;
        down: number;
        total: number;
        expiryTime?: number;
        totalGb?: number;
      }
    > = {};
    const seenStats = new Set<string>();

    for (const server of activeServers) {
      try {
        const cleanedUrl = normalizeXuiUrl(server.panelUrl);
        let loginResult = await loginXuiPanel(
          cleanedUrl,
          server.panelUsername,
          server.panelPassword,
        );

        if (!loginResult.success || !loginResult.cookie) {
          continue;
        }
        const headers: Record<string, string> = {
          Cookie: loginResult.cookie,
          Accept: "application/json",
        };
        if (loginResult.csrfToken) {
          headers["X-Csrf-Token"] = loginResult.csrfToken!;
        }
        // Try to get clientTraffics API directly for accurate unique stats
        let trafficJson = null;
        try {
          const ctRes = await xuiFetch(`${cleanedUrl}/panel/api/inbounds/getClientTraffics`, { method: 'GET', headers }, 8000);
          if (ctRes.ok) {
            const contentType = ctRes.headers.get('content-type') || '';
            if (!ctRes.redirected && !contentType.includes('text/html')) {
              const ctText = await ctRes.text();
              try { trafficJson = JSON.parse(ctText); } catch (e) {}
            }
          }
        } catch (e) {}

        if (trafficJson && trafficJson.success && Array.isArray(trafficJson.obj)) {
          for (let cs of trafficJson.obj) {
            if (cs.email || cs.uuid || cs.subId) {
              const lMail = (cs.email || "").toLowerCase();
              const lPrefix = lMail.split('@')[0];
              const lUuid = (cs.uuid || cs.subId || "").toString().toLowerCase();

              if (cs.id !== undefined && cs.id !== null) {
                const statKey = `${cs.id}_${cs.email}`;
                if (seenStats.has(statKey)) continue;
                seenStats.add(statKey);
              }

              const keyToUse = lUuid || lMail;
              if (keyToUse) {
                if (!trafficMap[keyToUse])
                  trafficMap[keyToUse] = { up: 0, down: 0, total: 0 };
                if (lMail && !trafficMap[lMail]) trafficMap[lMail] = trafficMap[keyToUse];
                if (lPrefix && !trafficMap[lPrefix]) trafficMap[lPrefix] = trafficMap[keyToUse];
                if (lUuid && !trafficMap[lUuid]) trafficMap[lUuid] = trafficMap[keyToUse];

                const csUp = Number(cs.up) || 0;
                const csDown = Number(cs.down) || 0;
                const csTotal = csUp + csDown;

                if (csTotal >= trafficMap[keyToUse].total) {
                  trafficMap[keyToUse].up = csUp;
                  trafficMap[keyToUse].down = csDown;
                  trafficMap[keyToUse].total = csTotal;
                }
                if (cs.expiryTime)
                  trafficMap[keyToUse].expiryTime = Number(cs.expiryTime);
                if (cs.total) {
                  const csTot = Number(cs.total);
                  trafficMap[keyToUse].totalGb = csTot > 10000000 ? csTot / (1024 * 1024 * 1024) : csTot;
                }
              }
            }
          }
        } else {
          // Get all inbounds fallback
          let inbRes = await xuiFetch(
            `${cleanedUrl}/panel/api/inbounds/list`,
            { method: "GET", headers },
            10000,
          );

          // Retry fallback list endpoint if it is redirected or failed with HTML
          if (inbRes.ok) {
            const contentType = inbRes.headers.get("content-type") || "";
            if (inbRes.redirected || contentType.includes("text/html")) {
              console.log(`[XUI Cache] Session expired on fallback list for ${cleanedUrl}. Retrying with fresh login...`);
              clearXuiPanelSession(cleanedUrl, server.panelUsername, server.panelPassword);
              const freshLogin = await loginXuiPanel(cleanedUrl, server.panelUsername, server.panelPassword, true);
              if (freshLogin.success && freshLogin.cookie) {
                const freshHeaders: Record<string, string> = {
                  Cookie: freshLogin.cookie!,
                  Accept: "application/json"
                };
                if (freshLogin.csrfToken) {
                  freshHeaders["X-Csrf-Token"] = freshLogin.csrfToken!;
                }
                inbRes = await xuiFetch(
                  `${cleanedUrl}/panel/api/inbounds/list`,
                  { method: "GET", headers: freshHeaders },
                  10000,
                );
              }
            }
          }

          if (!inbRes.ok) continue;

          const inbText = await inbRes.text();
          let inbJson: any = null;
          try {
            inbJson = JSON.parse(inbText);
          } catch (e) {
            // Retry list parsing once with fresh login if JSON parse failed
            console.log(`[XUI Cache] JSON parse failed on fallback list for ${cleanedUrl}. Retrying with fresh login...`);
            clearXuiPanelSession(cleanedUrl, server.panelUsername, server.panelPassword);
            const freshLogin = await loginXuiPanel(cleanedUrl, server.panelUsername, server.panelPassword, true);
            if (freshLogin.success && freshLogin.cookie) {
              const freshHeaders: Record<string, string> = {
                Cookie: freshLogin.cookie!,
                Accept: "application/json"
              };
              if (freshLogin.csrfToken) {
                freshHeaders["X-Csrf-Token"] = freshLogin.csrfToken!;
              }
              const inbResRetry = await xuiFetch(
                `${cleanedUrl}/panel/api/inbounds/list`,
                { method: "GET", headers: freshHeaders },
                10000,
              );
              if (inbResRetry.ok) {
                try {
                  inbJson = await inbResRetry.json();
                } catch (e2) {}
              }
            }
          }

          if (!inbJson || !inbJson.success || !Array.isArray(inbJson.obj)) continue;

          for (let inb of inbJson.obj) {
            // A) Check settings JSON clients
            if (inb.settings) {
              try {
                const parsedSettings = typeof inb.settings === "string" ? JSON.parse(inb.settings) : inb.settings;
                if (Array.isArray(parsedSettings.clients)) {
                  for (let c of parsedSettings.clients) {
                    if (c.email || c.id) {
                      const lMail = (c.email || "").toLowerCase();
                      const lUuid = (c.id || "").toLowerCase();
                      const keyToUse = lUuid || lMail;
                      if (keyToUse) {
                        if (!trafficMap[keyToUse]) trafficMap[keyToUse] = { up: 0, down: 0, total: 0 };
                        if (lMail && !trafficMap[lMail]) trafficMap[lMail] = trafficMap[keyToUse];
                        if (lUuid && !trafficMap[lUuid]) trafficMap[lUuid] = trafficMap[keyToUse];

                        const u = (Number(c.up) || 0) + (Number(c.down) || 0);
                        if (u > trafficMap[keyToUse].total) {
                          trafficMap[keyToUse].total = u;
                          trafficMap[keyToUse].up = Number(c.up) || 0;
                          trafficMap[keyToUse].down = Number(c.down) || 0;
                        }
                        if (c.expiryTime && Number(c.expiryTime) > 0)
                          trafficMap[keyToUse].expiryTime = Number(c.expiryTime);
                        const totVal = Number(c.total) || Number(c.totalGB) || 0;
                        if (totVal > 0) {
                          if (totVal > 10000000) {
                            trafficMap[keyToUse].totalGb = totVal / (1024 * 1024 * 1024);
                          } else {
                            trafficMap[keyToUse].totalGb = totVal;
                          }
                        }
                      }
                    }
                  }
                }
              } catch (e) {}
            }

            // B) Check clientStats array
            let clientStats = inb.clientStats || [];
            for (let cs of clientStats) {
              if (cs.email || cs.uuid || cs.id) {
                if (cs.id !== undefined && cs.id !== null) {
                  const statKey = `${cs.id}_${cs.email}`;
                  if (seenStats.has(statKey)) continue;
                  seenStats.add(statKey);
                }
                const lMail = (cs.email || "").toLowerCase();
                const lUuid = (cs.uuid || cs.id || "").toLowerCase();
                const keyToUse = lUuid || lMail;

                if (!trafficMap[keyToUse])
                  trafficMap[keyToUse] = { up: 0, down: 0, total: 0 };
                if (lMail && !trafficMap[lMail]) trafficMap[lMail] = trafficMap[keyToUse];
                if (lUuid && !trafficMap[lUuid]) trafficMap[lUuid] = trafficMap[keyToUse];

                const csUp = Number(cs.up) || 0;
                const csDown = Number(cs.down) || 0;
                const csTotal = csUp + csDown;

                if (csTotal >= trafficMap[keyToUse].total) {
                  trafficMap[keyToUse].up = csUp;
                  trafficMap[keyToUse].down = csDown;
                  trafficMap[keyToUse].total = csTotal;
                }

                if (cs.expiryTime && Number(cs.expiryTime) > 0)
                  trafficMap[keyToUse].expiryTime = Number(cs.expiryTime);
                if (cs.total && Number(cs.total) > 0) {
                  const csTot = Number(cs.total);
                  trafficMap[keyToUse].totalGb = csTot > 10000000 ? csTot / (1024 * 1024 * 1024) : csTot;
                }
              }
            }
          }
        }
      } catch (err) {
        // Continue
      }
    }

    const freshDb = readSqliteDb();
    settings = getSystemSettings(freshDb);
    let updatedCount = 0;

    for (let k of freshDb.subscription_keys || []) {
      const matchName = (
        k.clientName ||
        k.planName ||
        k.name ||
        ""
      ).toLowerCase();
      const matchPrefix = matchName.split('@')[0];
      const matchUuid = (k.clientUuid || k.uuid || "").toLowerCase();
      const stats = (matchUuid && trafficMap[matchUuid]) || (matchName && trafficMap[matchName]) || (matchPrefix && trafficMap[matchPrefix]);

      if (stats) {
        const usedGb = stats.total / (1024 * 1024 * 1024);
        if (Math.abs((k.trafficUsedGb || 0) - usedGb) > 0.001) {
          k.trafficUsedGb = Number(usedGb.toFixed(4));
          updatedCount++;
        }

        if (
          stats.totalGb &&
          stats.totalGb > 0 &&
          (!k.trafficLimitGb || k.trafficLimitGb === 0)
        ) {
          const capGb = stats.totalGb;
          k.trafficLimitGb = Number(capGb.toFixed(2));
          updatedCount++;
        }

        if (
          stats.expiryTime &&
          stats.expiryTime > 0
        ) {
          try {
            const expiryTs = stats.expiryTime;
            if (expiryTs > 0 && expiryTs < 10000000000000) {
              const newExpiryISO = new Date(expiryTs > 10000000000 ? expiryTs : expiryTs * 1000)
                .toISOString()
                .split("T")[0];
              if (k.expireDate !== newExpiryISO) {
                k.expireDate = newExpiryISO;
                updatedCount++;
              }
            }
          } catch (e) {}
        }
      }

      // Check Expiry Warning Feature (1GB remaining or 1 Day remaining)
      const isAutoWarningEnabled =
        String(freshDb.settings?.autoWarningConfigBtn || "true") !== "false";
      let expDateObj = null;
      let remainingDays = 999;
      const remainingGb = (k.trafficLimitGb || 50) - (k.trafficUsedGb || 0);

      try {
        expDateObj = new Date(k.expireDate);
        remainingDays = Math.ceil(
          (expDateObj.getTime() - Date.now()) / (1000 * 60 * 60 * 24),
        );
      } catch (e) {}

      if (isAutoWarningEnabled && !k.expiryWarningSent) {
        if (
          (remainingGb <= 1 && remainingGb > 0) ||
          (remainingDays <= 1 && remainingDays > 0)
        ) {
          console.log(
            `[Official Warning] User ${k.userId} subscription "${k.planName || k.clientName}" is running out.`,
          );
          const msg = `⚠️ <b>هشدار اتمام سرویس</b>\n\nکاربر گرامی، سرویس شما در حال اتمام است.\n\n🌐 نام سرویس: ${k.planName || "بدون نام"}\n🔰 کد سرویس: <code>${k.clientName}</code>\n🔻 حجم باقیمانده: ${remainingGb.toFixed(2)} GB\n⏳ روز باقیمانده: ${remainingDays} روز\n\nلطفاً نسبت به تمدید سرویس خود اقدام نمایید.`;
          const inlineKeyboard = {
            inline_keyboard: [
              [
                {
                  text: "🔄 تمدید سرویس", style: "success",
                  callback_data: `mysub_renew_${k.id}`,
                },
                {
                  text: "🔗 دریافت لینک اتصال", style: "primary",
                  callback_data: `vless_link_${k.id}`,
                },
              ],
              [{ text: settings.btnTextTicketSupport || "🎫 تیکت به پشتیبانی", callback_data: "mm_btnTicketSupport", style: "primary" }],
            ],
          };
          await sendTelegramMessage(
            settings.botToken,
            k.userId,
            msg,
            inlineKeyboard,
          );
          k.expiryWarningSent = true;
          updatedCount++;
        }
      }

      // Check No-Connection Warning Alert
      const isNoConnAlertEnabled =
        String(freshDb.settings?.autoWarningNoConnectionBtn || "true") !==
        "false";
      if (
        isNoConnAlertEnabled &&
        !k.noConnectionWarningSent &&
        Math.abs(k.trafficUsedGb || 0) < 0.001
      ) {
        if (expDateObj) {
          // We infer creation date from expire date and limit duration. For simplicity, just check if 1 day passed since 'now' and start date if possible.
          // However, without a clean createdAt, we can approximate: if duration is standard 30 and remaining is <= 29.
          // Better yet, just check if `k.createdAtMs` exists. Since we don't have it, we'll mark existing ones to avoid spam.
          if (!k.createdAtMs) {
            let estimatedMs = Date.now() - 30 * 24 * 60 * 60 * 1000;
            if (k.createdAt) {
              const dt = Date.parse(k.createdAt);
              if (!isNaN(dt)) {
                estimatedMs = dt;
              }
            } else if (k.expireTimestamp) {
              estimatedMs = (Number(k.expireTimestamp) - 30 * 24 * 60 * 60) * 1000;
            }
            k.createdAtMs = estimatedMs;
            updatedCount++;
          } else {
            const daysSinceCreation =
              (Date.now() - k.createdAtMs) / (1000 * 60 * 60 * 24);
            if (daysSinceCreation >= 1) {
              console.log(
                `[Official Warning] User ${k.userId} hasn't connected for 1 day.`,
              );
              let jalaliDate = k.expireDate;
              try {
                jalaliDate = new Intl.DateTimeFormat("fa-IR", {
                  year: "numeric",
                  month: "numeric",
                  day: "numeric",
                }).format(new Date(k.expireDate));
              } catch (e) {}
              const msg = `🔔 <b>پیام سیستم:</b>\n\n🤔 <b>آیا مشکلی در اتصال به VPN دارید؟</b>\n\nسرویس شما 1 روز پیش فعال شده اما هنوز به آن متصل نشده‌اید.\n\n🖌️ نام سرویس: ${k.planName || "بدون نام"}\n🔰 کد سرویس: <code>${k.clientName}</code>\n🔺حجم بسته: ${(k.trafficLimitGb || 0).toFixed(2)} GB\n🔻حجم باقی مانده: ${remainingGb.toFixed(2)} GB\n📅 تاریخ انقضا: ${jalaliDate}\n\n🔧 <b>اگر در اتصال مشکل دارید:</b>\n• راهنمای اتصال را مطالعه کنید\n• اپلیکیشن VPN خود را بررسی کنید\n• در صورت نیاز به پشتیبانی پیام دهید`;
              const inlineKeyboard = {
                inline_keyboard: [
                  [
                    {
                      text: "🔗 لینک سابسکریپشن(همه ی کانفیگ ها)", style: "primary",
                      callback_data: `vless_link_${k.id}`,
                    },
                  ],
                  [
                    {
                      text: "🔗 لینک های تکی", style: "primary",
                      callback_data: `mysub_vless_${k.id}`,
                    },
                  ],
                  [
                    {
                      text: settings.btnTextGuides || "💡 آموزش ها", style: "primary",
                      callback_data: "mm_btnGuides",
                    },
                  ],
                  [
                    {
                      text: settings.btnTextTicketSupport || "🎫 تیکت به پشتیبانی", style: "primary",
                      callback_data: "mm_btnTicketSupport",
                    },
                  ],
                ],
              };
              await sendTelegramMessage(
                settings.botToken,
                k.userId,
                msg,
                inlineKeyboard,
              );
              k.noConnectionWarningSent = true;
              updatedCount++;
            }
          }
        }
      }

      // Check First Connection Alert
      const isFirstConnAlertEnabled =
        String(freshDb.settings?.autoWarningFirstConnectionBtn || "true") !==
        "false";
      if (
        isFirstConnAlertEnabled &&
        !k.firstConnectionMessageSent &&
        (k.trafficUsedGb || 0) > 0.001
      ) {
        console.log(
          `[Official Warning] User ${k.userId} made their first connection.`,
        );
        let jalaliDate = k.expireDate;
        try {
          jalaliDate = new Intl.DateTimeFormat("fa-IR", {
            year: "numeric",
            month: "numeric",
            day: "numeric",
          }).format(new Date(k.expireDate));
        } catch (e) {}
        const msg = `🔔 <b>پیام سیستم:</b>\n\nسرویس شما با موفقیت متصل شد\n\n🔰 کد سرویس: <code>${k.clientName}</code>\n🔺حجم بسته: ${(k.trafficLimitGb || 0).toFixed(2)} GB\n🔻حجم باقی مانده: ${remainingGb.toFixed(2)} GB\n📅 تاریخ انقضا: ${jalaliDate}\n🔹 نام سرویس: ${k.planName || "بدون نام"}`;
        const inlineKeyboard = {
          inline_keyboard: [
            [{ text: "🔗 لینک اشتراک", callback_data: `vless_link_${k.id}`, style: "primary" }],
            [{ text: settings.btnTextTicketSupport || "🎫 تیکت به پشتیبانی", callback_data: "mm_btnTicketSupport", style: "primary" }],
          ],
        };
        await sendTelegramMessage(
          settings.botToken,
          k.userId,
          msg,
          inlineKeyboard,
        );
        k.firstConnectionMessageSent = true;
        updatedCount++;
      }
    }

    // Now recalculate colleague accounts' usedTrafficGb based on allocated limits
    if (
      freshDb.colleague_accounts &&
      Array.isArray(freshDb.colleague_accounts)
    ) {
      for (const colAcc of freshDb.colleague_accounts) {
        const colKeys = (freshDb.subscription_keys || []).filter(
          (k: any) => isKeyForColleague(k, colAcc),
        );
        for (const k of colKeys) {
          if (!k.colleagueAccountId) {
            k.colleagueAccountId = colAcc.id;
          }
        }
        const totalUsed = colKeys.reduce(
          (sum: number, k: any) => sum + (Number(k.trafficLimitGb) || 0),
          0,
        );
        const totalRealUsed = colKeys.reduce(
          (sum: number, k: any) => sum + (Number(k.trafficUsedGb) || 0),
          0,
        );

        const finalUsed = totalUsed + (Number(colAcc.deletedTrafficGb) || 0);
        const finalRealUsed =
          totalRealUsed + (Number(colAcc.deletedRealTrafficGb) || 0);

        if (Math.abs((colAcc.usedTrafficGb || 0) - finalUsed) > 0.01) {
          colAcc.usedTrafficGb = Number(finalUsed.toFixed(2));
          updatedCount++;
        }
        if (Math.abs((colAcc.realUsedTrafficGb || 0) - finalRealUsed) > 0.01) {
          colAcc.realUsedTrafficGb = Number(finalRealUsed.toFixed(2));
          updatedCount++;
        }
      }
    }

    if (updatedCount > 0) {
      writeSqliteDb({
        subscription_keys: freshDb.subscription_keys,
        colleague_accounts: freshDb.colleague_accounts
      } as any);
      console.log(
        `[Auto Sync Usage] Updated traffic usage for ${updatedCount} subscriptions.`,
      );
    }
  } catch (err) {
    console.error("[Auto Sync Usage Error]", err);
  }
}

async function autoSyncInboundsList() {
  try {
    const db = readSqliteDb();
    const settings = getSystemSettings(db);
    const activeServers = getActiveServers(settings);
    if (activeServers.length === 0) return;

    let allInbounds: any[] = [];
    for (const server of activeServers) {
      const cleanedUrl = normalizeXuiUrl(server.panelUrl);
      
      if (["rebecca", "pasarguard", "marzban"].includes((server.panelType || "").toLowerCase())) {
        try {
          const access_token = await loginReebekaPasarguard(cleanedUrl, server.panelUsername, server.panelPassword);

          if (access_token) {
            let fetchedList: any[] = [];
            const endpoints = ["/api/v2/services", "/api/services", "/api/groups/simple", "/api/groups"];

            for (const ep of endpoints) {
              const res = await xuiFetch(
                `${cleanedUrl}${ep}`,
                {
                  method: "GET",
                  headers: {
                    Authorization: `Bearer ${access_token}`,
                    Accept: "application/json"
                  }
                },
                5000
              ).catch(() => null);

              if (res && res.ok) {
                const sData = await res.json().catch(() => ({}));
                const rawList = sData.services || sData.groups || (Array.isArray(sData) ? sData : []);
                if (Array.isArray(rawList) && rawList.length > 0) {
                  fetchedList = rawList.map((item: any) => ({
                    id: item.id,
                    remark: `[${server.name}] ` + (item.name || `Service #${item.id}`),
                    port: 0,
                    protocol: "service",
                    clientsCount: item.user_count || 0
                  }));
                  break;
                }
              }
            }

            if (fetchedList.length > 0) {
              allInbounds = allInbounds.concat(fetchedList);
            } else {
              allInbounds.push({
                id: 1,
                remark: `[${server.name}] Default Service`,
                port: 0,
                protocol: "service",
                clientsCount: 0
              });
            }
          }
        } catch (e) {
          console.error(`[Inbounds Sync] Failed to fetch services/groups for ${server.panelType}`, e);
        }
      } else {
        try {
          let loginResult = await loginXuiPanel(
            cleanedUrl,
            server.panelUsername,
            server.panelPassword,
          );

          if (loginResult.success) {
            const listHeaders: Record<string, string> = { Cookie: loginResult.cookie! };
            if (loginResult.csrfToken) {
              listHeaders["X-Csrf-Token"] = loginResult.csrfToken!;
            }

            const listCandidates = getInboundListCandidates(cleanedUrl);
            let rawInboundList: any[] | null = null;

            for (const candidateUrl of listCandidates) {
              try {
                let listRes = await xuiFetch(
                  candidateUrl,
                  {
                    method: "GET",
                    headers: listHeaders,
                  },
                  5000,
                );

                if (listRes.ok) {
                  const contentType = listRes.headers.get("content-type") || "";
                  const finalUrl = listRes.url || "";
                  if (contentType.includes("text/html") || finalUrl.endsWith("/login")) {
                    clearXuiPanelSession(cleanedUrl, server.panelUsername, server.panelPassword);
                    const freshLogin = await loginXuiPanel(cleanedUrl, server.panelUsername, server.panelPassword, true);
                    if (freshLogin.success && freshLogin.cookie) {
                      loginResult = freshLogin;
                      const freshHeaders: Record<string, string> = { Cookie: freshLogin.cookie };
                      if (freshLogin.csrfToken) {
                        freshHeaders["X-Csrf-Token"] = freshLogin.csrfToken!;
                      }
                      listRes = await xuiFetch(
                        candidateUrl,
                        {
                          method: "GET",
                          headers: freshHeaders,
                        },
                        5000,
                      );
                    }
                  }

                  if (listRes.ok) {
                    const listText = await listRes.text();
                    if (!listText.trim().startsWith("<")) {
                      let listJson: any = null;
                      try {
                        listJson = JSON.parse(listText);
                      } catch (e) {}
                      const extracted = extractInboundListFromResponse(listJson);
                      if (extracted !== null) {
                        rawInboundList = extracted;
                        break;
                      }
                    }
                  }
                }
              } catch (err) {}
            }

            if (rawInboundList !== null) {
              const freshInbounds = rawInboundList.map((item: any) => {
                  let totalClientsCount = 0;
                  try {
                    const settingsObj =
                      typeof item.settings === "string"
                        ? JSON.parse(item.settings)
                        : item.settings;
                    if (settingsObj && Array.isArray(settingsObj.clients)) {
                      totalClientsCount = settingsObj.clients.length;
                    }
                  } catch (e) {}

                  const usedGb = (
                    (Number(item.up || 0) + Number(item.down || 0)) /
                    (1024 * 1024 * 1024)
                  ).toFixed(1);
                  const limitGb = item.total
                    ? (Number(item.total) / (1024 * 1024 * 1024)).toFixed(0)
                    : "unlimited";

                  return {
                    id: item.id !== undefined ? item.id : 1,
                    remark:
                      `[${server.name}] ` +
                      (item.remark || item.name || item.title || item.tag || `Inbound #${item.id || 1}`),
                    protocol: item.protocol || "vless",
                    port: item.port || 1234,
                    totalClients: totalClientsCount,
                    trafficUsed: usedGb,
                    trafficLimit: limitGb,
                    status: item.enable === false ? "inactive" : "active",
                  };
                });
                allInbounds = allInbounds.concat(freshInbounds);
            }
          }
        } catch (serverErr) {
          console.warn(`[Inbounds Sync] Failed for ${server.name}:`, serverErr);
        }
      }
    }

    const db2 = readSqliteDb();
    writeSqliteDb({ inbounds: allInbounds } as any);
    console.log(`[Background Inbounds Sync] Updated ${allInbounds.length} inbounds successfully.`);
  } catch (err: any) {
    console.error("[Background Inbounds Sync Error]:", err.message);
  }
}

function getDynamicSecureContext(hostname: string) {
  try {
    const db = readSqliteDb();
    const settings = getSystemSettings(db);
    
    let pubPath = settings.sslPublicKeyPath;
    let privPath = settings.sslPrivateKeyPath;
    
    // Auto-detect if not configured
    if (!pubPath || !privPath || !fs.existsSync(pubPath) || !fs.existsSync(privPath)) {
      const targetDom = hostname || settings.domainName || "";
      if (targetDom) {
        if (fs.existsSync(`/root/cert/${targetDom}/fullchain.pem`) && fs.existsSync(`/root/cert/${targetDom}/privkey.pem`)) {
          pubPath = `/root/cert/${targetDom}/fullchain.pem`;
          privPath = `/root/cert/${targetDom}/privkey.pem`;
        } else if (fs.existsSync(`/etc/letsencrypt/live/${targetDom}/fullchain.pem`) && fs.existsSync(`/etc/letsencrypt/live/${targetDom}/privkey.pem`)) {
          pubPath = `/etc/letsencrypt/live/${targetDom}/fullchain.pem`;
          privPath = `/etc/letsencrypt/live/${targetDom}/privkey.pem`;
        } else if (fs.existsSync(`/root/.acme.sh/${targetDom}_ecc/fullchain.cer`) && fs.existsSync(`/root/.acme.sh/${targetDom}_ecc/${targetDom}.key`)) {
          pubPath = `/root/.acme.sh/${targetDom}_ecc/fullchain.cer`;
          privPath = `/root/.acme.sh/${targetDom}_ecc/${targetDom}.key`;
        } else if (fs.existsSync(`/root/.acme.sh/${targetDom}/fullchain.cer`) && fs.existsSync(`/root/.acme.sh/${targetDom}/${targetDom}.key`)) {
          pubPath = `/root/.acme.sh/${targetDom}/fullchain.cer`;
          privPath = `/root/.acme.sh/${targetDom}/${targetDom}.key`;
        }
      }
    }
    
    if (pubPath && privPath && fs.existsSync(pubPath) && fs.existsSync(privPath)) {
      return tls.createSecureContext({
        cert: fs.readFileSync(pubPath),
        key: fs.readFileSync(privPath)
      });
    }
  } catch (err: any) {
    console.error("[Dynamic SSL Context Error]:", err.message);
  }
  return null;
}

async function startServer() {
  // Start the background cron job for auto cleaning expired trials
  setInterval(autoCleanExpiredFreeTrials, 10 * 60 * 1000);
  setTimeout(autoCleanExpiredFreeTrials, 10000); // Also run shortly after startup

  // Start background cron job for auto syncing traffic every 10 seconds
  setInterval(autoSyncTrafficUsage, 10 * 1000);
  setTimeout(autoSyncTrafficUsage, 5000); // Also run shortly after startup

  // Start background cron job for auto syncing inbounds every 15 seconds
  setInterval(autoSyncInboundsList, 15 * 1000);
  setTimeout(autoSyncInboundsList, 3000); // Also run shortly after startup

  // Start background cron job for auto backup check every minute
  setInterval(checkAutoBackup, 60 * 1000);
  setTimeout(checkAutoBackup, 5000); // Check once shortly after startup

  const isProduction = process.env.NODE_ENV === "production" || process.argv[1].includes('server.cjs');

  if (!isProduction) {
    console.log("[Server] Mount dev Vite middleware mode.");

    // Handle /miniapp route fallback in dev
    app.get(["/miniapp", "/miniapp/*"], (req, res, next) => {
      req.url = "/index.html";
      next();
    });

    // Create Vite server in middleware mode
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false, allowedHosts: true },
      appType: "spa",
    });

    // Force Vite request processing
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    const distPath = path.join(process.cwd(), "dist");
    console.log(`[Server] Serving production files from: ${distPath}`);
    
    // Explicitly bypass static cache for the entry HTML files, sw.js, and manifest
    app.get(["/", "/index.html", "/sw.js", "/manifest.json"], (req, res, next) => {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      res.setHeader("Surrogate-Control", "no-store");
      if (req.path === "/sw.js") {
        const swPath = path.join(process.cwd(), "public", "sw.js");
        if (fs.existsSync(swPath)) {
          res.setHeader("Content-Type", "application/javascript");
          return res.sendFile(swPath);
        }
        const distSwPath = path.join(distPath, "sw.js");
        if (fs.existsSync(distSwPath)) {
          res.setHeader("Content-Type", "application/javascript");
          return res.sendFile(distSwPath);
        }
      }
      if (req.path === "/manifest.json") {
        const manifestPath = path.join(process.cwd(), "public", "manifest.json");
        if (fs.existsSync(manifestPath)) {
          res.setHeader("Content-Type", "application/json");
          return res.sendFile(manifestPath);
        }
      }
      if (req.path === "/" || req.path === "/index.html") {
        return res.sendFile(path.join(distPath, "index.html"));
      }
      next();
    });

    // Dynamic cache-buster: only intercept if the requested index-*.js file does not exist on disk
    app.get("/assets/index-*.js", (req, res, next) => {
       const requestedFile = path.basename(req.path);
       const requestedFilePath = path.join(distPath, "assets", requestedFile);

       if (fs.existsSync(requestedFilePath)) {
         return next();
       }

       try {
         const assetsPath = path.join(distPath, "assets");
         if (fs.existsSync(assetsPath)) {
           const files = fs.readdirSync(assetsPath);
           const hasAnyJs = files.some((f: string) => f.startsWith("index-") && f.endsWith(".js"));
           if (hasAnyJs) {
             console.log(`[Cache-Buster] Requested old JS file ${requestedFile} which does not exist. Sending reload script.`);
             res.setHeader("Content-Type", "application/javascript");
             res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
             return res.send(`
                console.log("Stale frontend cache detected. Forcing reload...");
                window.location.href = window.location.pathname + "?bust=" + new Date().getTime();
             `);
           }
         }
       } catch (e) {
         console.warn("Error in dynamic cache-buster check", e);
       }
       next();
    });

    app.use(express.static(distPath, {
      setHeaders: (res, filePath) => {
        if (filePath.endsWith('.html')) {
          res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
          res.setHeader('Pragma', 'no-cache');
          res.setHeader('Expires', '0');
        } else {
          // Cache JS/CSS assets for 1 year since Vite uses content hashes
          res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
        }
      }
    }));

    // Explicitly bypass static cache for miniapp route
    app.get(["/miniapp", "/miniapp/*"], (req, res) => {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      res.setHeader("Surrogate-Control", "no-store");
      res.sendFile(path.join(distPath, "index.html"));
    });

    app.get("*", (req, res) => {
      res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      res.setHeader("Surrogate-Control", "no-store");
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // In dev / non-production mode, start the standard HTTP server immediately
  if (!isProduction) {
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`[Daltoon Dev Server] HTTP Server running at: http://0.0.0.0:${PORT}`);
    });
    return;
  }

  let isSslActive = true;
  let sslOptions: any = null;

  try {
    const db = readSqliteDb();
    const settings = getSystemSettings(db);
    
    let pubPath = settings.sslPublicKeyPath;
    let privPath = settings.sslPrivateKeyPath;
    
    // Auto-detect if not configured in DB at boot
    if (!pubPath || !privPath || !fs.existsSync(pubPath) || !fs.existsSync(privPath)) {
      const targetDom = (settings.domainName || "").trim();
      const possibleDoms: string[] = [];
      if (targetDom) possibleDoms.push(targetDom);

      // Also scan /root/cert for any available domain certificates
      if (fs.existsSync("/root/cert")) {
        try {
          const dirs = fs.readdirSync("/root/cert");
          for (const d of dirs) {
            if (d && !possibleDoms.includes(d)) possibleDoms.push(d);
          }
        } catch (e) {}
      }

      // Also scan /etc/letsencrypt/live
      if (fs.existsSync("/etc/letsencrypt/live")) {
        try {
          const leDirs = fs.readdirSync("/etc/letsencrypt/live");
          for (const d of leDirs) {
            if (d && !possibleDoms.includes(d)) possibleDoms.push(d);
          }
        } catch (e) {}
      }

      for (const dom of possibleDoms) {
        if (fs.existsSync(`/root/cert/${dom}/fullchain.pem`) && fs.existsSync(`/root/cert/${dom}/privkey.pem`)) {
          pubPath = `/root/cert/${dom}/fullchain.pem`;
          privPath = `/root/cert/${dom}/privkey.pem`;
          break;
        } else if (fs.existsSync(`/etc/letsencrypt/live/${dom}/fullchain.pem`) && fs.existsSync(`/etc/letsencrypt/live/${dom}/privkey.pem`)) {
          pubPath = `/etc/letsencrypt/live/${dom}/fullchain.pem`;
          privPath = `/etc/letsencrypt/live/${dom}/privkey.pem`;
          break;
        } else if (fs.existsSync(`/root/.acme.sh/${dom}_ecc/fullchain.cer`) && fs.existsSync(`/root/.acme.sh/${dom}_ecc/${dom}.key`)) {
          pubPath = `/root/.acme.sh/${dom}_ecc/fullchain.cer`;
          privPath = `/root/.acme.sh/${dom}_ecc/${dom}.key`;
          break;
        } else if (fs.existsSync(`/root/.acme.sh/${dom}/fullchain.cer`) && fs.existsSync(`/root/.acme.sh/${dom}/${dom}.key`)) {
          pubPath = `/root/.acme.sh/${dom}/fullchain.cer`;
          privPath = `/root/.acme.sh/${dom}/${dom}.key`;
          break;
        }
      }
    }
    
    if (pubPath && privPath && fs.existsSync(pubPath) && fs.existsSync(privPath)) {
      console.log(`[Daltoon Full-Stack Server] Found valid SSL certs at startup: ${pubPath}`);
      sslOptions = {
        cert: fs.readFileSync(pubPath),
        key: fs.readFileSync(privPath),
      };
    } else {
      isSslActive = false;
    }
  } catch (sslErr: any) {
    console.warn("[SSL Server Start Warning] Could not load HTTPS certs:", sslErr.message);
    isSslActive = false;
  }

  if (isSslActive && sslOptions) {
    try {
      const httpsServer = https.createServer(sslOptions, app);
      httpsServer.listen(PORT, "0.0.0.0", () => {
        console.log(`[Daltoon Full-Stack Server] HTTPS Server running at: https://0.0.0.0:${PORT}`);
      });
    } catch (e: any) {
      console.warn(`[HTTPS setup error, fallback to standard HTTP]`, e.message);
      app.listen(PORT, "0.0.0.0", () => {
        console.log(`[Daltoon Full-Stack Server] Fallback HTTP Server running at: http://0.0.0.0:${PORT}`);
      });
    }
  } else {
    // Standard HTTP server on PORT
    app.listen(PORT, "0.0.0.0", () => {
      console.log(
        `[Daltoon Full-Stack Server] HTTP Server running at: http://0.0.0.0:${PORT}`,
      );
    });
  }
}

startServer();
